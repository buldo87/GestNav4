MODEL.SETPERSISTENT.lua.desinstall_radar = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.EtatMapchanger = INT_MODEL(0)