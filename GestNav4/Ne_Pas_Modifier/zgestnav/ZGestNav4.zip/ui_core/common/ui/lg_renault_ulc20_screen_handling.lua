eScreenTypes = {
    Map = 0,
    Nav = 1,
    Home = 2,
    PointOnMap = 3,
    AHA = 4,
    Phone = 5,
    BackFromPhone = 6
}
eSynctoolScenarios = {
    AfterDefault = 0,
    AfterFingerprint = 1,
    AfterUpdate = 2,
    None = 3
}
function sc_Start_Screen_Handling()
    local scenario = MODEL.other.lg_renault.synctool_scenario()
    if scenario == eSynctoolScenarios.None then
        ui.vSynctoolStarted = 0
    elseif scenario == eSynctoolScenarios.AfterFingerprint or scenario == eSynctoolScenarios.AfterDefault then
        NEXTSTATE(st_AboutContents)
    end
end

function sc_Debug_Exit()
    MODEL.other.lg_renault.send_screen_message(eScreenTypes.Home)
    MODEL.other.lg_renault.initiate_shutdown()
end

function sc_Set_Voice_Testing_Mode(enabled)
    if enabled then
        MODEL.sound.tts_manager.starting_test()
    else
        MODEL.sound.tts_manager.stoping_test()
    end
    MODEL.other.lg_renault.voice_testing_mode = enabled
end

function sc_Is_LG_Screen(screenType)
    return MODEL.other.lg_renault.identify_lg_screen(screenType)
end

function sc_NavCtrl_ScreenChange(screenType)
    debug_log("lg_renault", 3, "lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
    sc_HwKeySelect()
    if screenType == eScreenTypes.Map then
        sc_GoToMap()
    elseif screenType == eScreenTypes.Nav then
        if MODEL.other.lg_renault.eco_support() then
            sc_GoToMap()
        else
            sc_GoTo_MainMenu()
        end
    else
        debug_log("lg_renault", 1, "SERIOUS screen-change PROBLEM: lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
        sc_GoTo_MainMenu()
    end
end

function sc_Screen_Control(hook, screenType)
    local lgModel = MODEL.other.lg_renault
    debug_log("lg_renault", 3, "lua sc_Screen_Control screenType = " .. tostring(screenType))
    if lgModel.navi_on_voice_settings_screen() then
        if screenType == eScreenTypes.Phone then
            sc_Set_Voice_Testing_Mode(false)
        elseif screenType == eScreenTypes.BackFromPhone then
            sc_Set_Voice_Testing_Mode(true)
        end
    end
    if sc_Is_LG_Screen(screenType) then
        if lgModel.voice_testing_mode() then
            sc_Set_Voice_Testing_Mode(false)
        end
        lgModel.disable_render()
    else
        lgModel.enable_render()
        if screenType == eScreenTypes.PointOnMap then
            lgModel.go_to_point_on_map()
        elseif screenType ~= eScreenTypes.BackFromPhone then

                sc_NavCtrl_ScreenChange(screenType)

        end
        lgModel.force_render_screen()
        lgModel.put_main_window_on_top()
    end
    lgModel.send_screen_message(screenType)
end

