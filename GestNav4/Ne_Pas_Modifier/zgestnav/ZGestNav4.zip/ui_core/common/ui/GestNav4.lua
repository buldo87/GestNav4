-- GestNav4.lua  *****************
StartInit:register(function()
    for idx = 1, #tPOISearchanims do
        if tPOISearchanims[idx] == "spr_Accomodation_anim" then
            table.remove(tPOISearchanims, idx)
        end
    end

    for cntr = 1, #RouteTypes do
        if RouteTypes[cntr].name == "Easy" then
            table.remove(RouteTypes, cntr)
            break
        end
    end
    MODEL.other.sensor_fusion.enabled = true
    MODEL.lua.show_exit = sc_GetSysEntry("interface", "show_exit", 0)
    MODEL.other.lg_renault.screen_change():register(sc_Screen_Control)
    MODEL.other.lg_renault.start_screen_handling():register(sc_Start_Screen_Handling)
    MODEL.map.states["2dheadup"].tilt = MODEL.map.states.navmap3d.tilt()
    MODEL.map.states["2dnorthup"].tilt = MODEL.map.states.navmap3d.tilt()
end
)
createState("st_GestNav4")
st_GestNav4:useLayers(backgroundLayers, "ui_SkinGestionList", "ui_List_Background")
function st_GestNav4.init()
    txtTitle.TEXT = m_i18n("GestNav4")
    if Plugin:isLoaded("__skin_mediaevo_v3_mod_bleu_cacou13_miochacha") then
        MODEL.lua.desinstall_radar = false
    elseif Plugin:isLoaded("__Skin_MediaEvo_v3_Al194_buldo_cacou_SmayK") then
        MODEL.lua.desinstall_radar = false
	elseif Plugin:isLoaded("__Skin_Plus") then
        MODEL.lua.desinstall_radar = false
    elseif Plugin:isLoaded("__skin_mediaevo_v3_mod_RS_cacou13") then
        MODEL.lua.desinstall_radar = false
    elseif Plugin:isLoaded("__skin_mediaevo_v3_mod_ultimate_cacou13") then
        MODEL.lua.desinstall_radar = false
    elseif Plugin:isLoaded("_carbone") then
        MODEL.lua.carbone = true
    else
        MODEL.lua.desinstall_radar = true
    end
    MODEL.lua.EtatMapchanger = sc_GetSysEntry("gestnav4", "image_maps", 0)
end

function sc_GestNav4_OnRelease()
    sc_NextStateAnim(st_GestNav4, "horz_scroll", 1, "")
end

function sc_GetMedia(phase)
    if phase >= 1 and phase <= #eMediaIconType then
        return eMediaIconType[phase]
    end
    return ""
end
----------Desinstallation Radars
function sc_Desinstall_Radars_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want uninstall"))
    newMsgBox.set_line(2, m_i18n("the speedcam ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstall_Radars", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstall_Radars()
    local params = "//navi_rw//utility//GestNav4//DesinstallationRadars.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----------Installations Radars EUR+
function sc_MaJRadars_EUR_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install speedcam EUR+ ?"))
    newMsgBox.set_line(2, m_i18n("you will have to wait 3 to 4 minutes"))
    newMsgBox.setup_button(1, "sc_OkMaJRadars_EUR", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMaJRadars_EUR()
    local params = "//navi_rw//utility//GestNav4//InstallationRadarsEUR.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----------Installation Radars STD
function sc_MaJRadars_STD_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install speedcam STD ?"))
    newMsgBox.set_line(2, m_i18n("you will have to wait 3 to 4 minutes"))
    newMsgBox.setup_button(1, "sc_OkMaJRadars_STD", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMaJRadars_STD()
    local params = "//navi_rw//utility//GestNav4//InstallationRadarsStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------Sauvegarde Radars EUR+
function sc_SauvRadars_EUR_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save"))
    newMsgBox.set_line(2, m_i18n("speedcam EUR+ ?"))
    newMsgBox.setup_button(1, "sc_OkSauvRadars_EUR", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvRadars_EUR()
    local params = "//navi_rw//utility//GestNav4//SauvegardeRadarsEUR.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------Sauvegarde Radars STD
function sc_SauvRadars_STD_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save"))
    newMsgBox.set_line(2, m_i18n("speedcam STD ?"))
    newMsgBox.setup_button(1, "sc_OkSauvRadars_STD", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvRadars_STD()
    local params = "//navi_rw//utility//GestNav4//SauvegardeRadarsStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Extras
createState("st_Extras")
st_Extras:useLayers(backgroundLayers, "ui_ExtrasList", "ui_List_Background")
function st_Extras.init()
    txtTitle.TEXT = m_i18n("Extras")
    MODEL.lua.EtatMapchanger = sc_GetSysEntry("gestnav4", "image_maps", 0)
end

function sc_Extras_OnRelease()
    sc_NextStateAnim(st_Extras, "horz_scroll", 1, "")
end

-- restauration all
function sc_RestorationMap_onlongclick()
    MODEL.lua.AutMapUpdate = false
    MODEL.lua.cerise = false
end
---- warning suppression sans skin
function sc_SupressionSansSkin_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete"))
    newMsgBox.set_line(2, m_i18n("modifications (except the skin)?"))
    newMsgBox.setup_button(1, "sc_OkSupressionSansSkin", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSupressionSansSkin()
    MODEL.lua.AutMapUpdate = false
    MODEL.lua.cerise = false
    MODEL.lua.desinstall_radar = true
    local params = "//navi_rw//utility//GestNav4//installation.sh amelioration uninstall_tous " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----------------------------- Sauvegarde restauration -----------------------------------------------
----------SauvNavigation
function sc_SauvNavigation_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save the navigation ?"))
    newMsgBox.set_line(2, m_i18n("it can last several minutes"))
    newMsgBox.setup_button(1, "sc_OkSauvNavigation", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvNavigation()
    local params = "//navi_rw//utility//GestNav4//SauvegardeNavigation.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------RestaurationNavi
function sc_RestaurationNavi_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to restore navigation ?"))
    newMsgBox.set_line(2, m_i18n("BE CAREFUL TO HAVE THE FILES! it can last several minutes"))
    newMsgBox.setup_button(1, "sc_OkRestaurationNavi", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRestaurationNavi()
    local params = "//navi_rw//utility//GestNav4//RestaurationNavigation.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Effacer Dossier Navi nota on a supprim� cette option
function sc_EffacerDossierNavi_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete"))
    newMsgBox.set_line(2, m_i18n("Navi folder totally ?"))
    newMsgBox.setup_button(1, "sc_OkSupressionDossierNavi", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSupressionDossierNavi()
    local params = "//navi_rw//utility//GestNav4//SupprimerNavi.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----------Sauv save
function sc_SauvSave_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save"))
    newMsgBox.set_line(2, m_i18n("Save folder totally ?"))
    newMsgBox.setup_button(1, "sc_OkSauvSave", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvSave()
    local params = "//navi_rw//utility//GestNav4//SauvegardeSave.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----- Restauration Save
function sc_RestaurationDossierSave_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to restore"))
    newMsgBox.set_line(2, m_i18n("Save folder totally ?"))
    newMsgBox.setup_button(1, "sc_OkRestaurationSave", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRestaurationSave()
    local params = "//navi_rw//utility//GestNav4//RestaurationSave.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----- Effacer Dossier Save
function sc_EffacerDossierSave_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete"))
    newMsgBox.set_line(2, m_i18n("Save folder totally ?"))
    newMsgBox.setup_button(1, "sc_OkEffacerSave", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkEffacerSave()
    local params = "//navi_rw//utility//GestNav4//SupprimerSave.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------------------------Gestion des favoris----------------------------------------
----- Installation Favori
function sc_InstallationFavori_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Favorites ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFavori", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFavori()
    local params = "//navi_rw//utility//GestNav4//InstallationFavori.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------- SauvFavoris
function sc_SauvFavoris_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save"))
    newMsgBox.set_line(2, m_i18n("your Favorites ?"))
    newMsgBox.setup_button(1, "sc_OkSauvFavoris", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvFavoris()
    local params = "//navi_rw//utility//GestNav4//SauvegardeFavoris.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Restauration Favori
function sc_RestaurationFavori_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to restore"))
    newMsgBox.set_line(2, m_i18n("your Favorites ?"))
    newMsgBox.setup_button(1, "sc_OkRestaurationFavori", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRestaurationFavori()
    local params = "//navi_rw//utility//GestNav4//RestaurationFavoris.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
------------------------------------------fin de gestion des favoris----------------------------------------

-------------------------------------------------Gestion des kml----------------------------------------
----- Installation kml
function sc_Installationkml_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your personnel kml ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationkml", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationkml()
    local params = "//navi_rw//utility//GestNav4//InstallationKml.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------- Sauvkml
function sc_Sauvkml_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to save"))
    newMsgBox.set_line(2, m_i18n("your personnel kml ?"))
    newMsgBox.setup_button(1, "sc_OkSauvkml", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSauvkml()
    local params = "//navi_rw//utility//GestNav4//SauvegardeKml.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Restauration kml
function sc_Restaurationkml_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to restore"))
    newMsgBox.set_line(2, m_i18n("your personnel kml ?"))
    newMsgBox.setup_button(1, "sc_OkRestaurationkml", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRestaurationkml()
    local params = "//navi_rw//utility//GestNav4//RestaurationKml.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Suppression kml
function sc_Deletekml_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete"))
    newMsgBox.set_line(2, m_i18n("your personnel kml ?"))
    newMsgBox.setup_button(1, "sc_OkDeletekml", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDeletekml()
    local params = "//navi_rw//utility//GestNav4//SupprimerKml.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
------------------------------------------fin de gestion des kml----------------------------------------

----------- Diagnostic
function sc_Diagnostic_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to make a Diag ?"))
    newMsgBox.set_line(2, m_i18n("Diagnostic_navigation.txt on your key"))
    newMsgBox.setup_button(1, "sc_OkDiagnostic", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDiagnostic()
    local params = "//navi_rw//utility//GestNav4//Diagnostic.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- D�sinstaller GestNav4
function sc_DesinstallerGestNav_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you really want to delete"))
    newMsgBox.set_line(2, m_i18n("GestNav4 ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallerGestNav", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstallerGestNav()
    local params = "//navi_rw//utility//GestNav4//Desinstallation_Gestnav.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
----------------------------- Fin Sauvegarde restauration -----------------------------------------------

----- MAJ Diverses
createState("st_MaJ_Diverses")
st_MaJ_Diverses:useLayers(backgroundLayers, "ui_MaJ_DiversesList", "ui_List_Background")
function st_MaJ_Diverses.init()
    txtTitle.TEXT = m_i18n("Miscellaneous updates")
end

function sc_MaJ_Diverses_OnRelease()
    sc_NextStateAnim(st_MaJ_Diverses, "horz_scroll", 1, "")
end

---------------------------------Menu MaJ diverses---------------------------------

----- MapUpdate
function sc_MapUpdate_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to install your navi content"))
    newMsgBox.set_line(2, m_i18n("who is in Navi user_installation ?"))
    newMsgBox.setup_button(1, "sc_OkMapupdate", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMapupdate()
    local params = "//navi_rw//utility//GestNav4//InstallMap.sh navi " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- HereUpdate
function sc_HereUpdate_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to install Here navi"))
    newMsgBox.set_line(2, m_i18n("who is in Navi user_installation map_changer... ?"))
    newMsgBox.setup_button(1, "sc_OkHereUpdate", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkHereUpdate()
    local params = "//navi_rw//utility//GestNav4//InstallMap.sh here " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Heredelete
function sc_HereDelete_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete Here navi"))
    newMsgBox.setup_button(1, "sc_OkHereDelete", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkHereDelete()
    local params = "//navi_rw//utility//GestNav4//SupprimerHere.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- TomtomUpdate
function sc_TomtomUpdate_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to install Tomtom navi"))
    newMsgBox.set_line(2, m_i18n("who is in Navi user_installation map_changer... ?"))
    newMsgBox.setup_button(1, "sc_OkTomtomUpdate", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkTomtomUpdate()
    local params = "//navi_rw//utility//GestNav4//InstallMap.sh tomtom " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Tomtomdelete
function sc_TomtomDelete_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to delete Tomtom navi"))
    newMsgBox.setup_button(1, "sc_OkTomtomDelete", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkTomtomDelete()
    local params = "//navi_rw//utility//GestNav4//SupprimerTomtom.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

---------------------------------fin menu MaJ diverses---------------------------------

----- ImagesBoot
createState("st_ImagesBoot")
st_ImagesBoot:useLayers(backgroundLayers, "ui_ImagesBootList", "ui_List_Background")
function st_ImagesBoot.init()
    txtTitle.TEXT = m_i18n("boot images")
end

function sc_ImagesBoot_OnRelease()
    sc_NextStateAnim(st_ImagesBoot, "horz_scroll", 1, "")
end

-------------------------------Lecteur Vid�o new
function sc_LecteurVideo_OnRelease()
    sc_NextStateAnim(st_LecteurVideo, "horz_scroll", 1, "")
end
createState("st_LecteurVideo")
st_LecteurVideo:useLayers(backgroundLayers, "ui_LecteurVideo", "ui_List_Background")
function st_LecteurVideo.init()
    txtTitle.TEXT = m_i18n("Video player")
end

function sc_InstallationLecteurVideo()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Video player ?"))
    newMsgBox.setup_button(1, "sc_OkInstallLecteurVideo", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallLecteurVideo()
    local params = "//navi_rw//utility//GestNav4//LecteurVideo.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationLecteurVideo()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("Video player ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallLecteurVideo", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesinstallLecteurVideo()
    local params = "//navi_rw//utility//GestNav4//LecteurVideo.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- MaJ radars
createState("st_MaJRadars")
st_MaJRadars:useLayers(backgroundLayers, "ui_MaJRadarsList", "ui_List_Background")
function st_MaJRadars.init()
    txtTitle.TEXT = m_i18n("Speedcam updates")
end

function sc_MaJRadars_OnRelease()
    sc_NextStateAnim(st_MaJRadars, "horz_scroll", 1, "")
end

----- sauvegarde restauration
createState("st_SauvRestauration")
st_SauvRestauration:useLayers(backgroundLayers, "ui_SauvRestaurationList", "ui_List_Background")
function st_SauvRestauration.init()
    txtTitle.TEXT = m_i18n("Save and restore")
end

function sc_SauvRestauration_OnRelease()
    sc_NextStateAnim(st_SauvRestauration, "horz_scroll", 1, "")
end

----------------------------- gestion mapchanger -----------------------------------------------

----- Map Changer
createState("st_MapChanger")
st_MapChanger:useLayers(backgroundLayers, "ui_MapChangerList", "ui_List_Background")
function st_MapChanger.init()
    txtTitle.TEXT = m_i18n("Map Changer")
end

function sc_MapChanger_OnRelease()
    sc_NextStateAnim(st_MapChanger, "horz_scroll", 1, "")
end

----------MapChanger_here
function sc_MapChanger_here_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Would you switch"))
    newMsgBox.set_line(2, m_i18n("to map_Here ?"))
    newMsgBox.setup_button(1, "sc_OkMapChanger_here", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMapChanger_here()
    local params = "//navi_rw//utility//GestNav4//MapChanger.sh here " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------MapChanger_tomtom
function sc_MapChanger_tomtom_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Would you switch"))
    newMsgBox.set_line(2, m_i18n("to map_tomtom ?"))
    newMsgBox.setup_button(1, "sc_OkMapChanger_tomtom", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMapChanger_tomtom()
    local params = "//navi_rw//utility//GestNav4//MapChanger.sh tomtom " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------MapChanger_usb_here
function sc_MapChanger_usb_here_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Would you switch"))
    newMsgBox.set_line(2, m_i18n("to map_usb_here ?"))
    newMsgBox.setup_button(1, "sc_OkMapChanger_usb_here", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMapChanger_usb_here()
    local params = "//navi_rw//utility//GestNav4//MapChanger.sh usb_here " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------MapChanger_usb_tomtom
function sc_MapChanger_usb_tomtom_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Would you switch"))
    newMsgBox.set_line(2, m_i18n("to map_usb_tomtom ?"))
    newMsgBox.setup_button(1, "sc_OkMapChanger_usb_tomtom", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkMapChanger_usb_tomtom()
    local params = "//navi_rw//utility//GestNav4//MapChanger.sh usb_tomtom " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------------------------- fin gestion mapchanger -----------------------------------------------

----- schemes
createState("st_ImageSchemes")
st_ImageSchemes:useLayers(backgroundLayers, "ui_ImageSchemesList", "ui_List_Background")
function st_ImageSchemes.init()
    txtTitle.TEXT = m_i18n("Pictures Schemes")
end

function sc_ImageSchemes_OnRelease()
    sc_NextStateAnim(st_ImageSchemes, "horz_scroll", 1, "")
end

----- skin
createState("st_ImageSkins")
st_ImageSkins:useLayers(backgroundLayers, "ui_ImageSkinsList", "ui_List_Background")
function st_ImageSkins.init()
    txtTitle.TEXT = m_i18n("Mods and Skins")
end

function sc_ImageSkins_OnRelease()
    sc_NextStateAnim(st_ImageSkins, "horz_scroll", 1, "")
end

---- Radar
createState("st_ImageRadar")
st_ImageRadar:useLayers(backgroundLayers, "ui_ImageRadarList", "ui_List_Background")
function st_ImageRadar.init()
    txtTitle.TEXT = m_i18n("Speedcam icons EUR+")
end

function sc_ImageRadar_OnRelease()
    sc_NextStateAnim(st_ImageRadar, "horz_scroll", 1, "")
end

---- RadarStd
createState("st_ImageRadarStd")
st_ImageRadarStd:useLayers(backgroundLayers, "ui_ImageRadarStdList", "ui_List_Background")
function st_ImageRadarStd.init()
    txtTitle.TEXT = m_i18n("Speedcam icons STD")
end

function sc_ImageRadarStd_OnRelease()
    sc_NextStateAnim(st_ImageRadarStd, "horz_scroll", 1, "")
end

---- Fleche
createState("st_FlecheDirection")
st_FlecheDirection:useLayers(backgroundLayers, "ui_FlecheDirectionList", "ui_List_Background")
function st_FlecheDirection.init()
    txtTitle.TEXT = m_i18n("Arrow Diricon")
end

function sc_FlecheDirection_OnRelease()
    sc_NextStateAnim(st_FlecheDirection, "horz_scroll", 1, "")
end

--- voiture
createState("st_TypeVoiture")
st_TypeVoiture:useLayers(backgroundLayers, "ui_TypeVoitureList", "ui_List_Background")
function st_TypeVoiture.init()
    txtTitle.TEXT = m_i18n("Type of car")
end

function sc_TypeVoiture_OnRelease()
    sc_NextStateAnim(st_TypeVoiture, "horz_scroll", 1, "")
end

--- POI
createState("st_POI")
st_POI:useLayers(backgroundLayers, "ui_POIList", "ui_List_Background")
function st_POI.init()
    txtTitle.TEXT = m_i18n("POI icon")
end

function sc_POI_OnRelease()
    sc_NextStateAnim(st_POI, "horz_scroll", 1, "")
end


---Telepules
createState("st_Telepule")
st_Telepule:useLayers(backgroundLayers, "ui_TelepuleList", "ui_List_Background")
function st_Telepule.init()
    txtTitle.TEXT = m_i18n("Telepules")
end

function sc_Telepule_OnRelease()
    sc_NextStateAnim(st_Telepule, "horz_scroll", 1, "")
end

createState("st_About_GestNav4")
st_About_GestNav4:useLayers(backgroundLayers, "ui_About_GestNav4")
function st_About_GestNav4.init()
    txtTitle.TEXT = m_i18n("About")
end

function sc_About_GestNav4_OnRelease()
    sc_NextStateAnim(st_About_GestNav4, "horz_scroll", 1, "")
end

---- Options
createState("st_Options")
st_Options:useLayers(backgroundLayers, "ui_OptionsList", "ui_List_Background")
function st_Options.init()
    txtTitle.TEXT = m_i18n("Options GestNav4")
end

function sc_Options_OnRelease()
    sc_NextStateAnim(st_Options, "horz_scroll", 1, "")
end

----- Installer GestNav4 sur le MN
function sc_GestNav4SurMN_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install GestNav4"))
    newMsgBox.set_line(2, m_i18n("on the Medianav ? "))
    newMsgBox.setup_button(1, "sc_OkGestNav4SurMN", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkGestNav4SurMN()
    local params = "//navi_rw//utility//GestNav4//GestNav4SurMN.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-- cacou long
function sc_RootCacou_onlongclick()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("TMC"))
    newMsgBox.set_line(2, m_i18n("cacou ? "))
    newMsgBox.setup_button(1, "sc_OkRootCacou", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRootCacou()
    local params = "//navi_rw//utility//GestNav4//cacou_long.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-- cacou
function sc_cacou_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Cerise"))
    newMsgBox.set_line(2, m_i18n("cacou ? "))
    newMsgBox.setup_button(1, "sc_Okcacou", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_Okcacou()
    local params = "//navi_rw//utility//GestNav4//cacou.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

------------  loading finished
function sc_loading_finished()
    MODEL.other.loading_finished = true
    startUp = false
    MODEL.other.create_process(true, L"//bin//bash", L"", L"//navi_rw//utility//GestNav4//loading_finished.sh", false)
end

----------------------  skinLG

createState("st_SkinLG")
st_SkinLG:useLayers(backgroundLayers, "ui_SkinLGList", "ui_List_Background")
function st_SkinLG.init()
    txtTitle.TEXT = m_i18n("Installation Skin LG")
end

function sc_SkinLG_OnRelease()
    sc_NextStateAnim(st_SkinLG, "horz_scroll", 1, "")
end

function sc_SkinLG_Original_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("do you want to restore"))
    newMsgBox.set_line(2, m_i18n("Original skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Original", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Original()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Original " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_bleu_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Blue skin Jere44460"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_bleu", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_bleu()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Bleu " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_RougeNoir_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Red Black skin Jere44460"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_RougeNoir", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_RougeNoir()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh RougeNoir " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Sicilia_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Sicilia skin Enriko_87_"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Sicilia", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Sicilia()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Sicilia " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Orange_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Orange skin mauntz"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Orange", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Orange()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Orange " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Batman_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Batman skin mauntz"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Batman", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Batman()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Batman " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Futuro_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Futuro skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Futuro", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Futuro()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Futuro " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Anime_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Anime skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Anime", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Anime()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Anime " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Orange_Ludo13_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Orange skin Ludo13"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Orange_Ludo13", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Orange_Ludo13()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Orange_Ludo13 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Anniversary_gray_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Anniversary gray skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Anniversary_gray", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Anniversary_gray()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Anniversary_gray " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Lapins_cretins_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Raving Rabbids Skin LN"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Lapins_cretins", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Lapins_cretins()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Lapins_cretins " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Bleu_Ludo13_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Blue skin Ludo13"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Bleu_Ludo13", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Bleu_Ludo13()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Bleu_Ludo13 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Carbon_Blue_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Carbon Blue skin Ludo13"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Carbon_Blue", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Carbon_Blue()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Carbon_Blue " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Fly_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Fly skin Ludo13"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Fly", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Fly()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Fly " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_MN4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("MN4 skin Jere44460"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_MN4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_MN4()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh MN4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_MN4_Dacia_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("MN4 Dacia skin Jere44460"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_MN4_Dacia", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_MN4_Dacia()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh MN4_Dacia " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Dark_Simple_1_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Dark Simple 1 skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Dark_Simple_1", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Dark_Simple_1()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Dark_Simple_1 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Vendetta_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Vendetta skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Vendetta", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Vendetta()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Vendetta " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_The_Expanse_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("The Expanse skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_The_Expanse", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_The_Expanse()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh The_Expanse " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Metal_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Metal skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Metal", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Metal()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Metal " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Cool_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Cool skin caps & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Cool", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Cool()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Cool " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Colors_series_Blue_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Color series blue skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Colors_series_Blue", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Colors_series_Blue()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Colors_series_Blue " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Colors_series_Green_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Color series green skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Colors_series_Green", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Colors_series_Green()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Colors_series_Green " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Colors_series_Purple_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Color series purple skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Colors_series_Purple", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Colors_series_Purple()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Colors_series_Purple " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Colors_series_Red_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Color series red skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Colors_series_Red", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Colors_series_Red()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Colors_series_Red " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Colors_series_Yellow_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Color series yellow skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Colors_series_Yellow", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Colors_series_Yellow()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Colors_series_Yellow " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Elements_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Elements skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Elements", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Elements()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Elements " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eco_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Eco skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eco", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eco()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eco " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Azure_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Azure skin Cangi & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Azure", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Azure()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Azure " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Dark_Simple_2_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Dark Simple 2 skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Dark_Simple_2", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Dark_Simple_2()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Dark_Simple_2 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Grey_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Grey skin Cangi & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Grey", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Grey()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Grey " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_MyMN4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("MyMN4 skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_MyMN4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_MyMN4()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh MyMN4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Orange_Cangi_Fina_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Orange skin Cangi & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Orange_Cangi_Fina", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Orange_Cangi_Fina()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Orange_Cangi_Fina " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_PMN4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("PMN4 skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_PMN4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_PMN4()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh PMN4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_PWRUP_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("PWRUP skin SM5 S.Marcon"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_PWRUP", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_PWRUP()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh PWRUP " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Space_1999_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Space 1999 skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Space_1999", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Space_1999()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Space_1999 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_RedFusion_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Red fusion skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_RedFusion", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_RedFusion()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh RedFusion " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Ribbon_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Ribbon skin E.Saccone"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Ribbon", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Ribbon()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Ribbon " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Roads_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Roads skin L.Raffa"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Roads", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Roads()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Roads " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Neon_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Neon skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Neon", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Neon()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Neon " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Exagon_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Exagon skin caps & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Exagon", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Exagon()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Exagon " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Malinois_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Malinois skin Chinellato"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Malinois", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Malinois()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Malinois " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_LupinIII_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("LupinIII skin caps"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_LupinIII", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_LupinIII()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh LupinIII " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Sandero_Orange_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Sandero orange skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Sandero_Orange", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Sandero_Orange()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Sandero_Orange " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Scary_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Scary skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Scary", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Scary()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Scary " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Westie_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Westie skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Westie", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Westie()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Westie " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_ForceAwakens_bleu_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Blue Star Wars Force Awakens skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_ForceAwakens_bleu", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_ForceAwakens_bleu()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh ForceAwakens_bleu " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_ForceAwakens_rouge_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Red Star Wars Force Awakens skin A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_ForceAwakens_rouge", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_ForceAwakens_rouge()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh ForceAwakens_rouge " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------------------  skinLG2

function sc_SkinLG_4WD_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Skin 4WD A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_4WD", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_4WD()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh 4WD " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_G_Eco_Blue_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("G-Eco Blue skin Chinellato"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_G_Eco_Blue", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_G_Eco_Blue()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh G_Eco_Blue " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_G_Eco_Red_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("G-Eco Red skin Chinellato"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_G_Eco_Red", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_G_Eco_Red()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh G_Eco_Red " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eclipse_Blue_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Blue Eclipse skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eclipse_Blue", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eclipse_Blue()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eclipse_Blue " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eclipse_Red_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Red Eclipse skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eclipse_Red", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eclipse_Red()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eclipse_Red " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Enigma_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Enigma skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Enigma", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Enigma()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Enigma " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eternity_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Eternity skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eternity", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eternity()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eternity " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eternity_Alien_Blue_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Eternity Alien blue skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eternity_Alien_Blue", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eternity_Alien_Blue()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eternity_Alien_Blue " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Eternity_Alien_Red_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Eternity Alien Red skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Eternity_Alien_Red", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Eternity_Alien_Red()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Eternity_Alien_Red " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_iOS_DDFI_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("iOS DDFI skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_iOS_DDFI", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_iOS_DDFI()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh iOS_DDFI " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Minimal_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Minimal skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Minimal", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Minimal()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Minimal " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Xtra_Azure_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Xtra Azure skin"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Xtra_Azure", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Xtra_Azure()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Xtra_Azure " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_SkinLG_Universal_Dacia_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Universal Dacia skin M.Iannone & A.Fina"))
    newMsgBox.setup_button(1, "sc_OkSkinLG_Universal_Dacia", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkSkinLG_Universal_Dacia()
    local params = "//navi_rw//utility//GestNav4//InstallationSkinLG.sh Universal_Dacia " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------------------------Gestion des Options original----------------------------------------
----------TripInfo
createState("st_TripInfo")
st_TripInfo:useLayers(backgroundLayers, "ui_TripInfoList", "ui_List_Background")
function st_TripInfo.init()
    txtTitle.TEXT = m_i18n("Trip info")
end

function sc_TripInfo_OnRelease()
    sc_NextStateAnim(st_TripInfo, "horz_scroll", 1, "")
end

----- D�sinstallation TripInfo
function sc_DesinstallationTripInfo_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want uninstall"))
    newMsgBox.set_line(2, m_i18n("Trip info ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallationTripInfo", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstallationTripInfo()
    local params = "//navi_rw//utility//GestNav4//DesinstallationTripInfoStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation TripInfo
function sc_InstallationTripInfo_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Trip info ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationTripInfo", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationTripInfo()
    local params = "//navi_rw//utility//GestNav4//InstallationTripInfoStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------SpeedAltitude
createState("st_SpeedAltitude")
st_SpeedAltitude:useLayers(backgroundLayers, "ui_SpeedAltitudeList", "ui_List_Background")
function st_SpeedAltitude.init()
    txtTitle.TEXT = m_i18n("Speed Altitude")
end

function sc_SpeedAltitude_OnRelease()
    sc_NextStateAnim(st_SpeedAltitude, "horz_scroll", 1, "")
end

----- D�sinstallation SpeedAltitude
function sc_DesinstallationSpeedAltitude_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want uninstall"))
    newMsgBox.set_line(2, m_i18n("Speed Altitude ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallationSpeedAltitude", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstallationSpeedAltitude()
    local params = "//navi_rw//utility//GestNav4//DesinstallationVitesse_AltitudeStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation SpeedAltitude
function sc_InstallationSpeedAltitude_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Speed Altitude ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationSpeedAltitude", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationSpeedAltitude()
    local params = "//navi_rw//utility//GestNav4//InstallationVitesse_AltitudeStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------DayNight
createState("st_DayNight")
st_DayNight:useLayers(backgroundLayers, "ui_DayNightList", "ui_List_Background")
function st_DayNight.init()
    txtTitle.TEXT = m_i18n("Day Night")
end

function sc_DayNight_OnRelease()
    sc_NextStateAnim(st_DayNight, "horz_scroll", 1, "")
end

----- D�sinstallation DayNight
function sc_DesinstallationDayNight_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want uninstall"))
    newMsgBox.set_line(2, m_i18n("Day Night ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallationDayNight", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstallationDayNight()
    local params = "//navi_rw//utility//GestNav4//DesinstallationDay_NightStd.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation DayNight
function sc_InstallationDayNight_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Day Night ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationDayNight", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationDayNight()
    local params = "//navi_rw//utility//GestNav4//InstallationDay_Night.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----------JunctionView
createState("st_JunctionView")
st_JunctionView:useLayers(backgroundLayers, "ui_JunctionViewList", "ui_List_Background")
function st_JunctionView.init()
    txtTitle.TEXT = m_i18n("Junction View")
end

function sc_JunctionView_OnRelease()
    sc_NextStateAnim(st_JunctionView, "horz_scroll", 1, "")
end

----- D�sinstallation JunctionView
function sc_DesinstallationJunctionView_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want uninstall"))
    newMsgBox.set_line(2, m_i18n("Mini Junction View ?"))
    newMsgBox.setup_button(1, "sc_OkDesinstallationJunctionView", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkDesinstallationJunctionView()
    local params = "//navi_rw//utility//GestNav4//DesinstallationJunction_View.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation JunctionView
function sc_InstallationJunctionView_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("Mini Junction View ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationJunctionView", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationJunctionView()
    local params = "//navi_rw//utility//GestNav4//InstallationJunction_View.sh " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

---------------------------------Changement des polices d'�criture LG-----------------------------

createState("st_FontLG")
st_FontLG:useLayers(backgroundLayers, "ui_InstallationFont_List", "ui_List_Background")
function st_FontLG.init()
    txtTitle.TEXT = m_i18n("Installation Font LG")
end

function sc_FontLG_OnRelease()
    sc_NextStateAnim(st_FontLG, "horz_scroll", 1, "")
end

----- Installation Font Algerian
function sc_InstallationFontAlgerian_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Algerian ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontAlgerian", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontAlgerian()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Algerian " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Sugar
function sc_InstallationFontSugar_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Sugar ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontSugar", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontSugar()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Sugar " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Airstream
function sc_InstallationFontAirstream_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Airstream ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontAirstream", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontAirstream()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Airstream " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Originale
function sc_InstallationFontOriginal_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Original ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontOriginale", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontOriginale()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Original " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso1
function sc_InstallationFontPerso1_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontPerso1", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontPerso1()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Perso1 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso2
function sc_InstallationFontPerso2_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontPerso2", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontPerso2()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Perso2 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso3
function sc_InstallationFontPerso3_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontPerso3", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontPerso3()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Perso3 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso4
function sc_InstallationFontPerso4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontPerso4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontPerso4()
    local params = "//navi_rw//utility//GestNav4//InstallationFont.sh Perso4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

---------------------------------Changement des polices d'�criture GPS-----------------------------
createState("st_FontGPS")
st_FontGPS:useLayers(backgroundLayers, "ui_InstallationFontGPS_List", "ui_List_Background")
function st_FontGPS.init()
    txtTitle.TEXT = m_i18n("Installation Font GPS")
end

function sc_FontGPS_OnRelease()
    sc_NextStateAnim(st_FontGPS, "horz_scroll", 1, "")
end

----- Installation Font Algerian
function sc_InstallationFontGPSAlgerian_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Algerian ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSAlgerian", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSAlgerian()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Algerian " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Sugar
function sc_InstallationFontGPSSugar_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Sugar ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSSugar", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSSugar()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Sugar " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Airstream
function sc_InstallationFontGPSAirstream_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Airstream ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSAirstream", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSAirstream()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Airstream " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Originale
function sc_InstallationFontGPSOriginal_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Font Original ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSOriginale", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSOriginale()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Original " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso1
function sc_InstallationFontGPSPerso1_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSPerso1", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSPerso1()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Perso1 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso2
function sc_InstallationFontGPSPerso2_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSPerso2", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSPerso2()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Perso2 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso3
function sc_InstallationFontGPSPerso3_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSPerso3", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSPerso3()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Perso3 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

----- Installation Font Perso4
function sc_InstallationFontGPSPerso4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want install"))
    newMsgBox.set_line(2, m_i18n("your Personal Font ?"))
    newMsgBox.setup_button(1, "sc_OkInstallationFontGPSPerso4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkInstallationFontGPSPerso4()
    local params = "//navi_rw//utility//GestNav4//InstallationFontGPS.sh Perso4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------Bouton accepter automatique
function sc_BoutonAccepterNavigation_OnRelease()
    sc_NextStateAnim(st_BoutonAccepterNavigation, "horz_scroll", 1, "")
end
createState("st_BoutonAccepterNavigation")
st_BoutonAccepterNavigation:useLayers(backgroundLayers, "ui_BoutonAccepterNavigation", "ui_List_Background")
function st_BoutonAccepterNavigation.init()
    txtTitle.TEXT = m_i18n("Button accept navigation")
end

function sc_InstallationBoutonAccepterNavigation()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Button accept automatic ?"))
    newMsgBox.setup_button(1, "sc_OkInstallButtonAccept", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallButtonAccept()
    local params = "//navi_rw//utility//GestNav4//BoutonAccepter.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationBoutonAccepterNavigation()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("Button accept automatic ?"))
    newMsgBox.setup_button(1, "sc_OkDesnstallButtonAccept", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesnstallButtonAccept()
    local params = "//navi_rw//utility//GestNav4//BoutonAccepter.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------Code Authentification
function sc_CodeAuthentification_OnRelease()
    sc_NextStateAnim(st_CodeAuthentification, "horz_scroll", 1, "")
end
createState("st_CodeAuthentification")
st_CodeAuthentification:useLayers(backgroundLayers, "ui_CodeAuthentification", "ui_List_Background")
function st_CodeAuthentification.init()
    txtTitle.TEXT = m_i18n("Authentication code")
end

function sc_InstallationCodeAuthentification()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Authentication code ?"))
    newMsgBox.setup_button(1, "sc_VerifInstallCodeAuthentification", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_VerifInstallCodeAuthentification()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Have you entered YOUR CODE correctly in the file Authentication_Screen.qml"))
    newMsgBox.set_line(2, m_i18n("in Installation_utilisateur code_authentification ?"))
    newMsgBox.setup_button(1, "sc_OkInstallCodeAuthentification", m_i18n("Yes"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("No"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallCodeAuthentification()
    local params = "//navi_rw//utility//GestNav4//CodeAuthentification.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationCodeAuthentification()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("Authentication code ?"))
    newMsgBox.setup_button(1, "sc_OkDesnstallCodeAuthentification", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesnstallCodeAuthentification()
    local params = "//navi_rw//utility//GestNav4//CodeAuthentification.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

---------------------------- Favoris Adac

createState("st_AdacLG")
st_AdacLG:useLayers(backgroundLayers, "ui_AdacLGList", "ui_List_Background")
function st_AdacLG.init()
    txtTitle.TEXT = m_i18n("Adac")
end

function sc_AdacLG_OnRelease()
    sc_NextStateAnim(st_AdacLG, "horz_scroll", 1, "")
end

function sc_AdacLG_Favori1_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 1 reversing radar image"))
    newMsgBox.setup_button(1, "sc_OkAdacLG_Favori1", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkAdacLG_Favori1()
    local params = "//navi_rw//utility//GestNav4//InstallationAdacLG.sh Favori1 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_AdacLG_Favori2_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 2 reversing radar image"))
    newMsgBox.setup_button(1, "sc_OkAdacLG_Favori2", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkAdacLG_Favori2()
    local params = "//navi_rw//utility//GestNav4//InstallationAdacLG.sh Favori2 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_AdacLG_Favori3_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 3 reversing radar image"))
    newMsgBox.setup_button(1, "sc_OkAdacLG_Favori3", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkAdacLG_Favori3()
    local params = "//navi_rw//utility//GestNav4//InstallationAdacLG.sh Favori3 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_AdacLG_Favori4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 4 reversing radar image"))
    newMsgBox.setup_button(1, "sc_OkAdacLG_Favori4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkAdacLG_Favori4()
    local params = "//navi_rw//utility//GestNav4//InstallationAdacLG.sh Favori4 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

---------------------------- Favoris Ringstones

createState("st_RingstonesLG")
st_RingstonesLG:useLayers(backgroundLayers, "ui_RingstonesLGList", "ui_List_Background")
function st_RingstonesLG.init()
    txtTitle.TEXT = m_i18n("Ringstones")
end

function sc_RingstonesLG_OnRelease()
    sc_NextStateAnim(st_RingstonesLG, "horz_scroll", 1, "")
end

function sc_RingstonesLG_Favori1_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 1 phone ringtone"))
    newMsgBox.setup_button(1, "sc_OkRingstonesLG_Favori1", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRingstonesLG_Favori1()
    local params = "//navi_rw//utility//GestNav4//InstallationRingstonesLG.sh Favori1 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_RingstonesLG_Favori2_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 2 phone ringtone"))
    newMsgBox.setup_button(1, "sc_OkRingstonesLG_Favori2", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRingstonesLG_Favori2()
    local params = "//navi_rw//utility//GestNav4//InstallationRingstonesLG.sh Favori2 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_RingstonesLG_Favori3_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Personal 3 phone ringtone"))
    newMsgBox.setup_button(1, "sc_OkRingstonesLG_Favori3", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRingstonesLG_Favori3()
    local params = "//navi_rw//utility//GestNav4//InstallationRingstonesLG.sh Favori3 " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_RingstonesLG_Favori4_OnRelease()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Original phone ringtone"))
    newMsgBox.setup_button(1, "sc_OkRingstonesLG_Favori4", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_OkRingstonesLG_Favori4()
    local params = "//navi_rw//utility//GestNav4//InstallationRingstonesLG.sh Original " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------Acces Map
function sc_AccesMap_OnRelease()
    sc_NextStateAnim(st_AccesMap, "horz_scroll", 1, "")
end
createState("st_AccesMap")
st_AccesMap:useLayers(backgroundLayers, "ui_AccesMap", "ui_List_Background")
function st_AccesMap.init()
    txtTitle.TEXT = m_i18n("Access to the map if Eco mode")
end

function sc_InstallationAccesMap()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Access to the map if Eco mode ?"))
    newMsgBox.setup_button(1, "sc_OkInstallAccesMap", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallAccesMap()
    local params = "//navi_rw//utility//GestNav4//AccesMap.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationAccesMap()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("Access to the map if Eco mode ?"))
    newMsgBox.setup_button(1, "sc_OkDesnstallAccesMap", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesnstallAccesMap()
    local params = "//navi_rw//utility//GestNav4//AccesMap.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------Acces Map d�marrage

createState("-replace-", st_Start, {
    extends = st_Start,
    init = function()
        ui.vSynctoolStatus = MODEL.other.check_synctool()
        MODEL.mydata.history.sort_by_lasttime()
        sc_loading_finished()
    end
})
function sc_loading_finished()
    MODEL.other.loading_finished = true
    startUp = false
	MODEL.other.create_process(true,L"//bin//bash",L"",L"//navi_rw//utility//GestNav4//loading_finished.sh",false)
end

function sc_Acces_loading_finished_OnRelease()
    sc_NextStateAnim(st_Acces_loading_finished, "horz_scroll", 1, "")
end
createState("st_Acces_loading_finished")
st_Acces_loading_finished:useLayers(backgroundLayers, "ui_Acces_loading_finished", "ui_List_Background")
function st_Acces_loading_finished.init()
    txtTitle.TEXT = m_i18n("Start on the map")
end

function sc_InstallationAcces_loading_finished()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("Start on the map ?"))
    newMsgBox.setup_button(1, "sc_OkInstallAcces_loading_finished", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallAcces_loading_finished()
    local params = "//navi_rw//utility//GestNav4//Acces_loading_finished.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationAcces_loading_finished()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("Start on the map ?"))
    newMsgBox.setup_button(1, "sc_OkDesnstallAcces_loading_finished", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesnstallAcces_loading_finished()
    local params = "//navi_rw//utility//GestNav4//Acces_loading_finished.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

-------------------------------Bouton Car Size
function sc_CarSize_OnRelease()
    sc_NextStateAnim(st_CarSize, "horz_scroll", 1, "")
end
createState("st_CarSize")
st_CarSize:useLayers(backgroundLayers, "ui_CarSize", "ui_List_Background")
function st_CarSize.init()
    txtTitle.TEXT = m_i18n("ux car size")
end

function sc_InstallationCarSize()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to install"))
    newMsgBox.set_line(2, m_i18n("ux car size ?"))
    newMsgBox.setup_button(1, "sc_OkInstallCarSize", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkInstallCarSize()
    local params = "//navi_rw//utility//GestNav4//CarSize.sh installation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end

function sc_DesinstallationCarSize()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Do you want to uninstall"))
    newMsgBox.set_line(2, m_i18n("ux car size ?"))
    newMsgBox.setup_button(1, "sc_OkDesnstallCarSize", m_i18n("Ok"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end
function sc_OkDesnstallCarSize()
    local params = "//navi_rw//utility//GestNav4//CarSize.sh desinstallation " .. tostring(sc_GetMedia(MODEL.other.lg_renault.media_type()))
    MODEL.other.create_process(true, L"//bin//bash", L"", towstring(params), false)
    sc_DoExit()
end
