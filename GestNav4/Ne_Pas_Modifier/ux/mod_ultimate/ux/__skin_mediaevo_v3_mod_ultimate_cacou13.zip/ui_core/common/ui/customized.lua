-- Modif Hb31 Bouton Day Night
st_EasyNav:useLayers(primary, "ui_JourNuit")
sc_day_night = function()
     if MODEL.screen.nightmode() then
        MODEL.screen.nightmode = false
     else
        MODEL.screen.nightmode = true
     end
end

gSimControlsFadeDelayID = -1
gSimControlsVisibilityDelayID = -1
-- Fin Modif


-- File name: customized.lua
function sc_start_customize()
  MODEL.warning.speedwarn_alt_toltype = 0
end

sc_set_MAPresolution()

-- 1052
function sc_SB_DefineHomeWork()
  MODEL.poi.flat_search.list.index = MODEL["*"]._index()
  Monnomfav = MODEL["*"].name()
--  MODEL.screen.msgbox.new.setup(3)
  MODEL.screen.msgbox.new.setup(2)
  MODEL.screen.msgbox.new.set_line(1, m_i18n("Associate this favourite with the button :"))
  MODEL.screen.msgbox.new.set_line_wstr(2, Monnomfav)
  MODEL.screen.msgbox.new.setup_button(1, "sc_SB_DefineHome", m_i18n("Home"), L"", "ico_m_hm.bmp#3")
  MODEL.screen.msgbox.new.setup_button(2, "sc_SB_DefineWork", m_i18n("Work"), L"", "ico_m_wrk.bmp#3")
--  MODEL.screen.msgbox.new.setup_button(3, "", m_i18n("Cancel"), L"", "ico_cancel_mid.bmp#3")
  MODEL.screen.msgbox.create_new()
end
-- 1064
function sc_SB_DefineHome()
  MODEL.lua.SBHome = Monnomfav
end
-- 1068
function sc_SB_DefineWork()
  MODEL.lua.SBWork = Monnomfav
end
-- 1072
gContactsSearchStateisEnteredSHW = false
createState("st_ManageContactsSHW")
st_ManageContactsSHW:useLayers(backgroundLayers, "ui_ManageContactsSHW", "ui_List_Background")
function st_ManageContactsSHW.init()
  txtTitle.TEXT = m_i18n("Contacts")
  g_OnPoiListItemClicked = sc_FlatSearch_OnPoiItemClicked
  isFromFavorite = false
end
-- 1081
function st_ManageContactsSHW.enter()
  gContactsSearchStateisEnteredSHW = true
  MODEL.lua.PoiListFilterString = L""
  MODEL.poi.flat_search.ext_name_filter.name = L""
  sc_SearchContacts()
end
-- 1088
function st_ManageContactsSHW.exit()
  gContactsSearchStateisEnteredSHW = false
  isFromFavorite = false
  obs_poi_filter_search_done:STOP()
end
-- 1094
function sc_map_local_menu_ContactsSHW()
  MODEL.lua.SBFAVNOCNT = false
  gSearchEngineIsInitialized = false
  sc_ForcePoiInit()
  sc_NextStateAnim(st_ManageFavoriteSHW, "horz_scroll", 1, "")
end
-- 1101
gFavoritesSearchStateisEnteredSHW = false
createState("st_ManageFavoriteSHW")
st_ManageFavoriteSHW:useLayers(backgroundLayers, "ui_ManageFavoriteSHW", "ui_List_Background")
function st_ManageFavoriteSHW.init()
  if MODEL.lua.SBFAVNOCNT() == true then
    txtTitle.TEXT = m_i18n("Favourites")
  else
    txtTitle.TEXT = m_i18n("Contacts")
  end
  g_OnPoiListItemClicked = sc_FlatSearch_OnPoiItemClicked
  isFromFavorite = false
end
-- 1114
function st_ManageFavoriteSHW.enter()
  gFavoritesSearchStateisEnteredSHW = true
  MODEL.lua.PoiListFilterString = L""
  MODEL.poi.flat_search.ext_name_filter.name = L""
  if MODEL.lua.SBFAVNOCNT() == true then
    sc_SearchFavorites()
  else
    sc_SearchContacts()
  end
end

-- 1125
function st_ManageFavoriteSHW.exit()
  gFavoritesSearchStateisEnteredSHW = false
  isFromFavorite = false
  obs_poi_filter_search_done:STOP()
  obs_poi_filter_struct_search_done:STOP()
end

-- 1132
function sc_map_local_menu_favoriteSHW()
  MODEL.lua.SBFAVNOCNT = true
  gSearchEngineIsInitialized = false
  sc_ForcePoiInit()
  sc_NextStateAnim(st_ManageFavoriteSHW, "horz_scroll", 1, "")
end

-- 1139
createState("st_SelectHomeWork")
st_SelectHomeWork:useLayers(backgroundLayers, "ui_SelectHomeWork", "ui_AnimationNom", "ui_List_Background")
function st_SelectHomeWork.init()
  txtTitle.TEXT = m_i18n("Select Home/Work")
end

-- 1145
function sc_sb_SelectHomeWork()
  sc_NextStateAnim(st_SelectHomeWork, "horz_scroll", 1, "")
end

-- 1150
function sc_SB_VerifracFav(montext)
  if MODEL.lua.SBHome() == Monnomrac then
    MODEL.lua.SBHome = montext
  elseif MODEL.lua.SBWork() == Monnomrac then
    MODEL.lua.SBWork = montext
  end
end

-- 1158
function sc_SB_DelracFav()
  if MODEL.lua.SBHome() == Monnomrac then
    MODEL.lua.SBHome = L""
  elseif MODEL.lua.SBWork() == Monnomrac then
    MODEL.lua.SBWork = L""
  end
end

-- 1166
function sc_SB_DeleteAllrac()
  MODEL.lua.SBHome = L""
  MODEL.lua.SBWork = L""
end

-- 1171
function sc_SB_RacDel_OnRelease(monnum)
  if monnum == 1 then
    Monnomrac = MODEL.lua.SBHome()
  elseif monnum == 2 then
    Monnomrac = MODEL.lua.SBWork()
  end
  if Monnomrac ~= L"" then
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Are you sure you want to cancel shortcut?"))
    newMsgBox.set_line_wstr(2, Monnomrac)
    newMsgBox.setup_button(1, "sc_SB_DelracFav2", m_i18n("Delete"), L"", "ico_del_sml.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), L"", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
  end
end

-- 1188
function sc_SB_DelracFav2()
  sc_SB_DelracFav()
  btnHW1:REDRAW()
  btnHW2:REDRAW()
end

--4052
createState("st_paramSkin")

st_paramSkin:useLayers(backgroundLayers, "ui_paramskin", "ui_ExeOut", "ui_AnimationLogo", "ui_List_Background")

--4055
function st_paramSkin.init()
  txtTitle.TEXT = m_i18n("Skin settings")
end

--4059
function sc_Paramskin_OnRelease()
  sc_NextStateAnim(st_paramSkin, "horz_scroll", 1, "")
end

--4083
createState("st_transparence")

st_transparence:useLayers(backgroundLayers, "ui_transparence", "ui_AnimationNom", "ui_List_Background")

st_transparence.init = function()
  txtTitle.TEXT = m_i18n("Transparency Settings")
end

--4089
function sc_sb_Transparence_OnRelease()
  sc_NextStateAnim(st_transparence, "horz_scroll", 1, "")
end

-- 4339
function sc_SearchHomeWork(mavar)
  local sbTmphomework = var.new()
  if mavar == 1 then
    sbTmphomework = sc_GetSysEntry("homework", "1", "MAISON")
  else
    sbTmphomework = sc_GetSysEntry("homework", "2", "TRAVAIL")
  end
  sc_DeleteRoute()
  MODEL.poi.copy_query("poi.struct_search", "poi.flat_search", 1)
  local flat_search = MODEL.poi.flat_search
  flat_search.sort = MODEL.poi.struct_search.sort()
  flat_search.reset()
  flat_search.area = 3000000
  flat_search.center = "gps"
  flat_search.distance_on_route = "disabled"
  flat_search.calculate_detour = "disabled"
  flat_search.search_root = MODEL.poi.find_group("@Favourites")
  inpSI_Text:VALUE(sbTmphomework)
  flat_search.name_filter = ui.inpSI_Text.VALUE()
  flat_search.execute()
  if flat_search.list.size() > 0 then
    for item,index in ModelList_iter(MODEL.poi.flat_search.list) do
      if item.name() == ui.inpSI_Text.VALUE() then
        MODEL.my.poi.select_poi(item.provider_id(), item.id())
        MODEL.map.cursor.position = MODEL.my.map.selected_item.position()
        MODEL.poi.resultpoi.clear()
        MODEL.poi.resultpoi.add_poi_by_id(item.provider_id(), item.id())
        isFromFavorite = true
        PoiSelected = true
        sc_EasyRouteTo()
        sc_GO_onrelease()
        return
      end
    end
  else
    sc_InfoMessageBox(m_i18n("Favourite not found."))
    return
  end
  sc_InfoMessageBox(m_i18n("Favourite not found."))
end

-- 4392
function sc_SearchHomeWork(mavar)
  local sbTmphomework = var.new()
  sc_DeleteRoute()
  MODEL.poi.copy_query("poi.struct_search", "poi.flat_search", 1)
  local flat_search = MODEL.poi.flat_search
  flat_search.sort = MODEL.poi.struct_search.sort()
  flat_search.reset()
  flat_search.area = 3000000
  flat_search.center = "gps"
  flat_search.distance_on_route = "disabled"
  flat_search.calculate_detour = "disabled"
  flat_search.search_root = MODEL.poi.find_group("@Favourites")
  if mavar == 1 then
    inpSI_Text:VALUE(MODEL.lua.SBHome())
  elseif mavar == 2 then
    inpSI_Text:VALUE(MODEL.lua.SBWork())
  elseif mavar == 3 then
    inpSI_Text:VALUE(L"POSCAR")
  end
  flat_search.name_filter = ui.inpSI_Text.VALUE()
  flat_search.execute()
  if flat_search.list.size() > 0 then
    for item,index in ModelList_iter(MODEL.poi.flat_search.list) do
      if item.name() == ui.inpSI_Text.VALUE() then
        MODEL.my.poi.select_poi(item.provider_id(), item.id())
        MODEL.map.cursor.position = MODEL.my.map.selected_item.position()
        MODEL.poi.resultpoi.clear()
        MODEL.poi.resultpoi.add_poi_by_id(item.provider_id(), item.id())
        isFromFavorite = true
        PoiSelected = true
        sc_EasyRouteTo()
        sc_GO_onrelease()
        return
      end
    end
  else
    flat_search.sort = MODEL.poi.struct_search.sort()
    flat_search.reset()
    flat_search.area = 3000000
    flat_search.center = "gps"
    flat_search.distance_on_route = "disabled"
    flat_search.calculate_detour = "disabled"
    flat_search.search_root = MODEL.poi.find_group("Contacts")
    flat_search.name_filter = ui.inpSI_Text.VALUE()
    flat_search.execute()
    if flat_search.list.size() > 0 then
      for item,index in ModelList_iter(MODEL.poi.flat_search.list) do
        if item.name() == ui.inpSI_Text.VALUE() then
          MODEL.my.poi.select_poi(item.provider_id(), item.id())
          MODEL.map.cursor.position = MODEL.my.map.selected_item.position()
          MODEL.poi.resultpoi.clear()
          MODEL.poi.resultpoi.add_poi_by_id(item.provider_id(), item.id())
          isFromFavorite = true
          PoiSelected = true
          sc_EasyRouteTo()
          sc_GO_onrelease()
          return
        end
      end
    else
      sc_InfoMessageBox(m_i18n("Favourite not found."))
      return
    end
  end
  sc_InfoMessageBox(m_i18n("Favourite not found."))
end

-- 4459
function sc_SB_CreateTextHome()
  if MODEL.lua.SBHome() == L"" then
    return m_i18n("Home button : Not selected")
  else
    local text = translated_format(m_i18n("Home button : %s"), MODEL.lua.SBHome())
    return text
  end
end

-- 4468
function sc_SB_CreateTextWork()
  if MODEL.lua.SBWork() == L"" then
    return m_i18n("Work button : Not selected")
  else
    local text = translated_format(m_i18n("Work button : %s"), MODEL.lua.SBWork())
    return text
  end
end

--4745
function sc_Bd_Colors_settings()
  sc_NextStateAnim(st_Bd_Colors_settings, "horz_scroll", 1, "")
end

--4749
createState("st_Bd_Colors_settings")

st_Bd_Colors_settings:useLayers(backgroundLayers, "ui_Bd_Colors_settings", "ui_AnimationNom", "ui_List_Background")

--4752
function st_Bd_Colors_settings.init()
  txtTitle.TEXT = m_i18n("Colors settings")
end

--4816
function sc_Bd_set_Colors()
txt_Bd_ArrowColor:TEXT(tostring(MODEL.lua.BdArrowColor()))
txt_Bd_Arrow2Color:TEXT(tostring(MODEL.lua.BdArrow2Color()))
end

--4824
function sc_Bd_set_transparence()
  txt_TransButtonArrow:TEXT(tostring(MODEL.lua.TransButtonArrow()))
  txt_TransButtonAltitude:TEXT(tostring(MODEL.lua.TransButtonAltitude()))
end

-- 5495
function sc_BdChangeColorSpeed()
  if not MODEL.screen.nightmode() then
	if MODEL.lua.SpeedInfoColorD() == 1 then
	MODEL.lua.SpeedInfoColorD = 2
	elseif MODEL.lua.SpeedInfoColorD() == 2 then
	MODEL.lua.SpeedInfoColorD = 3
	elseif MODEL.lua.SpeedInfoColorD() == 3 then
	MODEL.lua.SpeedInfoColorD = 4
	elseif MODEL.lua.SpeedInfoColorD() == 4 then
	MODEL.lua.SpeedInfoColorD = 5
	elseif MODEL.lua.SpeedInfoColorD() == 5 then
	MODEL.lua.SpeedInfoColorD = 6
	elseif MODEL.lua.SpeedInfoColorD() == 6 then
	MODEL.lua.SpeedInfoColorD = 1
	else
	MODEL.lua.SpeedInfoColorD = 1
	end
  elseif MODEL.screen.nightmode() then
	if MODEL.lua.SpeedInfoColorN() == 1 then
	MODEL.lua.SpeedInfoColorN = 2
	elseif MODEL.lua.SpeedInfoColorN() == 2 then
	MODEL.lua.SpeedInfoColorN = 3
	elseif MODEL.lua.SpeedInfoColorN() == 3 then
	MODEL.lua.SpeedInfoColorN = 4
	elseif MODEL.lua.SpeedInfoColorN() == 4 then
	MODEL.lua.SpeedInfoColorN = 5
	elseif MODEL.lua.SpeedInfoColorN() == 5 then
	MODEL.lua.SpeedInfoColorN = 6
	elseif MODEL.lua.SpeedInfoColorN() == 6 then
	MODEL.lua.SpeedInfoColorN = 1
	else
	MODEL.lua.SpeedInfoColorN = 1
	end
  end
end