-- Version ini **********

function sc_InfoIni()
    txtTitle.TEXT = m_i18n("Information")
    sc_NextStateAnim(st_InfoIni, "horz_scroll", 1, "")
end    

createState("st_InfoIni")
st_InfoIni:useLayers(backgroundLayers, ui_AnimationLogo, ui_InfoIni)


-- UTILISATION DE LA MEMOIRE **********
function sc_Memory_Onrelease()
  txtTitle.TEXT = m_i18n("About memory")
  sc_NextStateAnim(st_AboutMemory, "horz_scroll", 1, "")
end

createState("st_AboutMemory")
st_AboutMemory:useLayers(backgroundLayers, ui_AnimationLogo, ui_AboutMemory)
-- **********
-- MENU PARAMETRES DES ALERTES
function sc_btnSR_MenuWarnings_OnRelease ()
    sc_NextStateAnim(st_MenuWarningsSettings, "horz_scroll", 1, "")
end

createState("st_MenuWarningsSettings")
st_MenuWarningsSettings:useLayers(backgroundLayers, "ui_MenuWarnings", "ui_AnimationNom", "ui_List_Background")
function st_MenuWarningsSettings.init()
    txtTitle.TEXT = m_i18n("Alerts Settings")
end