MODEL.SETPERSISTENT.lua.vitesse = BOOL_MODEL(true)
st_EasyNav:useLayers("ui_vitesse")

