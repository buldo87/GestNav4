MODEL.SETPERSISTENT.lua.Altitude = BOOL_MODEL(true)
st_EasyNav:useLayers("ui_Altitude")