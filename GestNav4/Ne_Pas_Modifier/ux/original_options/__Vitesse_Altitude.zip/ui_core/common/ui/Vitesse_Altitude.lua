MODEL.SETPERSISTENT.lua.VitesseAltitude = BOOL_MODEL(true)
