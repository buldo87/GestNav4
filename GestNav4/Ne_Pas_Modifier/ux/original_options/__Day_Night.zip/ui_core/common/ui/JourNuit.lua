MODEL.SETPERSISTENT.lua.JourNuit = BOOL_MODEL(true)
st_EasyNav:useLayers(primary, "ui_JourNuit")

-- Modif Hb31 Bouton Day Night

sc_day_night = function()
     if MODEL.screen.nightmode() then
        MODEL.screen.nightmode = false
     else
        MODEL.screen.nightmode = true
     end
end

gSimControlsFadeDelayID = -1
gSimControlsVisibilityDelayID = -1




-- Fin Modif