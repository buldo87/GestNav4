MODEL.SETPERSISTENT.lua.APVehicle_size = INT_MODEL(120)
MODEL.SETPERSISTENT.lua.CarZoomMode = BOOL_MODEL(false)

sc_vehicle_size = function()
  MODEL.map.car_display.map_scale = MODEL.lua.APVehicle_size()
end
 
gCarZoomModeTimeOutID = -1
sc_CarZoomMode_On = function()
  MODEL.lua.CarZoomMode = true
  sc_SetCarZoomMode_TimeOut()
end
 
sc_CarZoomMode_Off = function()
  MODEL.lua.CarZoomMode = false
  sc_vehicle_size()
end
 
sc_CarZoomChanged = function()
  sc_vehicle_size()
end
 
sc_SetCarZoomMode_TimeOut = function()
  killDelayed(gCarZoomModeTimeOutID)
  gCarZoomModeTimeOutID = doDelayed(500, sc_CarZoomMode_Off)
end

sc_CarSize_Reset = function()
  MODEL.lua.APVehicle_size = 120
end