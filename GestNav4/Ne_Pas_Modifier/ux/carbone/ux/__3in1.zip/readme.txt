3in1 ***************************************************************************
This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

Historique des versions

4.7 05/05/2024 insertion trad allemand faite par Vukasin

4.6 06/10/2017 adaptation pour carbone, MsieurLolo
-----------------------
4.5   10/04/2015  THL
- Correction : de l'affichage de l'heure d'arriv�e en haut � droite du bouton "3 en 1".
- Am�lioration : en cas d'absence d'itin�raire actif, le format compact reconduit le contexte d'affichage du skin de la DreamTeam selon la valeur donn�e au param�tre "Plus../R�glages/Param�tres du skin/Navigation/3 infos dans un seul bouton".
- Am�lioration : activation automatique de la possibilit� de choisir d'afficher une boussole lin�aire dans l'un des boutons d'information. Auparavant, il fallait activer cette possibilit� au niveau du param�tre situ� dans le menu "Extras" (Plus.../R�glages/Param�tres du skin/Extras/Boussole lin�aire).
- Ajout : [stelna971] de l'affichage de l'azimut dans l'information du bas du bouton "3 en 1" et dans les boutons d'information �tendus selon les choix effectu�s dans le menu de gestion des informations � afficher (acc�s par un appui long sur un des boutons d'information).
- Ajout : indicateur au centre de la boussole lin�aire.
- Ajout : sigle (W vs O) de la direction "Ouest" de la boussole lin�aire adapt� en fonction de la langue active.

4.4   07/12/2014  THL
- Ajout : [softsoft] Support de la r�solution d'�cran 400_240.
- Am�lioration : positionnement de l'heure d'arriv�e en haut � gauche du bouton "3 en 1".

4.3   30/08/2014  THL
- Modification : Le format de l'information de distance a �t� modifi� pour permettre son affichage sur les version Primo 2.0. Cette modification conduit � ce que l'unit� de distance (km ou m) n'est plus affich�e en exposant (en haut) mais en indice (en bas).
- Modification : L'affichage du temps restant adopte un format d'affichage variant en fonction de sa valeur. "SS sec" jusqu'� 59 secondes, "MN min" jusqu'� 59 minutes et "HH:MN" au del�.

4.2   05/08/2014  THL
- Optimisation : transfert des fichiers navigatemap.ui vers \common\ui
- Ajout : �cran "A propos" accessible par un appui long sur le bouton, ou la case � cocher, de la rubrique "Bouton 3 infos" du menu "R�glage du guidage visuel"

4.1   29/05/2014  THL
- Am�lioration : version "multi-r�solutions" regroupant dans un seul Mod les diff�rentes r�solutions d'�cran (320_240, 480_272 et 800_480).

4.0   16/02/2014  THL
- Modification : de la gestion du choix de l'information principale � afficher en bas du bouton "3 en 1".
- Am�lioration : possibilit� de choisir l'information principale � afficher en bas d'un bouton "3 en 1" parmi l'ensemble des informations possibles.

3.0   21/12/2013  THL
- Modification : transfert de la gestion du choix du type d'affichage dans le menu "R�glage du guidage visuel" avec cr�ation d'une ic�ne sp�cifique.
- Modification : des intitul�s des choix par ajout du suffixe "en bas" ("Distance restante en bas" ; "Horaire d'arriv�e en bas" ; "D�sactiv�")
- Modification : renommage du Mod UX avec le nom complet au lieu de son abr�viation et avec la r�solution pour laquelle il est d�velopp� en dernier.

2.0   03/11/2013  THL
- Modification : r�glages dans le menu "Extras" restreint au choix des deux nouveaux formats. Les choix d'origine DT sont � r�aliser dans le menu "Navigation" ; ils sont actifs si le r�glage "Bouton DreamTeam" est s�lectionn� dans le menu "Extras".
- Modification : renommage du Mod UX pour �tre conforme avec les conventions de nommage DT et pour le classement dans le menu "Extras".

1.1   01/11/2013  THL
- Modification : ajout du suffixe "(DT)"" dans l'affichage des choix d'origine du skin DT ("Avec itin�raire (DT)" et "Permanent (DT)").
- Am�lioration : traduction en fran�ais des libell�s utilis�s pour la configuration de la fonction dans le fichier "040c.lang".

1.0   21/09/2013  THL
- Version initiale bas�e sur le code du Mod Aldo51 4.0, notamment celles d�finissant la forme du bouton r�duit en fonction du choix d'afficher l'heure ou la distance en bas du bouton "3 en 1".

Description
-----------
Ce Mod UX ajoute un format d'affichage compact des informations figurant dans le bouton "3 en 1" de l'�cran de navigation lorsqu'un trajet est actif.
L'ensemble des informations principales sont possibles en bas du bouton "3 en 1" " : "Distance restante", "Heure d'arriv�e", "Dur�e restante", "Altitude", "Limite de vitesse", "Vitesse", "Boussole", "Heure"...

Installation
------------
Le fichier zip est � copier tel quel, sans le d�compresser et sans le renommer, dans le sous-r�pertoire UX.
Si le sous-r�pertoire UX n'existe pas, il doit �tre cr�� sous le r�pertoire principal dans lequel se situent le fichier ex�cutable de primo et le fichier data.zip.

Configuration
-------------
L'activation de la fonction est r�alis�e depuis le bouton de la rubrique [Bouton 3 infos] du menu "R�glage du guidage visuel" [Menu Navigation/Plus.../R�glages/R�glage du guidage visuel/Bouton 3 infos].

Selon le type d'appui sur l'intitul� de la rubrique [Bouton 3 infos]
  . court : active/d�sactive la fonction.
  . long : affiche l'�cran "A propos".

Lorsque l'affichage �tendu est activ�, un appui court sur une des trois informations permet de s�lectionner l'information principale � afficher en bas du bouton "3 en 1".

Utilisation
-----------
Si le bouton "3 en 1" est activ� sur l'�cran de navigation :
- Un appui court sur le bouton "3 en 1" �tend l'affichage en trois boutons avec une information par bouton ou, s'il est �tendu, le contracte en trois informations affich�es dans un seul bouton.
  . Le choix de l'information principale � afficher en bas du bouton "3 en 1" est effectu� par un appui court sur une des trois informations de l'affichage �tendu.
  . Lorsque la fonction est d�sactiv�e ou qu'il n'y pas d'itin�raire actif, le format compact reconduit le contexte d'affichage du skin de la DreamTeam selon la valeur donn�e au param�tre "Plus../R�glages/Param�tres du skin/Navigation/3 infos dans un seul bouton".
- Un appui long sur le bouton "3 en 1" permet d'acc�der � l'�cran de gestion des informations � afficher.
