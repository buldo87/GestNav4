-- 3in1 ************************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

-- Init ------------------------------------------------------------------------
st_EasyNav:removeLayers("ui_EasyNav_Cockpit")
st_EasyNav:useLayers("ui_EasyNav_THL_Cockpit")
MODEL.lua.linear_compass = true

-- Direction -------------------------------------------------------------------
sc_thl_3in1_Direction = function(azimuth)
  local direction1 = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SO", "OSO", "O", "ONO", "NO", "NNO"}
  local direction2 = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SW", "WSW", "W", "WNW", "NW", "NNW"}
  local direction = ""
  local index = (azimuth * 2 / 45) + 1
  if azimuth * 2 % 45 == 0 then
    if (MODEL.regional.units() == 1) then
      direction = direction1[index]
    else
      direction = direction2[index]
    end
  end
  return direction
end

-- About -----------------------------------------------------------------------
sc_thl_3in1_About = function()
  ui_xhtml_sublayer.FILENAME = "ui_core/" .. tostring(uiRes) .. "/ui/3in1_about.xhtml"
  sc_NextStateAnim(st_xhtml, "fade", 1, "")
  txtTitle.TEXT = "About"
end
