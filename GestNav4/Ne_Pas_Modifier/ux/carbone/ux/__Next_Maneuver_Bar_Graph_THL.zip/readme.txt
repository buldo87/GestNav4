Next Maneuver Bar Graph ********************************************************
This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

Historique des versions
-----------------------
6.7   25/04/2024 cacou13
- insertion trad allemand faite par Vukasin

6.6   20/02/2018 Buldo
- Adaptation pour Carbone

6.5   19/04/2015  THL
- Ajout : dans l'�cran de param�trage, du r�glage de la position du bargraphe dans la zone d'information de la prochaine manoeuvre.

6.4   18/12/2014  THL
- Ajout : [softsoft] Support de la r�solution d'�cran 400_240.
- Modification : nouvelle forme du bargraphe 3D.

6.3   28/09/2014  THL
- Ajout : [Miochacha / Cacou13] Choix entre un bargraphe au format 2D ou 3D dans le menu de configuration.

6.2   08/08/2014  THL
- Ajout : Bouton "A propos" en bas du menu de configuration.
- Modification : Simplification des intitul�s du menu de configuration.

6.1   15/05/2014  THL
- Modification : version "multi-r�solutions" regroupant dans un seul Mod UX les diff�rentes r�solutions d'�cran (320_240, 480_272 et 800_480).
- Modification : renommage du Mod UX de "Next Maneuver" en "Next Maneuver Bar Graph" pour le distinguer du Mod UX "Next Maneuver 2D Overview".

6.0   23/02/2014  THL
- Param�trage des 10 paliers du bargraphe dans un menu de configuration sp�cifique accessible depuis le bouton d'activation de la fonction.

5.0   23/12/2013  THL
- Optimisation de la gestion de la progression du bargraphe et impl�mentation de la comptabilit� avec la transparence de la zone de prochaine manoeuvre.
- Bargraphe positionn� en second plan par rapport aux fl�ches de direction de la prochaine manoeuvre.
- Renommage du Mod UX avec le nom complet.

4.0   23/12/2013  THL
- Am�lioration de la lin�arit� de la progression en rempla�ant les pourcentages par des valeurs fixes dans le fichier "NM_navigatemap.ui".
- Renommage du Mod UX pour que le nom se termine par la r�solution pour laquelle il est d�velopp�.

3.0   07/12/2013  THL
- Modification du fond de bargraphe pour qu'il se confonde avec celui de la zone "Prochaine Manoeuvre" lorsque la transparence est r�gl�e au minimum.

2.0   11/11/2013  THL
- Modification de la distance de d�but de la progression � 450 m.
- Renommage du Mod UX pour �tre conforme avec les conventions de nommage DT.

1.0   12/10/2013  THL
- Version initiale bas�e sur la fonction issue du skin de fmilan & amat�r.
- Cr�ation d'une ic�ne sp�cifique pour le menu "R�glage du guidage visuel".
Rem. Cette fonction est aussi int�gr�e dans le Mod Aldo51 4.0 pour le skin Sbertaud13 DreamTeam WinCE.

Description
-----------
Ce Mod UX permet d'ajouter un bargraphe d'approche de la prochaine manoeuvre � droite de la fl�che pr�cisant la direction de la prochaine manoeuvre.
Le bargraphe ajoute une composante visuelle graphique � l'indication de d�compte num�rique de distance du prochain changement de direction.
La couleur des dix constituants du bargraphe passe du vert fonc� au rouge fonc� au fur et � mesure de l'approche du prochain changement de direction.

Installation
------------
Le fichier zip est � copier tel quel, sans le d�compresser et sans le renommer, dans le sous-r�pertoire UX.
Si le sous-r�pertoire UX n'existe pas, il doit �tre cr�� sous le r�pertoire principal dans lequel se situent le fichier ex�cutable de primo et le fichier data.zip.

Configuration
-------------
L'activation de la fonction est r�alis�e depuis le bouton de la rubrique [Bargraphe de prochaine manoeuvre] du menu "R�glage du guidage visuel" [Menu Navigation/Plus.../R�glages/R�glage du guidage visuel/Bargraphe de prochaine manoeuvre].

Selon le type d'appui :

- sur l'intitul� de la rubrique [Bargraphe de prochaine manoeuvre]
  . court : active/d�sactive la fonction.
  . long : affiche l'�cran "A propos".

- sur la case � cocher d�sactiv�e (vide = fonction d�sactiv�e)
  . court : active la fonction.
  . long : d�sactive la fonction.

- sur la case � cocher activ�e (forme de liste de choix = fonction activ�e)
  . court : fait appara�tre l'�cran de param�trage des 10 paliers de distance du bargraphe et de choix du format du bargraphe (activ�, par d�faut = 3D, d�sactiv� = 2D)
            Les valeurs des paliers retenus sont arrondies pour tenir compte des valeurs de distance utilis�es par iGO Primo.
  . long : d�sactive la fonction.

Utilisation
-----------
L'�l�ment d'information visuel sous la forme d'un bargraphe 2D ou 3D, selon le choix effectu� dans le menu de configuration, vient en compl�ment du d�compte num�rique de distance du prochain changement de direction.
La fonction est op�rationnelle pour les modes navigation et simulation.
