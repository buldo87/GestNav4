Lane Settings ******************************************************************
This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.
Adapt� pour carbone par Jthiriet et Buldo
Historique des versions
-----------------------
1.5.3 05/05/2024 cacou13
insertion trad allemand faite par Vukasin

1.5.2 08/10/2017 Buldo
- Ajout du param�trage de la position junctionview pour carbone Gauche, Centre, Droite, Plein �cran
- correction bug affichage � droite

1.4   17/01/2015  THL
- Ajout : [softsoft] Support de la r�solution d'�cran 400_240.

1.3   13/09/2014  THL
- Modification : [Kamille] D�sactivation de la possibilit� de retourner � la ligne pour l'affichage des noms de fichiers sonore dans l'�cran de configuration.

1.2   27/08/2014  THL
- Ajout : Gestion de la transparence pour les deux types d'information directement dans le menu de configuration du Mod.
- Modification : Correction des conditions d'activation des r�glages de la notification sonore, du volume et du son dans les cas o� l'affichage est d�s�lectionn� pour le panneau de direction ou l'indicateur de voie.
- Modification : Remplacement du son "lane" de la notification sonore configur�e par d�faut par le son "!nav_ding". Le choix du son de notification reste possible.

1.1   22/07/2014  THL
- Modification : [Kamille] Syntaxe des formulations.
- Modification : [Kamille] R�glage par d�faut du volume de la notification sonore au maximum.
- Ajout : Bouton "A propos" en bas du menu de configuration.

1.0   13/07/2014  THL
- Version initiale r�pondant � une demande de Kamille. Ce Mod UX est inspir� du code du skin de Gurjon "gjak_1.09_P24_Salamander5a".

Description
-----------
Ce Mod UX permet la notification sonore lors de l'apparition d'un panneau d'indication de direction, comme, par exemple, les panneaux d'autoroute, ou d'un indicateur de voie en bas d'�cran de navigation.
De plus, il permet de choisir les types d'information � afficher (Panneau d'indication de direction et Indicateur de voie) en fonction du type de route (Autoroute ou route)

Installation
------------
Le fichier zip est � copier tel quel, sans le d�compresser et sans le renommer, dans le sous-r�pertoire UX.
Si le sous-r�pertoire UX n'existe pas, il doit �tre cr�� sous le r�pertoire principal dans lequel se situent le fichier ex�cutable de primo et le fichier data.zip.

Configuration
-------------
L'activation de la fonction est r�alis�e depuis le bouton de la rubrique [Panneaux d'indication de direction et de voie] du  menu "R�glage du guidage visuel" [Menu Navigation/Plus.../R�glages/R�glage du guidage visuel/Panneaux d'indication de direction et de voie].
Cette fonction se substitue � celle du skin DT intitul�e "Panneau" qui se limite � activer/d�sactiver l'affichage des Panneaux d'indication de direction.

Selon le type d'appui sur l'intitul� de la rubrique
  . court : acc�s aux param�tres de configuration.
  . long : affiche l'�cran "A propos".

Les param�tres de configuration permettent de choisir :
- par type d'information (Panneau d'indication de direction et Indicateur de voie), sur quel type de route (autoroute, route, tout type) les informations doivent �tre affich�es.
- le type d'information (Panneaux de direction, Indicateur de voie, tout type) devant faire l'objet d'une notification sonore.
- le message sonore parmi les fichiers sonores disponibles (son "!nav_ding" par d�faut) et son volume sonore.
- la gestion de la transparence des panneaux d'indication de direction et des indicateurs de voie, en parall�le de celle pr�sente dans le skin DT au niveau du menu "Transparence" [Menu Navigation/Plus.../R�glages/Param�tres du skin/Transparence/Panneau ; .../Lane Info].

Utilisation
-----------
Apr�s activation et en fonction des param�tres configur�s, les actions choisies sont visibles et audibles dans les modes navigation ou simulation.
