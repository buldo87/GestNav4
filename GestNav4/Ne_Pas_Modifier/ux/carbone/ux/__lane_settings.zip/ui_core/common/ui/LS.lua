-- Lane Settings ***************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.
-- Adapté pour carbone par Jthiriet et Buldo 
-- Settings --------------------------------------------------------------------

sc_thl_LS_Settings_OnRelease = function()
  sc_NextStateAnim(st_thl_LS_Settings, "horz_scroll", 1, "")
end

createState("st_thl_LS_Settings")
st_thl_LS_Settings:useLayers(backgroundLayers, "ui_thl_LS_Settings")
st_thl_LS_Settings.init = function()
  txtTitle:SET(m_i18n("Lane Settings"))
end

-- Panneau de direction
sc_thl_LS_Signpost_OnRelease = function()
  if MODEL.lua.thl_LS_Signpost() == 0 then
    MODEL.lua.thl_LS_SignpostRoad_Enable = false
    MODEL.lua.thl_LS_SignpostHighway_Enable = false
    MODEL.lua.SBSignpostOn = false
  elseif MODEL.lua.thl_LS_Signpost() == 1 then
    MODEL.lua.thl_LS_SignpostRoad_Enable = true
    MODEL.lua.thl_LS_SignpostHighway_Enable = false
    MODEL.lua.SBSignpostOn = true
  elseif MODEL.lua.thl_LS_Signpost() == 2 then
    MODEL.lua.thl_LS_SignpostRoad_Enable = false
    MODEL.lua.thl_LS_SignpostHighway_Enable = true
    MODEL.lua.SBSignpostOn = true
  elseif MODEL.lua.thl_LS_Signpost() == 3 then
    MODEL.lua.thl_LS_SignpostRoad_Enable = true
    MODEL.lua.thl_LS_SignpostHighway_Enable = true
    MODEL.lua.SBSignpostOn = true
  end
end
-- Panneau de direction
sc_SignPostLayerShow_orig = sc_SignPostLayerShow
sc_SignPostLayerShow = function()
  if ((MODEL.navigation.car.is_on_highway() and MODEL.lua.thl_LS_SignpostHighway_Enable()) or (not MODEL.navigation.car.is_on_highway() and MODEL.lua.thl_LS_SignpostRoad_Enable())) then
    if st_EasyNav.active and not MODEL.lua.SignpostIsValid() then
      MODEL.lua.SignpostIsValid = true
      ui_NavigateMapSingpost.Y = -vLaneInfoSignpostHeight() -----------
      ui_NavigateMapSingpost:YBLEND(0, 15) ------------------------
      ui_NavigateMapSingpost:BLENDALPHA(0, MODEL.lua.SbTransSignPost(), MODEL.lua.SbTransSignPost())

    elseif st_EasyNav.active and not MODEL.lua.SignpostIsValid() and not MODEL.lua.SBSignpostOn() and MODEL.navigation.junction_view_on() then
      sc_AngleSignPost()
      MODEL.lua.SignpostIsValid = true
      ui_NavigateMapSingpost.Y = -250 -----------------
	  ui_NavigateMapSingpost:BLENDALPHA(MODEL.lua.SbTransSignPost(), 0, MODEL.lua.SbTransSignPost())
    end
  end

  obs_want_junctionview:TRIGGER()
end


-- Indicateur de voie
sc_thl_LS_Lane_OnRelease = function()
  if MODEL.lua.thl_LS_Lane() == 0 then
    MODEL.lua.thl_LS_LaneRoad_Enable = false
    MODEL.lua.thl_LS_LaneHighway_Enable = false
  elseif MODEL.lua.thl_LS_Lane() == 1 then
    MODEL.lua.thl_LS_LaneRoad_Enable = true
    MODEL.lua.thl_LS_LaneHighway_Enable = false
  elseif MODEL.lua.thl_LS_Lane() == 2 then
    MODEL.lua.thl_LS_LaneRoad_Enable = false
    MODEL.lua.thl_LS_LaneHighway_Enable = true
  elseif MODEL.lua.thl_LS_Lane() == 3 then
    MODEL.lua.thl_LS_LaneRoad_Enable = true
    MODEL.lua.thl_LS_LaneHighway_Enable = true
  end
end

-- Indicateur de voie
sc_LaneInfoVisibleOnchange_orig = sc_LaneInfoVisibleOnchange
sc_LaneInfoVisibleOnchange = function()
  if ((MODEL.navigation.car.is_on_highway() and MODEL.lua.thl_LS_LaneHighway_Enable()) or (not MODEL.navigation.car.is_on_highway() and MODEL.lua.thl_LS_LaneRoad_Enable())) then
    if MODEL.lua.laneInfoVisible() then
      sprLaneInfoEasy:BLENDALPHA(0, MODEL.lua.SbTransSignPost(), MODEL.lua.SbTransSignPost())
    else
      sprLaneInfoEasy:BLENDALPHA(MODEL.lua.SbTransSignPost(), 0, MODEL.lua.SbTransSignPost())
    end
  end
end
