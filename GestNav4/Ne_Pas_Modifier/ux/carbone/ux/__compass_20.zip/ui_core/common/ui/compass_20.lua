MODEL.SETPERSISTENT.lua.newCompass = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.newDestArrow = BOOL_MODEL(false)

createState("st_Grand_Compass")
st_EasyNav:useLayers(primary, "ui_Grand_Compass")