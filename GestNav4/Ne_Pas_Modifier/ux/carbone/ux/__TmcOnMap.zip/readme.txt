TMConMap ***************************************************************************

Adaptation de "Morco_TMConMap" 
05/09/2018 correction position sur 2 lignes,
			choix couleurs texte
10/09/2017 adaptation par jthiriet et buldo pour Medianav et skin carbone
08/10/2017 correction de bug affichage avec ux lane setting