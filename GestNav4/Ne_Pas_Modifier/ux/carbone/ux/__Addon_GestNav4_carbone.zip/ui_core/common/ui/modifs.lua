function sc_sk_choup_LoadMyVariables()
    MODEL.lua.EtatMapchanger = sc_GetSysEntry("gestnav4", "image_maps", 0) 
    MODEL.lua.herepicture = 0
    MODEL.lua.tomtompicture = 0
    MODEL.SETPERSISTENT.lua.desinstall_radar = BOOL_MODEL(false)
end