MODEL.SET.lua.Vitesse = INT_MODEL(50)
MODEL.SET.lua.VitesseZD = INT_MODEL(50)
MODEL.SET.lua.Hauteur = INT_MODEL(18)
MODEL.SET.lua.Largeur = INT_MODEL(20)
function sc_GetVitesseLimitePhase(speed2)
    local speed = speed2
    local speedRoute = MODEL.warning.driveralert.speed_limit()
    local speedRadar = MODEL.navigation.curr_speedcam.speed_limit()
    if speedRadar == 0 and speedRoute == 0 then
        return 0
    elseif speedRoute == 0 then
        if speed <= speedRadar then
            return 0
        elseif speed <= speedRadar * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 then
            return 1
        else
            return 2
        end
    elseif speedRadar == 0 then
        if speed <= speedRoute then
            return 0
        elseif speed <= speedRoute * MODEL.warning.speedwarn_alt_tolerance() / 100 then
            return 1
        else
            return 2
        end
    elseif speedRoute < speedRadar then
        if speed <= speedRoute then
            return 0
        elseif speed <= speedRoute * MODEL.warning.speedwarn_alt_tolerance() / 100 then
            return 1
        else
            return 2
        end
    elseif speed <= speedRadar then
        return 0
    elseif speed <= speedRadar * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 then
        return 1
    else
        return 2
    end
end

function sc_BlinkSpeedLimitAlpha()
    if vSpeedLimitBlinkCounter() > 0 then
        ui.vSpeedLimitBlinkCounter = vSpeedLimitBlinkCounter() + 1
        return vSpeedLimitBlinkCounter() % 2
    else
        return true
    end
end

function sc_CurrentSpeedcamDistanceAsChanged()
    local CurrentSpeedcamCategory = MODEL.navigation.curr_speedcam.category()
    if CurrentSpeedcamCategory == 7 or CurrentSpeedcamCategory == 14 then
        sc_CurrentSpeedcamLargeurHauteur()
    elseif CurrentSpeedcamCategory == 8 then
        sc_CurrentSpeedcamDistance()
    end
end

function sc_CurrentSpeedcamLargeurHauteur()
    local CurrentSpeedcamSpeedLimit = MODEL.navigation.curr_speedcam.speed_limit()
    if CurrentSpeedcamSpeedLimit >= 17 and CurrentSpeedcamSpeedLimit <= 45 then
        local calcul = tostring(CurrentSpeedcamSpeedLimit / 10) .. "," .. tostring(CurrentSpeedcamSpeedLimit % 10) .. "m"
        txtLargeurHauteur:TEXT(calcul)
    end
end

function sc_CurrentSpeedcamDistance()
    local speed = MODEL.navigation.car.current_speed()
    local distance = tostring(speed * 56 / 100) .. "m"
    txtDistance:TEXT(distance)
end

st_EditSpeedcam.init_orig = st_EditSpeedcam.init
function st_EditSpeedcam.init()
    if MODEL.lua.managespeedcam() then
        txtTitle.TEXT = m_i18n("Edit Alert Point")
    else
        txtTitle.TEXT = m_i18n("Add Alert Point")
    end
    if MODEL.lua.SpeedCam_Type() == 7 then
        if MODEL.lua.managespeedcam() then
            MODEL.lua.Hauteur = MODEL.lua.SpeedCam_SpeedLimit()
        end
    elseif MODEL.lua.SpeedCam_Type() == 9 then
        if MODEL.lua.managespeedcam() then
            MODEL.lua.VitesseZD = MODEL.lua.SpeedCam_SpeedLimit()
        end
    elseif MODEL.lua.SpeedCam_Type() == 14 then
        if MODEL.lua.managespeedcam() then
            MODEL.lua.Largeur = MODEL.lua.SpeedCam_SpeedLimit()
        end
    elseif (MODEL.lua.SpeedCam_Type() == 1 or MODEL.lua.SpeedCam_Type() == 4 or MODEL.lua.SpeedCam_Type() == 5 or MODEL.lua.SpeedCam_Type() == 13 or MODEL.lua.SpeedCam_Type() == 16 or MODEL.lua.SpeedCam_Type() == 17 or MODEL.lua.SpeedCam_Type() == 18 or MODEL.lua.SpeedCam_Type() == 24 or MODEL.lua.SpeedCam_Type() == 25) and MODEL.lua.managespeedcam() then
        MODEL.lua.Vitesse = MODEL.lua.SpeedCam_SpeedLimit()
    end
    sc_init_local_menu("ui.lm_editSpeedcam")
end

sc_SaveSpeedcam_orig = sc_SaveSpeedcam
function sc_SaveSpeedcam()
    gSpeedCamSaved = true
    local SBspeedlimit = var.new
    if MODEL.lua.SpeedCam_Type() == 7 then
        SBspeedlimit = MODEL.lua.Hauteur()
    elseif MODEL.lua.SpeedCam_Type() == 9 then
        SBspeedlimit = MODEL.lua.VitesseZD()
    elseif MODEL.lua.SpeedCam_Type() == 14 then
        SBspeedlimit = MODEL.lua.Largeur()
    elseif MODEL.lua.SpeedCam_Type() == 1 or MODEL.lua.SpeedCam_Type() == 4 or MODEL.lua.SpeedCam_Type() == 13 or MODEL.lua.SpeedCam_Type() == 16 or MODEL.lua.SpeedCam_Type() == 17 or MODEL.lua.SpeedCam_Type() == 18 then
        SBspeedlimit = MODEL.lua.SpeedCam_SpeedLimit()
    else
        SBspeedlimit = MODEL.lua.Vitesse()
    end
    if MODEL.lua.managespeedcam() then
        MODEL.warning.manage.update_speedcam(MODEL.lua.SpeedCam_ID(), MODEL.lua.SpeedCam_Type(), SBspeedlimit, MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
    else
        MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), SBspeedlimit, MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
        SpeedcamAdded:trigger()
    end
    MODEL.map.primary.update_clicked_speedcam_list()
    sc_CopySpeedCamUserList()
    sc_UpdateCameraCursorIcon()
    sc_back()
end

function sc_hscSC_Height_OnChange()
    if MODEL.lua.Hauteur() == 17 then
        TXTRDHaut:TEXT("1.70 m")
    elseif MODEL.lua.Hauteur() == 18 then
        TXTRDHaut:TEXT("1.80 m")
    elseif MODEL.lua.Hauteur() == 19 then
        TXTRDHaut:TEXT("1.90 m")
    elseif MODEL.lua.Hauteur() == 20 then
        TXTRDHaut:TEXT("2.00 m")
    elseif MODEL.lua.Hauteur() == 21 then
        TXTRDHaut:TEXT("2.10 m")
    elseif MODEL.lua.Hauteur() == 22 then
        TXTRDHaut:TEXT("2.20 m")
    elseif MODEL.lua.Hauteur() == 23 then
        TXTRDHaut:TEXT("2.30 m")
    elseif MODEL.lua.Hauteur() == 24 then
        TXTRDHaut:TEXT("2.40 m")
    elseif MODEL.lua.Hauteur() == 25 then
        TXTRDHaut:TEXT("2.50 m")
    elseif MODEL.lua.Hauteur() == 26 then
        TXTRDHaut:TEXT("2.60 m")
    elseif MODEL.lua.Hauteur() == 27 then
        TXTRDHaut:TEXT("2.70 m")
    elseif MODEL.lua.Hauteur() == 28 then
        TXTRDHaut:TEXT("2.80 m")
    elseif MODEL.lua.Hauteur() == 29 then
        TXTRDHaut:TEXT("2.90 m")
    elseif MODEL.lua.Hauteur() == 30 then
        TXTRDHaut:TEXT("3.00 m")
    elseif MODEL.lua.Hauteur() == 31 then
        TXTRDHaut:TEXT("3.10 m")
    elseif MODEL.lua.Hauteur() == 32 then
        TXTRDHaut:TEXT("3.20 m")
    elseif MODEL.lua.Hauteur() == 33 then
        TXTRDHaut:TEXT("3.30 m")
    elseif MODEL.lua.Hauteur() == 34 then
        TXTRDHaut:TEXT("3.40 m")
    elseif MODEL.lua.Hauteur() == 35 then
        TXTRDHaut:TEXT("3.50 m")
    elseif MODEL.lua.Hauteur() == 36 then
        TXTRDHaut:TEXT("3.60 m")
    elseif MODEL.lua.Hauteur() == 37 then
        TXTRDHaut:TEXT("3.70 m")
    elseif MODEL.lua.Hauteur() == 38 then
        TXTRDHaut:TEXT("3.80 m")
    elseif MODEL.lua.Hauteur() == 39 then
        TXTRDHaut:TEXT("3.90 m")
    elseif MODEL.lua.Hauteur() == 40 then
        TXTRDHaut:TEXT("4.00 m")
    elseif MODEL.lua.Hauteur() == 41 then
        TXTRDHaut:TEXT("4.10 m")
    elseif MODEL.lua.Hauteur() == 42 then
        TXTRDHaut:TEXT("4.20 m")
    elseif MODEL.lua.Hauteur() == 43 then
        TXTRDHaut:TEXT("4.30 m")
    elseif MODEL.lua.Hauteur() == 44 then
        TXTRDHaut:TEXT("4.40 m")
    elseif MODEL.lua.Hauteur() == 45 then
        TXTRDHaut:TEXT("4.50 m")
    else
        MODEL.lua.Hauteur = 45
        TXTRDHaut:TEXT("4.50 m")
    end
end

function sc_hscSC_Width_OnChange()
    if MODEL.lua.Largeur() == 20 then
        TXTRDLarg:TEXT("2.00 m")
    elseif MODEL.lua.Largeur() == 21 then
        TXTRDLarg:TEXT("2.10 m")
    elseif MODEL.lua.Largeur() == 22 then
        TXTRDLarg:TEXT("2.20 m")
    elseif MODEL.lua.Largeur() == 23 then
        TXTRDLarg:TEXT("2.30 m")
    elseif MODEL.lua.Largeur() == 24 then
        TXTRDLarg:TEXT("2.40 m")
    elseif MODEL.lua.Largeur() == 25 then
        TXTRDLarg:TEXT("2.50 m")
    elseif MODEL.lua.Largeur() == 26 then
        TXTRDLarg:TEXT("2.60 m")
    elseif MODEL.lua.Largeur() == 27 then
        TXTRDLarg:TEXT("2.70 m")
    elseif MODEL.lua.Largeur() == 28 then
        TXTRDLarg:TEXT("2.80 m")
    elseif MODEL.lua.Largeur() == 29 then
        TXTRDLarg:TEXT("2.90 m")
    elseif MODEL.lua.Largeur() == 30 then
        TXTRDLarg:TEXT("3.00 m")
    elseif MODEL.lua.Largeur() == 31 then
        TXTRDLarg:TEXT("3.10 m")
    elseif MODEL.lua.Largeur() == 32 then
        TXTRDLarg:TEXT("3.20 m")
    elseif MODEL.lua.Largeur() == 33 then
        TXTRDLarg:TEXT("3.30 m")
    elseif MODEL.lua.Largeur() == 34 then
        TXTRDLarg:TEXT("3.40 m")
    elseif MODEL.lua.Largeur() == 35 then
        TXTRDLarg:TEXT("3.50 m")
    else
        MODEL.lua.Largeur = 35
        TXTRDLarg:TEXT("3.50 m")
    end
end

function sc_hscSC_Zone_OnChange()
    if MODEL.lua.VitesseZD() == 0 then
        TXTRDZone:TEXT("No limit DZ")
    elseif MODEL.lua.VitesseZD() == 20 then
        TXTRDZone:TEXT("20 km/h")
    elseif MODEL.lua.VitesseZD() == 30 then
        TXTRDZone:TEXT("30 km/h")
    elseif MODEL.lua.VitesseZD() == 40 then
        TXTRDZone:TEXT("40 km/h")
    elseif MODEL.lua.VitesseZD() == 45 then
        TXTRDZone:TEXT("45 km/h")
    elseif MODEL.lua.VitesseZD() == 50 then
        TXTRDZone:TEXT("50 km/h")
    elseif MODEL.lua.VitesseZD() == 60 then
        TXTRDZone:TEXT("60 km/h")
    elseif MODEL.lua.VitesseZD() == 70 then
        TXTRDZone:TEXT("70 km/h")
    elseif MODEL.lua.VitesseZD() == 80 then
        TXTRDZone:TEXT("80 km/h")
    elseif MODEL.lua.VitesseZD() == 90 then
        TXTRDZone:TEXT("90 km/h")
    elseif MODEL.lua.VitesseZD() == 100 then
        TXTRDZone:TEXT("100 km/h")
    elseif MODEL.lua.VitesseZD() == 110 then
        TXTRDZone:TEXT("110 km/h")
    elseif MODEL.lua.VitesseZD() == 120 then
        TXTRDZone:TEXT("120 km/h")
    elseif MODEL.lua.VitesseZD() == 130 then
        TXTRDZone:TEXT("130 km/h")
    elseif MODEL.lua.VitesseZD() == 210 then
        TXTRDZone:TEXT("Dangerous Crossroads")
    elseif MODEL.lua.VitesseZD() == 212 then
        TXTRDZone:TEXT("Speed Breaker")
    elseif MODEL.lua.VitesseZD() == 215 then
        TXTRDZone:TEXT("Dangerous Roundabout")
    elseif MODEL.lua.VitesseZD() == 216 then
        TXTRDZone:TEXT("Give Way")
    elseif MODEL.lua.VitesseZD() == 217 then
        TXTRDZone:TEXT("Crossroads (STOP ?)")
    elseif MODEL.lua.VitesseZD() == 218 then
        TXTRDZone:TEXT("Dangerous turn")
    elseif MODEL.lua.VitesseZD() == 219 then
        TXTRDZone:TEXT("Steep Descent")
    else
        MODEL.lua.VitesseZD = 219
        TXTRDZone:TEXT("Steep Descent")
    end
end

function sc_hscSC_Vitesse_OnChange()
    if MODEL.lua.Vitesse() == 0 then
        TXTRDVitesse:TEXT("No limit")
    elseif MODEL.lua.Vitesse() == 10 then
        TXTRDVitesse:TEXT("10 km/h")
    elseif MODEL.lua.Vitesse() == 15 then
        TXTRDVitesse:TEXT("15 km/h")
    elseif MODEL.lua.Vitesse() == 20 then
        TXTRDVitesse:TEXT("20 km/h")
    elseif MODEL.lua.Vitesse() == 25 then
        TXTRDVitesse:TEXT("25 km/h")
    elseif MODEL.lua.Vitesse() == 30 then
        TXTRDVitesse:TEXT("30 km/h")
    elseif MODEL.lua.Vitesse() == 35 then
        TXTRDVitesse:TEXT("35 km/h")
    elseif MODEL.lua.Vitesse() == 40 then
        TXTRDVitesse:TEXT("40 km/h")
    elseif MODEL.lua.Vitesse() == 45 then
        TXTRDVitesse:TEXT("45 km/h")
    elseif MODEL.lua.Vitesse() == 50 then
        TXTRDVitesse:TEXT("50 km/h")
    elseif MODEL.lua.Vitesse() == 60 then
        TXTRDVitesse:TEXT("60 km/h")
    elseif MODEL.lua.Vitesse() == 70 then
        TXTRDVitesse:TEXT("70 km/h")
    elseif MODEL.lua.Vitesse() == 80 then
        TXTRDVitesse:TEXT("80 km/h")
    elseif MODEL.lua.Vitesse() == 90 then
        TXTRDVitesse:TEXT("90 km/h")
    elseif MODEL.lua.Vitesse() == 100 then
        TXTRDVitesse:TEXT("100 km/h")
    elseif MODEL.lua.Vitesse() == 110 then
        TXTRDVitesse:TEXT("110 km/h")
    elseif MODEL.lua.Vitesse() == 120 then
        TXTRDVitesse:TEXT("120 km/h")
    elseif MODEL.lua.Vitesse() == 130 then
        TXTRDVitesse:TEXT("130 km/h")
    elseif MODEL.lua.Vitesse() == 200 then
        TXTRDVitesse:TEXT("Variable speed")
    else
        MODEL.lua.Vitesse = 50
        TXTRDVitesse:TEXT("50")
    end
end

MODEL.SET.lua.speedcamAllowed = PROXY_BOOL_MODEL({
    getter = function()
        if MODEL.route.list.navigated.waypoints.start_is_user_selected() then
            return sc_SpeedcamIsAllowedByPos(MODEL.lua.LastKnownPos())
        else
            return MODEL.warning.speedcam.allowed_in_the_country()
        end
    end,
    observe = {
        MODEL.warning.speedcam.allowed_in_the_country,
        MODEL.route.list.navigated.waypoints.start_is_user_selected
    }
})
MODEL.SETPERSISTENT.lua.VS = INT_MODEL(30)
MODEL.SET.lua.TK_Radar_22 = BOOL_MODEL(true)
MODEL.SET.lua.TK_Radar_Auto = BOOL_MODEL(true)
function tk_Switch_Autorad()
    MODEL.lua.TK_Radar_Auto = not MODEL.lua.TK_Radar_Auto()
    if MODEL.lua.TK_Radar_Auto() then
        MODEL.lua.TK_Radar_22 = true
        sc_SpeedcamWarningDisabled()
    else
        MODEL.lua.TK_Radar_22 = false
        sc_SpeedcamWarningEnabled()
    end
    sc_back_to_cockpit()
end

createState("st_VS")
st_EasyNav:useLayers(primary, "ui_VS")
function sc_start_customize()
    obs_GC_Collector:START("NO_TRIGGER")
    gBdDetectAutorad = sc_GetSysEntry("autorad", "detect", 10)
    MODEL.lua.TK_Radar_Auto = not sc_GetSysEntry("autorad", "disabled", 0)
    if MODEL.lua.TK_Radar_Auto() then
        sc_SpeedcamWarningDisabled()
    else
        sc_SpeedcamWarningEnabled()
    end
    if gBdDetectAutorad < 1 then
        gBdDetectAutorad = 1
    elseif gBdDetectAutorad > 25 then
        gBdDetectAutorad = 25
    end
    MODEL.lua.TK_Radar_22 = MODEL.lua.TK_Radar_Auto()
    MODEL.lua.VS = gBdDetectAutorad
end

function sc_GetAdvancedSpeedLimitPhase(speed, speed_limit)
    if MODEL.lua.TK_Radar_Auto() and speed < gBdDetectAutorad or MODEL.lua.TK_Radar_22() and MODEL.navigation.is_in_simulation() then
        if MODEL.navigation.is_in_simulation() then
            sc_SpeedcamWarningEnabled()
        else
            sc_SpeedcamWarningDisabled()
        end
    else
        sc_SpeedcamWarningEnabled()
    end
    if MODEL.warning.driveralert.speed_limit_condition.valid() and MODEL.warning.driveralert.speed_limit_condition() ~= eSpeedlimitContionTypes.eTime then
    else
        if not MODEL.warning.driveralert.speed_limit.valid() then
            return 0
        end
        speed_limit = MODEL.warning.driveralert.speed_limit()
    end
    if MODEL.lua.warning.speedwarn_alt_tolerance_global() > 99 then
        if speed <= speed_limit then
            return 0
        elseif speed <= speed_limit * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 then
            return 1
        else
            return 2
        end
    elseif speed <= speed_limit * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 then
        return 0
    elseif speed > speed_limit * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 and speed <= speed_limit then
        return 1
    else
        return 2
    end
end

function sc_DeleteSpeedcamSB()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Delete current speedcam ?"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_DeleteSpeedcamSB2", m_i18n("Yes"), L"", "ico_done_mid.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("No"), L"", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_DeleteSpeedcamSB2()
    sc_UpdateSpeedcamModels(MODEL.map.primary.clicked_speedcam_list[0])
    MODEL.warning.manage.delete_speedcam(MODEL.lua.SpeedCam_ID())
    MODEL.map.primary.update_clicked_speedcam_list()
    sc_UpdateCameraCursorIcon()
end

