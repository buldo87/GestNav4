BeforeStartInit:register(function()
end
)
StartInit:register(function()
    MODEL.other.sensor_fusion.enabled = true
    MODEL.lua.show_exit = sc_GetSysEntry("interface", "show_exit", 0)
    MODEL.other.lg_renault.screen_change():register(sc_Screen_Control)
    MODEL.other.lg_renault.start_screen_handling():register(sc_Start_Screen_Handling)
end
)
CockpitInit:register(function()
    MODEL.other.lg_renault.send_screen_message(eScreenTypes.Map)
end
)
