MODEL.SETPERSISTENT.lua.GCTimeUpd = INT_MODEL(10)
MODEL.SET.lua.LuaMem =  WSTRING_MODEL(L"")
MODEL.SETPERSISTENT.lua.GCActive = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.Memory_Auto_Clean = BOOL_MODEL(false)
local triger = true
local hibernate_delay = MODEL.lua.GCTimeUpd()
MODEL.SETPERSISTENT.lua.Free_Memory_Limit_GC = INT_MODEL(3)
MODEL.SET.lua.wCurrentRealTimeGC = PROXY_WSTRING_MODEL({
    getter = function()
        return MODEL.other.format_time_dayperiod(MODEL.other.lg_renault.display_time.time(), 0, 0)
    end,
    observe = {
        MODEL.other.lg_renault.display_time.time
    }
})
function sc_Time_in_seconds()
    local Time = MODEL.other.format_time_dayperiod(MODEL.other.lg_renault.display_time.time(), 0, 0)
    local Time_String = tostring(Time)
    local i = string.find(Time_String, ":", 1)
    local Time_HH = string.sub(Time_String, 1, i - 1)
    local Time_HH_d = tonumber(Time_HH)
    local j = string.find(Time_String, ":", i + 1)
    local Time_MM = string.sub(Time_String, i + 1, j - 1)
    local Time_MM_d = tonumber(Time_MM)
    local Time_SS = string.sub(Time_String, j + 1, -1)
    local Time_SS_d = tonumber(Time_SS)
    return (Time_HH_d * 60 + Time_MM_d) * 60 + Time_SS_d
end

local timer = sc_Time_in_seconds()
function sc_Garbage_Collector()
    if MODEL.lua.Memory_Auto_Clean() and sc_Time_in_seconds() - timer > hibernate_delay and MODEL.other.free_memory() / 1048576 <= MODEL.lua.Free_Memory_Limit_GC() then
        sc_Clear_Garbage_Collector()
    elseif MODEL.lua.Memory_Auto_Clean() and sc_Time_in_seconds() - timer > hibernate_delay and MODEL.lua.Free_Memory_Limit_GC() == 0 then
        sc_Clear_Garbage_Collector()
    end
end

function sc_Clear_Garbage_Collector()
buldo_debug_log(wstring.format(L" sc_Clear_Garbage_Collector ##"), 1)
sc_log_Garbage_Collector()
    if triger then
	buldo_debug_log(wstring.format(L"sc_clear_memory() START_APPLICATION"), 3)
        sc_clear_memory()
MODEL.other.create_process(true,L"//bin//bash",L"",L"//navi_rw//utility//mem//gc.sh",false)
--   START_APPLICATION(exe, params)
--        MODEL.SETPERSISTENT.lua.GCActive = BOOL_MODEL(false)
    end
    if not triger then
	buldo_debug_log(wstring.format(L"collectgarbage"), 3)
        collectgarbage("collect")
--        MODEL.SETPERSISTENT.lua.GCActive = BOOL_MODEL(true)
    end
    triger = not triger
    timer = sc_Time_in_seconds()
	doDelayed(15, sc_log_Garbage_Collector())

    doDelayed(16, buldo_debug_log(wstring.format(L" sc_Clear_Garbage_Collector fin#"), 1))
	
end
function sc_log_Garbage_Collector()
    buldo_debug_log(wstring.format(L"memoire libre \'%s\' Mo", towstring(MODEL.other.free_memory() / 1048576)), 2)
	buldo_debug_log(wstring.format(L"cache utilise \'%s\' Mo", towstring(MODEL.other.cache_used_memory() / 1048576)), 2)
	buldo_debug_log(wstring.format(L"Garbage memory \'%s\' Mo", towstring(MODEL.other.cache_garbage_memory() / 1048576)), 2)
	buldo_debug_log(wstring.format(L"memoire Lua collectgarbage \'%s\' Ko", towstring(collectgarbage("count"))), 2)
end

createState("st_GCset")
st_GCset:useLayers(backgroundLayersNoFooter, "ui_GCset", "ui_List_Background")
function st_GCset.init()
    txtTitle:SET(sc_st_GCsetTitle())
end

function sc_st_GCsetTitle()
    return m_i18n("Auto Clean Memory")
end

function sc_GCset_OnRelease()
    sc_NextStateAnim(st_GCset, "horz_scroll", 1, "")
end

function sc_SelectValueIntegerTime_GC()
    GC_input_type = "time"
    sc_NextStateAnim(st_InputValueInteger_GC, "fade", 1, "")
    txtTitle.TEXT = m_i18n("Period Update")
    inpValueInteger_GC.value = L""
    inpValueInteger_GC.EMPTYTITLE = translated_format(m_i18n("<Enter Number (%s)>"), L"3..60")
    sc_inpValueInteger_onchange_GC()
    KEY("RETURN", sc_GCTimeDone)
    ui.vKeyTableDone = sc_GCTimeDone
end

createState("st_InputValueInteger_GC")
st_InputValueInteger_GC:useLayers(backgroundLayers, "ui_InputValueInteger_GC")
function st_InputValueInteger_GC.init()
    MODEL.lua.easyShowDoneKey = true
    MODEL.regional.keyboard.load_panel_by_name(L"Core Numbers")
    MODEL.lua.InputValidatorIsDate = GC_input_type ~= "time"
    wTmpdateDelimiter = MODEL.lua.dateDelimiter()
    MODEL.lua.dateDelimiter = 0
end

function st_InputValueInteger_GC.done()
    KEY("RETURN")
    MODEL.lua.InputValidatorIsDate = false
    MODEL.lua.dateDelimiter = wTmpdateDelimiter
    MODEL.regional.keyboard.on_close_panel()
    MODEL.regional.keyboard.smartkey_model("")
end

function sc_GCTimeDone()
    MODEL.lua.GCTimeUpd = tonumber(ui.inpValueInteger_GC.VALUE())
    hibernate_delay = MODEL.lua.GCTimeUpd()
    sc_back()
end

function sc_inpValueInteger_onchange_GC()
    local text = ui.inpValueInteger_GC.value
    if GC_input_type == "time" then
        sc_CheckNextChar("int", text, 3, 60)
    end
    MODEL.lua.keyb_done = MODEL.lua.validator_done()
    MODEL.regional.keyboard.smartkey_model("lua.validator_chars")
end

function sc_TimeGCUpd()
    local txt = translated_format(m_i18n("sec"))
    return towstring(MODEL.lua.GCTimeUpd() .. L" " .. txt)
end

function sc_SelectValueIntegerMemoryCritic()
    GC_input_type2 = "memoire"
    sc_NextStateAnim(st_InputValueInteger_GC2, "fade", 1, "")
    txtTitle.TEXT = m_i18n("Critic Memory")
    inpValueInteger_GC2.value = L""
    inpValueInteger_GC2.EMPTYTITLE = translated_format(m_i18n("<Enter Number (%s)>"), L"0..99")
    sc_inpValueInteger_onchange_GC2()
    KEY("RETURN", sc_GCMemoryDone)
    ui.vKeyTableDone = sc_GCMemoryDone
end

createState("st_InputValueInteger_GC2")
st_InputValueInteger_GC2:useLayers(backgroundLayers, "ui_InputValueInteger_GC2")
function st_InputValueInteger_GC2.init()
    MODEL.lua.easyShowDoneKey = true
    MODEL.regional.keyboard.load_panel_by_name(L"Core Numbers")
end

function st_InputValueInteger_GC2.done()
    KEY("RETURN")
    MODEL.regional.keyboard.on_close_panel()
    MODEL.regional.keyboard.smartkey_model("")
end

function sc_GCMemoryDone()
    MODEL.lua.Free_Memory_Limit_GC = tonumber(ui.inpValueInteger_GC2.VALUE())
    sc_back()
end

function sc_inpValueInteger_onchange_GC2()
    local text = ui.inpValueInteger_GC2.value
    if GC_input_type2 == "memoire" then
        sc_CheckNextChar("int", text, 0, 99)
    end
    MODEL.lua.keyb_done = MODEL.lua.validator_done()
    MODEL.regional.keyboard.smartkey_model("lua.validator_chars")
end

function sc_MemoryGCUpd()
    local txt = translated_format(m_i18n("MB"))
    return towstring(MODEL.lua.Free_Memory_Limit_GC() .. L" " .. txt)
end

function sc_clear_memory()
	MODEL.lua.LuaMem = towstring(collectgarbage("count"))

    local easyClear = not MODEL.screen.nightmode()
	MODEL.screen.nightmode = easyClear
	local easyClear2 = not MODEL.screen.nightmode()
	MODEL.screen.nightmode = easyClear2
	
end

createState("st_AboutMemory")
st_AboutMemory:useLayers(backgroundLayers2, ui_AnimationLogo, ui_AboutMemory)
function sc_Memory_Onrelease()
    txtTitle.TEXT = m_i18n("About Memory")
    sc_NextStateAnim(st_AboutMemory, "horz_scroll", 1, "")
end

