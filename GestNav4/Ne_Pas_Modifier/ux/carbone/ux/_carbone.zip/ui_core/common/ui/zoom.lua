MODEL.SETPERSISTENT.lua.OverViewModeOn2 = INT_MODEL(1)
MODEL.SET.lua.Vitesse = INT_MODEL(50)
MODEL.SET.lua.VitesseZD = INT_MODEL(50)
MODEL.SET.lua.Hauteur = INT_MODEL(18)
MODEL.SET.lua.Largeur = INT_MODEL(20)
MODEL.SETPERSISTENT.lua.vdjOverViewEnable = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.vdjOverViewDistance = INT_MODEL(1000)
MODEL.SETPERSISTENT.lua.vdjOverViewZoom = INT_MODEL(1000)
MODEL.SETPERSISTENT.lua.OverviewSpeedcam = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.vOverviewON = INT_MODEL(0)
MODEL.SETPERSISTENT.lua.vNorthUpRotation = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.bFollowRotation = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.SBCarPos2DNu = INT_MODEL(49)
MODEL.SETPERSISTENT.lua.SBCarPos2D = INT_MODEL(71)
MODEL.SETPERSISTENT.lua.SBCarPos3D = INT_MODEL(71)
MODEL.SETPERSISTENT.lua.SBOverviewSpeedMin = INT_MODEL(0)
MODEL.SETPERSISTENT.lua.SBTypeOverview = INT_MODEL(1)
MODEL.SETPERSISTENT.lua.SBOverview3DTilt = INT_MODEL(76)
MODEL.SETPERSISTENT.lua.SBbtpanman = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.SBgerincl = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.SBTiltMax = INT_MODEL(72)
MODEL.SETPERSISTENT.lua.SBTiltMin = INT_MODEL(51)
MODEL.SETPERSISTENT.lua.BdZoomMax = INT_MODEL(300)
MODEL.SETPERSISTENT.lua.BdZoomMin = INT_MODEL(10)
MODEL.SETPERSISTENT.lua.OverViewModeOn = BOOL_MODEL(true)
st_EasyNav:useLayers(primary, "ui_Bd_zoomonmap")
function sc_SetFlyOverMode()
    if not MODEL.navigation.is_in_simulation() then
        return
    end
    local mapLayer = MODEL.map.primary
    if mapLayer.state() ~= "simulate_2d_northup" and mapLayer.state() ~= "simulate_2d" and mapLayer.state() ~= "simulate" then
        mapLayer.enter_state(MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup and "simulate_2d_northup" or MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D and "simulate_2d" or "simulate")
        if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
            mapLayer.rotate = 0
        else
            mapLayer.rotate = 4096 - MODEL.navigation.car.heading()
        end
    end
    primary:ONMAPCLICK(sc_ShowHideSimulateControls)
    MODEL.navigation.autoreplan = false
    MODEL.route.list.navigated.waypoints.autocreate_start = MODEL.navigation.autoreplan()
    obs_flyover_stopped:START()
    sc_ShowHideSimulateControls()
end

function sc_RestoreSmartZoom()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.showLaneInfo = true
    mapLayer.camera_settings.roundabout.centery = 50
    if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2DNu()
    elseif MODEL.lua.vEasyMapMode() == 3 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2D()
    else
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
    end
    mapLayer.camera_settings.presetid = MODEL.lua.vEasyViewMode() + 1
    if MODEL.lua.vOverviewON() == 2 and MODEL.lua.SBTypeOverview() == 1 then
        if MODEL.lua.vEasyMapMode() == 2 then
            mapLayer.car_posy = MODEL.lua.SBCarPos2DNu()
        else
            mapLayer.car_posy = MODEL.lua.SBCarPos2D()
        end
    else
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
    end
end

function sc_ZoomMapSetting()
    if MODEL.lua.vEasyViewMode() == 3 then
        sc_Bd_Tiltset_OnRelease()
        if not MODEL.lua.SBgerincl() then
            MODEL.lua.vEasyViewMode = 0
        end
    else
        MODEL.lua.vEasyViewMode = MODEL.lua.vEasyViewMode() + 1
        sc_Set_Presets()
    end
end

function sc_PanoramaMapSetting()
    if MODEL.lua.OverViewModeOn2() == 2 then
        sc_sb_panoramaset_OnRelease()
        if not MODEL.lua.vdjOverViewEnable() then
            MODEL.lua.OverViewModeOn2 = 0
            MODEL.lua.OverViewModeOn = false
        end
    elseif MODEL.lua.OverViewModeOn2() == 1 then
        MODEL.lua.OverViewModeOn2 = 2
        MODEL.lua.OverViewModeOn = false
    elseif MODEL.lua.OverViewModeOn2() == 0 then
        MODEL.lua.OverViewModeOn2 = 1
        MODEL.lua.OverViewModeOn = true
    end
end

function st_EasyNav.init()
    sc_Bd_init_map()
    sc_PosRecalcLayer()
    sc_Set_Presets()
    sc_init_local_menu("ui.lm_st_EasyNav")
    primary:ONMAPCLICK(sc_EasyMapClick)
    obs_enter_drag_mode:START("no_trigger")
    if MODEL.lua.dragMode() then
        sc_dragmode(true)
        MODEL.lua.mainMenuMode = false
    else
        if MODEL.navigation.is_in_simulation() then
            sc_SetFlyOverMode()
        else
            sc_set_Nav2D3D()
            MODEL.lua.mainMenuMode = false
        end
        sc_SetCockpitMap()
        sc_Set_Follow_On()
        MODEL.map.primary.show_cursor = false
    end
    ATTACH_LANEINFO(sprLaneInfoEasy, "laneinfo.ini")
    ATTACH_LANEINFO(sprLaneInfoSignpost, "laneinfo_signpost.ini")
    ui.bLaneInfoSignpostForceRedraw = 1
    if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2DNu()
    elseif MODEL.lua.vEasyMapMode() == 3 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2D()
    else
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
    end
    st_EasyNav.active = true
    ui_Local_Menu_Background.ALPHA = 0
    ui_Local_Menu_Background_Disabled:HIDE()
    if not MODEL.map.primary.center_follow() and not gKeepMapPosAfterBack then
        MODEL.map.primary.center_noanim(MODEL.map.cursor.position())
    end
    gKeepMapPosAfterBack = false
    if showDriveCarefully and MODEL.interface.drive_carefully() then
        sc_drive_carefully_init()
    end
    satPhaseTimerId = doDelayed(20, sc_CycleSatPhase, true)
    MODEL.lua.ismapvisible = true
    CockpitInit:trigger()
end

function sc_Bd_init_map()
    sc_Bd_ShowzoomOnMap_init()
    if MODEL.lua.SBgerincl() then
        sc_sB_Tilt()
    end
    if MODEL.lua.vdjOverViewEnable() then
        if MODEL.lua.SBbtpanman() then
        else
            ob_gjm_overview:START("no_trigger")
        end
        MODEL.lua.OverViewModeOn = false
        MODEL.lua.vOverviewON = 1
    end
end

createState("st_Bd_Tiltset")
st_Bd_Tiltset:useLayers(backgroundLayers, "ui_Bd_Tiltset", "ui_List_Background")
function st_Bd_Tiltset.init()
    txtTitle.TEXT = m_i18n("Manage Tilt and zoom")
end

function sc_Bd_Tiltset_OnRelease()
    sc_NextStateAnim(st_Bd_Tiltset, "horz_scroll", 1, "")
end

createState("st_sb_panoramaset")
st_sb_panoramaset:useLayers(backgroundLayers, "ui_sb_panoramaset")
function st_sb_panoramaset.init()
    txtTitle.TEXT = m_i18n("Panorama")
    sc_SB_set_Overview()
end

function sc_sb_panoramaset_OnRelease()
    sc_NextStateAnim(st_sb_panoramaset, "horz_scroll", 1, "")
end

function sc_sB_Tilt()
    local primary = MODEL.map.primary
    primary.camera_settings.maxzoom3d = MODEL.lua.BdZoomMax()
    primary.camera_settings.minzoom3d = MODEL.lua.BdZoomMin()
    if MODEL.lua.SBgerincl() and MODEL.lua.vOverviewON() ~= 2 then
        if MODEL.lua.SBTiltMax() < MODEL.lua.SBTiltMin() then
            MODEL.lua.SBTiltMax = MODEL.lua.SBTiltMin()
        end
        if MODEL.lua.BdZoomMax() < MODEL.lua.BdZoomMin() then
            MODEL.lua.BdZoomMax = MODEL.lua.BdZoomMin()
        end
        txt_NavmapTiltzoommax:TEXT(tostring(MODEL.lua.BdZoomMax()))
        txt_NavmapTiltzoommin:TEXT(tostring(MODEL.lua.BdZoomMin()))
        txt_NavmapTiltmax:TEXT(tostring(MODEL.lua.SBTiltMax()))
        txt_NavmapTiltmin:TEXT(tostring(MODEL.lua.SBTiltMin()))
        primary.camera_settings.minangle = MODEL.lua.SBTiltMin()
        primary.camera_settings.maxangle = MODEL.lua.SBTiltMax()
    else
        primary.camera_settings.presetid = MODEL.lua.vEasyViewMode()
    end
end

function sc_Bd_ShowzoomOnMap_init()
    ui_Bd_zoomonmap:HIDE()
end

function sc_Bd_ShowzoomOnMap()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.tiltVisible = true
    mapLayer.zoom_lock = false
    mapLayer.tilt_lock = false
    mapLayer.rotate_lock = false
    mapLayer.zoom_follow = false
    mapLayer.tilt_follow = false
    mapLayer.rotate_follow = false
    ui_Bd_zoomonmap:SHOW()
    doDelayed(400, function()
        ui_Bd_zoomonmap:HIDE()
        mapLayer.rotate_lock = true
        mapLayer.rotate_follow = true
    end)
end

function sc_Bd_ShowzoomOnMapCruse()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.tiltVisible = true
    mapLayer.zoom_lock = false
    mapLayer.tilt_lock = false
    mapLayer.rotate_lock = false
    mapLayer.zoom_follow = false
    mapLayer.tilt_follow = false
    mapLayer.rotate_follow = false
    ui_Bd_zoomonmap:SHOW()
    doDelayed(400, function()
        ui_Bd_zoomonmap:HIDE()
        mapLayer.rotate_lock = true
        mapLayer.rotate_follow = true
    end)
end

function sc_SB_set_Overview()
end

function sc_dj_DistChange()
    if MODEL.lua.vOverviewON() ~= 0 and not MODEL.lua.SBbtpanman() then
        sc_dj_overviewON()
    end
end

function sc_dj_switch2d3d()
    if MODEL.lua.vEasyMapMode() == 1 then
        sc_dj_overviewOFF()
        MODEL.lua.vEasyMapMode = 2
        sc_Easy2D()
    else
        sc_dj_overviewOFF()
        MODEL.lua.vEasyMapMode = 1
        sc_Easy3D()
    end
end

function sc_dj_overviewONpanman()
    sc_dj_overview2DSW()
end

function sc_dj_overviewONpanmanoff()
    sc_dj_overview3D()
end

function sc_dj_overviewON()
    if not MODEL.lua.dragMode() and not MODEL.lua.SBbtpanman() then
        if not MODEL.lua.OverviewSpeedcam() and MODEL.navigation.curr_speedcam.category.valid() then
            sc_dj_overview3D()
        elseif MODEL.navigation.distance_to_maneuver() < MODEL.lua.vdjOverViewDistance() then
            sc_dj_overview3D()
        elseif MODEL.lua.SBOverviewSpeedMin() > 0 and MODEL.lua.SBOverviewSpeedMin() > MODEL.navigation.car.current_speed() then
            sc_dj_overview3D()
        else
            sc_dj_overview2DSW()
        end
    end
end

function sc_dj_overviewOFF()
    MODEL.lua.vOverviewON = 0
end

function sc_dj_over3D()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.vOverviewON = 2
    mapLayer.switch_state("navmap3d", 1)
    mapLayer.tilt = MODEL.lua.SBOverview3DTilt() * 100
    mapLayer.tilt_lock = false
    mapLayer.tilt_follow = true
    mapLayer.rotate_follow = true
    mapLayer.zoom_lock = false
    mapLayer.zoom_follow = false
    mapLayer.zoom = MODEL.lua.vdjOverViewZoom()
end

function sc_dj_over2D()
    if MODEL.lua.vOverviewON() ~= 2 then
        local mapLayer = MODEL.map.primary()
        mapLayer.switch_state("2dheadup", 1)
        mapLayer.zoom_follow = false
        mapLayer.zoom_lock = false
        mapLayer.zoom = MODEL.lua.vdjOverViewZoom()
        MODEL.lua.vOverviewON = 2
    end
end

function sc_dj_overview3D()
    if MODEL.lua.vOverviewON() ~= 1 then
        MODEL.lua.vOverviewON = 1
        if MODEL.lua.MemMapMode() == 1 then
            MODEL.lua.vEasyMapMode = 1
            local mapLayer = MODEL.map.primary()
            mapLayer.switch_state("navmap3d", 1)
            mapLayer.zoom_follow = true
            mapLayer.zoom_lock = true
            mapLayer.rotate_follow = true
            mapLayer.car_posy = MODEL.lua.SBCarPos3D()
            sc_Easy3D()
        elseif MODEL.lua.MemMapMode() == 2 then
            local mapLayer = MODEL.map.primary()
            mapLayer.switch_state("2dnorthup", 1)
            mapLayer.rotate = 0
            mapLayer.zoom_lock = false
            mapLayer.rotate_lock = false
            mapLayer.center_lock = false
            mapLayer.center_follow = true
            mapLayer.zoom_follow = true
            mapLayer.rotate_follow = false
            mapLayer.zoom = MODEL.lua.vdjOverViewZoom()
            mapLayer.car_posy = MODEL.lua.SBCarPos2DNu()
            sc_Easy2D_northup()
        elseif MODEL.lua.MemMapMode() == 3 then
            local mapLayer = MODEL.map.primary()
            mapLayer.switch_state("2dheadup", 1)
            mapLayer.zoom_lock = false
            mapLayer.rotate_lock = true
            mapLayer.center_lock = false
            mapLayer.center_follow = true
            mapLayer.zoom_follow = true
            mapLayer.rotate_follow = true
            mapLayer.zoom = MODEL.lua.vdjOverViewZoom()
            mapLayer.car_posy = MODEL.lua.SBCarPos2D()
            sc_Easy2D()
        end
    end
end

function sc_dj_overview2DSW()
    if MODEL.lua.vOverviewON() ~= 2 then
        if MODEL.lua.SBTypeOverview() == 1 then
            sc_dj_over2D()
            local mapLayer = MODEL.map.primary()
            if MODEL.lua.vNorthUpRotation() then
                mapLayer.rotate_follow = true
                MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2D()
            else
                MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2DNu()
                mapLayer.rotate = 0
                mapLayer.rotate_follow = false
            end
        else
            sc_dj_over3D()
            MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
        end
    end
end

function PanoramaOff()
    if MODEL.lua.vdjOverViewEnable() then
        sc_dj_overviewON()
    end
end

function sc_back_to_cockpit()
    sc_LoadRoute()
    sc_GoToMap()
    PanoramaOff()
end

function sc_sb_Easy2DSetting()
    if MODEL.lua.vEasyMapMode() == 2 then
        sc_Easy2D()
    end
end

lastZoom = DOUBLE_0
lastTilt = DOUBLE_0
tiltStep = DOUBLE_0
function sc_TiltChanged1()
    sc_TiltChanged()
end

function sc_TiltChanged2()
    manualTiltChange = true
    sc_TiltChanged()
    manualTiltChange = nil
end

function sc_TiltChanged()
    if not manualTiltChange or MODEL.map.primary.tilt_lock() then
        return
    end
    sc_CalcTiltStep()
end

function sc_CalcTiltStep()
    local primary = MODEL.map.primary
    lastZoom = primary.zoom()
    if lastZoom < maxZoom then
        lastTilt = DOUBLE.new(primary.tilt())
        tiltStep = lastTilt / (maxZoom - lastZoom)
    end
end

function sc_MapModeChanged()
    sc_CalcTilt()
end

function sc_ZoomChanged()
    sc_CalcTilt()
end

function sc_CalcTilt()
    local primary = MODEL.map.primary
    if primary.tilt_lock() or primary.mode() ~= "3d" then
        return
    end
    local actZoom = primary.zoom()
    local lastManualTiltChange = manualTiltChange
    manualTiltChange = nil
    if actZoom > maxZoom then
        actZoom = maxZoom
    elseif actZoom < lastZoom then
        actZoom = lastZoom
    end
    local tilt = (lastTilt - (actZoom - lastZoom) * tiltStep):toInt()
    if tilt > primary.maxtilt3d() then
        tilt = primary.maxtilt3d()
    elseif tilt < 0 then
        tilt = 0
    end
    primary.tilt = tilt
    if actZoom == lastZoom then
        sc_CalcTiltStep()
    end
    manualTiltChange = lastManualTiltChange
end

function sc_RefreshOverviewStatus()
    MODEL.lua.OverViewModeOn = not MODEL.lua.OverViewModeOn()
    MODEL.lua.OverViewModeOn = not MODEL.lua.OverViewModeOn()
end

function sc_Stop_Obs_Panorama()
    ob_gjm_overview:STOP()
    PanoramaOff()
end

function sc_Stop_Obs_Panoramaman()
    PanoramaOff()
    sc_dj_overview3D()
    ob_gjm_overview:START("no_trigger")
end

function PanoramaOffPopUp(isPanelOpen)
    if MODEL.lua.vdjOverViewEnable() and isPanelOpen then
        ob_gjm_overview:STOP()
        sc_dj_overviewOFF()
        sc_dj_overview3D()
    end
    sc_SetNavCarPos(isPanelOpen)
    if MODEL.lua.vdjOverViewEnable() and not isPanelOpen then
        ob_gjm_overview:START("no_trigger")
    end
end

