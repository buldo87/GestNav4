MODEL.SET.lua.Flash_X_Y = WSTRING_MODEL(L"")
MODEL.SET.lua.Flash_speed = WSTRING_MODEL(L"")
MODEL.SET.lua.Flash_heading = INT_MODEL(0)
MODEL.SET.lua.FRg = INT_MODEL(0)
MODEL.SET.lua.FPl = INT_MODEL(0)
MODEL.SET.lua.Dir = INT_MODEL(0)
MODEL.SET.lua.Bis = INT_MODEL(0)
MODEL.SET.lua.Inv = INT_MODEL(0)
MODEL.SET.lua.Tou = INT_MODEL(0)
MODEL.SET.lua.Flash_type = WSTRING_MODEL(L"")
MODEL.SET.lua.ComAlert = WSTRING_MODEL(L"")
MODEL.SET.lua.Fix = INT_MODEL(0)
MODEL.SET.lua.FVP = INT_MODEL(0)
MODEL.SET.lua.Mob = INT_MODEL(0)
MODEL.SET.lua.Sct = INT_MODEL(0)
MODEL.SET.lua.FinSct = BOOL_MODEL(false)
MODEL.SET.lua.Flash_dirtype = WSTRING_MODEL(L"")
MODEL.SET.lua.Flash_direction = WSTRING_MODEL(L"")
MODEL.SET.lua.ComSens = WSTRING_MODEL(L"")
MODEL.SET.lua.TK_pseudo = CSTRING_MODEL("")
MODEL.SET.lua.TKcountry = CSTRING_MODEL("")
MODEL.SETPERSISTENT.lua.myfile = CSTRING_MODEL("")
MODEL.SETPERSISTENT.lua.myfileB = CSTRING_MODEL("")
MODEL.SET.lua.mymscr = CSTRING_MODEL("")
MODEL.SET.lua.mymscrB = CSTRING_MODEL("")
MODEL.SET.lua.mortscript = CSTRING_MODEL("")
MODEL.lua.TK_pseudo = sc_GetSysEntry("login", "pseudo", "")
function sc_Rel2AbsFromPrimo(path)
    if path:len() > 0 then
        path = path .. "\\"
    end
    path = string.gsub(path, "/", "\\")
    if path:sub(1, 1) ~= "\\" and sc_GetSysEntry("folders", "app", "") ~= "" then
        path = sc_GetSysEntry("folders", "app", "") .. "\\" .. path
    end
    while string.find(path, "\\\\") do
        path = string.gsub(path, "\\\\", "\\")
    end
    return path
end

do
    local myfile = string.gsub(sc_GetSysEntry("flash", "myfile", "FlashSpeedcam.txt"), "/", "\\")
    local myfileB = string.gsub(sc_GetSysEntry("flash", "myfileB", "LocalLiveSpeedcam.txt"), "/", "\\")
    while string.find(myfile, "\\\\") do
        myfile = string.gsub(myfile, "\\\\", "\\")
    end
    while string.find(myfileB, "\\\\") do
        myfileB = string.gsub(myfileB, "\\\\", "\\")
    end
    if myfile:sub(-1) == "\\" then
        myfile = myfile:sub(1, -2) .. ".txt"
    end
    if myfileB:sub(-1) == "\\" then
        myfileB = myfileB:sub(1, -2) .. ".txt"
    end
    local path = sc_GetSysEntry("flash", "myfolder", "")
    if myfile:sub(1, 1) ~= "\\" then
        if string.find(myfile, "\\") then
            path = ""
        end
        myfile = sc_Rel2AbsFromPrimo(path) .. myfile
    end
    if myfileB:sub(1, 1) ~= "\\" then
        if string.find(myfileB, "\\") then
            path = ""
        end
        myfileB = sc_Rel2AbsFromPrimo(path) .. myfileB
    end
    MODEL.lua.myfile = string.gsub(myfile, "\\\\", "\\")
    MODEL.lua.myfileB = string.gsub(myfileB, "\\\\", "\\")
    MODEL.lua.mymscr = sc_Rel2AbsFromPrimo(sc_GetSysEntry("flash", "mscrpath", "utility")) .. sc_GetSysEntry("flash", "mscrfile", "FlashRad.mscr")
    MODEL.lua.mymscrB = sc_Rel2AbsFromPrimo(sc_GetSysEntry("flash", "mscrpath", "utility")) .. sc_GetSysEntry("flash", "mscrfile", "FlashRadB.mscr")
    MODEL.lua.mortscript = sc_Rel2AbsFromPrimo("utility") .. "MortScript.exe"
end
createState("st_LFlash")
st_EasyNav:useLayers(primary, "ui_LFlash")
function EcranFlash()
    doDelayed(15, function()
        sc_NextStateAnim(st_Flash, "horz_scroll", 1, "")
    end)
end

createState("st_Flash")
st_Flash:useLayers(backgroundLayers, "ui_Flash")
function st_Flash.enter()
    txtTitle.TEXT = "Capture flash radars"
    MODEL.map.cursor.position = MODEL.navigation.car.position()
    local Coord = wstring.gsub(towstring(MODEL.map.cursor.position()), L"longitude = ", L"")
    Coord = wstring.gsub(Coord, L" latitude = ", L"")
    MODEL.lua.Flash_X_Y = Coord
    MODEL.lua.SpeedCam_Pos = MODEL.map.cursor.position()
    MODEL.lua.Flash_speed = towstring(MODEL.warning.driveralert.speed_limit())
    MODEL.lua.SpeedCam_SpeedLimit = MODEL.warning.driveralert.speed_limit()
    MODEL.lua.Flash_heading = MODEL.navigation.car.heading()
    cameraData = {}
    cameraData.speedlimit, cameraData.direction, cameraData.directionType = MODEL.warning.manage.get_segment_params()
    MODEL.lua.SpeedCam_Direction = cameraData.direction
    if MODEL.lua.FinSct() then
        sc_Sct()
    else
        sc_Mob()
    end
    sc_Dir()
end

function InitAlert()
    MODEL.lua.Fix = 0
    MODEL.lua.Mob = 0
    MODEL.lua.Sct = 0
    MODEL.lua.FRg = 0
    MODEL.lua.FPl = 0
    MODEL.lua.FVP = 0
end

function sc_Fix()
    MODEL.lua.SpeedCam_Type = 0
    InitAlert()
    MODEL.lua.Fix = 1
    MODEL.lua.Flash_type = L"1"
    MODEL.lua.ComAlert = L"Fixe"
end

function sc_Mob()
    MODEL.lua.SpeedCam_Type = 2
    InitAlert()
    MODEL.lua.Mob = 1
    MODEL.lua.Flash_type = L"2"
    MODEL.lua.ComAlert = L"Mobile"
end

function sc_Sct()
    MODEL.lua.SpeedCam_Type = 3
    InitAlert()
    MODEL.lua.Sct = 1
    MODEL.lua.Flash_type = L"4"
    MODEL.lua.ComAlert = L"Section x 2"
end

function sc_FRg()
    MODEL.lua.SpeedCam_Type = 5
    InitAlert()
    MODEL.lua.FRg = 1
    MODEL.lua.Flash_type = L"69"
    MODEL.lua.ComAlert = L"Red light"
end

function sc_FPl()
    MODEL.lua.SpeedCam_Type = 15
    InitAlert()
    MODEL.lua.FPl = 1
    MODEL.lua.Flash_type = L"15"
    MODEL.lua.ComAlert = L"Truck"
end

function sc_FVP()
    MODEL.lua.SpeedCam_Type = 0
    InitAlert()
    MODEL.lua.FVP = 1
    MODEL.lua.Flash_type = L"1"
    MODEL.lua.ComAlert = L"Discriminant"
end

function InitSens()
    MODEL.lua.Dir = 0
    MODEL.lua.Inv = 0
    MODEL.lua.Bis = 0
    MODEL.lua.Tou = 0
end

function sc_Dir()
    MODEL.lua.SpeedCam_Direction_type = 1
    InitSens()
    MODEL.lua.Dir = 1
    MODEL.lua.Flash_dirtype = L"1"
    local heading = (4096 - MODEL.lua.Flash_heading()) * 360 / 4096
    if heading == 360 then
        heading = 0
    end
    MODEL.lua.Flash_direction = towstring(heading)
    MODEL.lua.ComSens = L"Direct"
end

function sc_Inv()
    MODEL.lua.SpeedCam_Direction_type = 0
    InitSens()
    MODEL.lua.Inv = 1
    MODEL.lua.Flash_dirtype = L"1"
    local heading = (4096 - MODEL.lua.Flash_heading()) * 360 / 4096
    if heading < 180 then
        heading = heading + 180
    else
        heading = heading - 180
    end
    MODEL.lua.Flash_direction = towstring(heading)
    MODEL.lua.ComSens = L"Inverse"
end

function sc_Bis()
    MODEL.lua.SpeedCam_Direction_type = 2
    InitSens()
    MODEL.lua.Bis = 1
    MODEL.lua.Flash_dirtype = L"2"
    local heading = (4096 - MODEL.lua.Flash_heading()) * 360 / 4096
    if heading == 360 then
        heading = 0
    end
    MODEL.lua.Flash_direction = towstring(heading)
    MODEL.lua.ComSens = L"Double"
end

function sc_Tou()
    MODEL.lua.SpeedCam_Direction_type = 3
    InitSens()
    MODEL.lua.Tou = 1
    MODEL.lua.Flash_dirtype = L"0"
    local heading = (4096 - MODEL.lua.Flash_heading()) * 360 / 4096
    MODEL.lua.Flash_direction = towstring(heading)
    MODEL.lua.ComSens = L"All"
end

function sc_VtsP()
    if MODEL.lua.SpeedCam_SpeedLimit() < 130 then
        if MODEL.lua.SpeedCam_SpeedLimit() < 50 then
            MODEL.lua.SpeedCam_SpeedLimit = MODEL.lua.SpeedCam_SpeedLimit() + 5
        else
            MODEL.lua.SpeedCam_SpeedLimit = MODEL.lua.SpeedCam_SpeedLimit() + 10
        end
        MODEL.lua.Flash_speed = towstring(MODEL.lua.SpeedCam_SpeedLimit())
    end
end

function sc_VtsM()
    if MODEL.lua.SpeedCam_SpeedLimit() < 131 then
        if MODEL.lua.SpeedCam_SpeedLimit() > 50 then
            MODEL.lua.SpeedCam_SpeedLimit = MODEL.lua.SpeedCam_SpeedLimit() - 10
        elseif MODEL.lua.SpeedCam_SpeedLimit() > 30 then
            MODEL.lua.SpeedCam_SpeedLimit = MODEL.lua.SpeedCam_SpeedLimit() - 5
        end
        MODEL.lua.Flash_speed = towstring(MODEL.lua.SpeedCam_SpeedLimit())
    end
end

function FinFlash()
    if MODEL.lua.Sct() then
        if MODEL.lua.FinSct() then
            MODEL.lua.FinSct = false
        else
            MODEL.lua.FinSct = true
        end
    else
        MODEL.lua.FinSct = false
    end
    SelectSauv()
    sc_Bd_SelectSaveSpeedcam()
    TransKey()
end

function SelectSauv()
    MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), MODEL.lua.SpeedCam_SpeedLimit(), MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
    MODEL.map.primary.update_clicked_speedcam_list()
    sc_UpdateCameraCursorIcon()
    local speedcam = MODEL.lua.Flash_X_Y() .. L"," .. MODEL.lua.Flash_type() .. L"," .. MODEL.lua.Flash_speed() .. L"," .. MODEL.lua.Flash_dirtype() .. L"," .. MODEL.lua.Flash_direction() .. L"," .. MODEL.lua.ComAlert() .. L" & " .. MODEL.lua.ComSens()
    local params = "\"" .. MODEL.lua.mymscr() .. "\" myfile=\"" .. MODEL.lua.myfile() .. "\" data=\"" .. tostring(speedcam) .. "\""
    local exe = MODEL.lua.mortscript()
    doDelayed(10, function()
--        START_APPLICATION(exe, params)
    end)
end

function sc_Bd_SelectSaveSpeedcam()
    if MODEL.lua.FVP() then
        if MODEL.lua.Inv() == 1 then
            sc_tk_SaveSpeedcamDInverse()
        else
            sc_tk_SaveSpeedcamD()
        end
    elseif MODEL.lua.Inv() == 1 then
        sc_tk_SaveSpeedcamInverse()
    else
        sc_tk_SaveSpeedcam()
    end
end

function sc_tk_SaveSpeedcamInverse()
    MODEL.lua.TKcountry = MODEL.navigation.car.current_country()
    MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), MODEL.lua.SpeedCam_SpeedLimit(), MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
    MODEL.map.primary.update_clicked_speedcam_list()
    sc_UpdateCameraCursorIcon()
    local speedcam = L",," .. MODEL.lua.Flash_X_Y() .. L"," .. towstring(MODEL.lua.TKcountry()) .. L"," .. MODEL.lua.Flash_type() .. L"," .. MODEL.lua.Flash_speed() .. L"," .. MODEL.lua.Flash_dirtype() .. L"," .. MODEL.lua.Flash_direction() .. L"," .. towstring(MODEL.lua.TK_pseudo()) .. L"," .. L"" .. L"," .. L"Inverse"
    local params = "\"" .. MODEL.lua.mymscrB() .. "\" myfileB=\"" .. MODEL.lua.myfileB() .. "\" data=\"" .. tostring(speedcam) .. "\""
    local exe = MODEL.lua.mortscript()
    doDelayed(10, function()
 --       START_APPLICATION(exe, params)
    end)
end

function sc_tk_SaveSpeedcam()
    MODEL.lua.TKcountry = MODEL.navigation.car.current_country()
    if MODEL.lua.SpeedCam_Direction_type() == 2 or MODEL.lua.SpeedCam_Direction_type() == 3 then
        MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), MODEL.lua.SpeedCam_SpeedLimit(), MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
        sc_UpdateCameraCursorIcon()
    end
    local speedcam = L",," .. MODEL.lua.Flash_X_Y() .. L"," .. towstring(MODEL.lua.TKcountry()) .. L"," .. MODEL.lua.Flash_type() .. L"," .. MODEL.lua.Flash_speed() .. L"," .. MODEL.lua.Flash_dirtype() .. L"," .. MODEL.lua.Flash_direction() .. L"," .. towstring(MODEL.lua.TK_pseudo()) .. L"," .. L"" .. L"," .. L""
    local params = "\"" .. MODEL.lua.mymscrB() .. "\" myfileB=\"" .. MODEL.lua.myfileB() .. "\" data=\"" .. tostring(speedcam) .. "\""
    local exe = MODEL.lua.mortscript()
    doDelayed(10, function()
--        START_APPLICATION(exe, params)
    end)
end

function sc_tk_SaveSpeedcamDInverse()
    MODEL.lua.TKcountry = MODEL.navigation.car.current_country()
    MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), MODEL.lua.SpeedCam_SpeedLimit(), MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
    MODEL.map.primary.update_clicked_speedcam_list()
    sc_UpdateCameraCursorIcon()
    local speedcam = L",," .. MODEL.lua.Flash_X_Y() .. L"," .. towstring(MODEL.lua.TKcountry()) .. L"," .. MODEL.lua.FVP() .. L"," .. MODEL.lua.Flash_speed() .. L"," .. MODEL.lua.Flash_dirtype() .. L"," .. MODEL.lua.Flash_direction() .. L"," .. towstring(MODEL.lua.TK_pseudo()) .. L"," .. L"Discri" .. L"," .. L"Inverse"
    local params = "\"" .. MODEL.lua.mymscrB() .. "\" myfileB=\"" .. MODEL.lua.myfileB() .. "\" data=\"" .. tostring(speedcam) .. "\""
    local exe = MODEL.lua.mortscript()
    doDelayed(10, function()
--        START_APPLICATION(exe, params)
    end)
end

function sc_tk_SaveSpeedcamD()
    MODEL.lua.TKcountry = MODEL.navigation.car.current_country()
    if MODEL.lua.SpeedCam_Direction_type() == 2 or MODEL.lua.SpeedCam_Direction_type() == 3 then
        MODEL.warning.manage.add_speedcam(MODEL.lua.SpeedCam_Pos(), MODEL.lua.SpeedCam_Type(), MODEL.lua.SpeedCam_SpeedLimit(), MODEL.lua.SpeedCam_Direction(), MODEL.lua.SpeedCam_Direction_type())
        MODEL.map.primary.update_clicked_speedcam_list()
        sc_UpdateCameraCursorIcon()
    end
    local speedcam = L",," .. MODEL.lua.Flash_X_Y() .. L"," .. towstring(MODEL.lua.TKcountry()) .. L"," .. MODEL.lua.FVP() .. L"," .. MODEL.lua.Flash_speed() .. L"," .. MODEL.lua.Flash_dirtype() .. L"," .. MODEL.lua.Flash_direction() .. L"," .. towstring(MODEL.lua.TK_pseudo()) .. L"," .. L"Discri" .. L"," .. L""
    local params = "\"" .. MODEL.lua.mymscrB() .. "\" myfileB=\"" .. MODEL.lua.myfileB() .. "\" data=\"" .. tostring(speedcam) .. "\""
    local exe = MODEL.lua.mortscript()
    doDelayed(10, function()
--        START_APPLICATION(exe, params)
    end)
end

function TransKey()
    sc_close_local_menu()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Position is captured"))
    MODEL.screen.msgbox.new.set_line(2, m_i18n("Save files to USB?\n Existing ones will be overwritten!"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_TransKeyOk", m_i18n("Copie"), "", "ico_TransSaisie.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_TransKeyOk()
    sc_back()
--    START_APPLICATION("./Utility/TransfertKey.exe", "")
end

