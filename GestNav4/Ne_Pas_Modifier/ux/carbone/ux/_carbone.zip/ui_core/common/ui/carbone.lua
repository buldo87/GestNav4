MODEL.SET.lua.JunctionViewHiddenByUser = BOOL_MODEL(false)
MODEL.SET.lua.logbuldo = BOOL_MODEL(false)
MODEL.SET.lua.JunctionViewVisible = PROXY_BOOL_MODEL({
    getter = function()
        return MODEL.navigation.want_junctionview() and MODEL.navigation.has_junctionview() and not MODEL.lua.JunctionViewHiddenByUser() and (MODEL.lua.SignpostOn() or MODEL.navigation.tunnel_view.overview.available())
    end,
    observe = {
        MODEL.navigation.want_junctionview,
        MODEL.navigation.has_junctionview,
        MODEL.lua.JunctionViewHiddenByUser,
        MODEL.lua.SignpostOn,
        MODEL.navigation.tunnel_view.overview.available
    }
})
MODEL.SETPERSISTENT.lua.sbgoNavigationTimeout = INT_MODEL(10)
MODEL.SETPERSISTENT.lua.warning.speedwarn_alt_tolerance_global = INT_MODEL(100)
function sc_GetAdvancedSpeedLimitPhase(speed, speed_limit)
    if speed <= speed_limit then
        return 0
    elseif speed <= speed_limit * MODEL.lua.warning.speedwarn_alt_tolerance_global() / 100 then
        return 1
    else
        return 2
    end
end

MODEL.SETPERSISTENT.lua.daValueModel = INT_MODEL(0)
MODEL.SETPERSISTENT.lua.warningDistanceEnabled = BOOL_MODEL(true)
function sc_SettingRegionalLanguageOK()
    MODEL.regional.select_language(MODEL.regional.languages.index(), false)
MODEL.other.create_process(true,L"//bin//bash",L"",L"//navi_rw//utility//restart//restart.sh",false)
--    doDelayed(20000, START_APPLICATION(exe, params))
--    NEXTSTATE(RestartState)
	sc_Debug_Exit()
end

MODEL.SET.lua.wBlockValid = INT_MODEL(0)
wBlockedFromCockpit = false
wNeedDestinationTimer = nil
wDestinationBackIdleTimer = nil
sc_SetGoNavCountdown_orig = sc_SetGoNavCountdown
function sc_SetGoNavCountdown(tmp, DoCountDown)
    if not DoCountDown or DoCountDown == 0 then
        return m_i18n("Go!")
    end
    local Timeout = MODEL.lua.sbgoNavigationTimeout()
    if MODEL.lua.ReadOutRouteSummary() then
        Timeout = Timeout / 2
    end
    return translated_format(m_i18n("Go! (%s)"), towstring(Timeout - MODEL.ui._idle_time()))
end

function sc_LMBlockRoad()
    MODEL.route.add_roadblock(MODEL.map.cursor.position(), true, true)
    MODEL.mydata.blocked_roads.current_weekdays_all_blocked(true)
    sc_wBlockCheck()
end

function sc_LMBlockRoad_lc()
    MODEL.route.add_roadblock(MODEL.map.cursor.position(), true, true)
    MODEL.lua.newBlockedSection = true
    wBlockedFromCockpit = true
    NEXTSTATE(st_ChangeBlockedRoad)
end

function sc_wBlockCheck()
    MODEL.lua.wBlockValid = MODEL.route.is_segment_roadblock(MODEL.map.cursor.position(), 50)
end

sc_lock_plan_mode_orig = sc_lock_plan_mode
function sc_lock_plan_mode()
    if MODEL.lua.LockToCar() then
        MODEL.my.map.select_gcoor(MODEL.navigation.car.position())
    else
        sc_LoadTempPos()
    end
    local Pos = MODEL.my.map.selected_item.position()
    MODEL.map.cursor.position = Pos
    MODEL.map.primary.center = Pos
    if MODEL.my.map.selected_item.type() == 1 then
        PoiSelected = true
        MODEL.my.poi.select_poi(MODEL.ui.lmSavedPos[0].item.poi.provider_id(), MODEL.ui.lmSavedPos[0].item.poi.id())
        sc_SetPOICursorIcon()
    else
        MODEL.map.primary.cursor_icon = "cursor_places"
    end
    sc_wBlockCheck()
end

st_SetBlockedRoads.init_orig = st_SetBlockedRoads.init
function st_SetBlockedRoads.init()
    txtTitle.TEXT = m_i18n("Blocked Roads")
    MODEL.lua.wLocalMenuHide = true
end

function st_SetBlockedRoads.done()
    MODEL.lua.wLocalMenuHide = false
end

function st_ChangeBlockedRoad.exit()
    wBlockedFromCockpit = false
end

sc_ChangeBlockedRoadOK_onrelease_orig = sc_ChangeBlockedRoadOK_onrelease
function sc_ChangeBlockedRoadOK_onrelease()
    sc_BlockedRoadsData_SaveToCurrent()
    if wBlockedFromCockpit then
        MODEL.lua.newBlockedSection = false
        PREVSTATE()
        return
    end
    CLEARTOSTATE(st_FindOnMap)
    if not CLEARTOSTATE(st_FindOnMap) then
        CLEARTOSTATE(st_SetBlockedRoads)
    end
    MODEL.lua.newBlockedSection = false
end

sc_DelBlockedRoadsMSG_orig = sc_DelBlockedRoadsMSG
function sc_DelBlockedRoadsMSG()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Delete all roadblocks?"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_DelBlockedRoads", m_i18n("Delete All"), "", "ico_DeleteAll_mid.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_LMBlockRoadCurrentUsage()
    wBlockedFromCockpit = true
    sc_LMBlockRoadCurrentUsageFind()
end

function sc_LMBlockRoadCurrentUsageFind()
    if sc_wBlockRoadCurrentItemFind() then
        sc_BlockedRoadsData_LoadFromCurrent()
        NEXTSTATE(st_ChangeBlockedRoad)
    else
        NEXTSTATE(st_SetBlockedRoads)
    end
end

function sc_wBlockRoadCurrentItemFind()
    MODEL.route.add_roadblock(MODEL.map.cursor.position(), true, true)
    MODEL.mydata.blocked_roads.current_weekdays_all_blocked(false)
    MODEL.mydata.blocked_roads.list.setcurrent(0)
    local topLeftNeed, bottomRightNeed = MODEL.mydata.blocked_roads.get_boundrect()
    local topLeft, bottomRight
    local successfind = false
    MODEL.mydata.blocked_roads.delete_current()
    for i = 0, MODEL.INT.mydata.blocked_roads.list.size() - 1 do
        MODEL.mydata.blocked_roads.list.setcurrent(i)
        topLeft, bottomRight = MODEL.mydata.blocked_roads.get_boundrect()
        if topLeft == topLeftNeed and bottomRight == bottomRightNeed then
            successfind = true
            break
        end
    end
    return successfind
end

function sc_wDeleteSegmentMSG()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Delete this roadblock?"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_wDeleteSegment", m_i18n("Delete"), "", "ico_Delete_mid.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_wDeleteSegment()
    if sc_wBlockRoadCurrentItemFind() then
        MODEL.mydata.blocked_roads.delete_current()
    else
        MODEL.route.remove_roadblock(MODEL.map.cursor.position())
        MODEL.route.recalculate()
    end
    sc_wBlockCheck()
end

createState("st_wBlockedRoadItem")
st_wBlockedRoadItem:useLayers(ui_BlockedRoadItem, backgroundLayers)
function st_wBlockedRoadItem.enter()
    sc_BlockedRoadsData_LoadFromCurrent()
end

function st_wBlockedRoadItem.init()
    txtTitle.TEXT = m_i18n("Blocked Road")
end

sc_DelBlockedRoad_orig = sc_DelBlockedRoad
function sc_DelBlockedRoad()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Delete this roadblock?"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_DelBlockedRoadOK", m_i18n("Delete"), "", "ico_Delete_mid.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_DelBlockedRoadOK()
    MODEL.mydata.blocked_roads.delete_current()
    sc_back()
    if MODEL.mydata.blocked_roads.list.isempty() then
        sc_back()
    end
end

sc_BlockRoadSectionPermanent_orig = sc_BlockRoadSectionPermanent
function sc_BlockRoadSectionPermanent()
    MODEL.route.add_roadblock(MODEL.map.cursor.position(), true, true)
    MODEL.mydata.blocked_roads.current_weekdays_all_blocked(true)
    sc_wBlockCheck()
end

function sc_BlockRoadSectionPermanent_lc()
    MODEL.route.add_roadblock(MODEL.map.cursor.position(), true, true)
    MODEL.lua.newBlockedSection = true
    CLEARTOSTATE(st_FindOnMap)
    NEXTSTATE(st_ChangeBlockedRoad)
end

function sc_BlockedRoadDays_SetDay(day_index)
    if MODEL.ui.blocked_roads_dayusage[day_index].usage() == 0 then
        blocked_roads.dayranges[day_index] = {
            Range1 = {Start = 0, End = 24},
            Range2 = {Start = -1, End = -1}
        }
    else
        blocked_roads.dayranges[day_index] = {
            Range1 = {Start = -1, End = -1},
            Range2 = {Start = -1, End = -1}
        }
    end
    sc_BlockedRoadsData_RefreshDayUsage(day_index)
end

function sc_BlockedRoadsData_RefreshDayUsage(day_index)
    local weekday = blocked_roads.dayranges[day_index]
    if weekday.Range1.Start == -1 then
        MODEL.ui.blocked_roads_dayusage[day_index].usage = blocked_roads.usage.off
    elseif weekday.Range1.Start == 0 and weekday.Range1.End == 24 then
        MODEL.ui.blocked_roads_dayusage[day_index].usage = blocked_roads.usage.full_time
    else
        MODEL.ui.blocked_roads_dayusage[day_index].usage = blocked_roads.usage.part_time
    end
end

function sc_BlockedRoadDays_ChangeTime(day_index)
    MODEL.mydata.blocked_roads.current_weekdays.index = day_index
    MODEL.ui.blocked_roads_dayusage.index = day_index
    NEXTSTATE(st_SetBlockingTime)
end

function sc_wGetBlockRoadStatus()
    local text = ""
    if not MODEL.mydata.blocked_roads.list[MODEL.mydata.blocked_roads.list.index()].is_permanent() then
        text = "blocked for current route"
    else
        for day_index = 0, 6 do
            if MODEL.ui.blocked_roads_dayusage[day_index].usage() ~= blocked_roads.usage.full_time then
                text = "intermittently blocked"
            end
        end
        if text == "" then
            text = "completely blocked"
        end
    end
    return text
end

function sc_wBlockRoute_OnRelease()
    sc_close_local_menu()
    sc_NextStateAnim(st_wBlockRoute, "fade", 1, "")
end

wBlockRouteStart = nil
wBlockRouteEnd = nil
createState("st_wBlockRoute")
st_wBlockRoute:useLayers(ui_wBlockRoute, primary, uieffect)
function st_wBlockRoute.enter()
    wBlockRouteStart = nil
    wBlockRouteEnd = nil
    MODEL.lua.wBlockRoutePoint = 0
    MODEL.lua.wBlockRouteStatus = 0
    MODEL.lua.wBlockRouteDir = 2
    MODEL.my.map.select_address(MODEL.navigation.car.position())
    sc_SaveTempPos()
    MODEL.map.primary.cursor_icon = "cursor_places"
end

function st_wBlockRoute.init()
    local mapLayer = MODEL.map.primary
    mapLayer.save_state(mapLayer.state())
    mapLayer.enter_state("browsemap")
    mapLayer.rotate = 0
    mapLayer.zoom = mapLayer.minzoom2d()
    mapLayer.breadcrumbs = false
    mapLayer.center = MODEL.my.map.selected_item.position()
    primary:ONMAPCLICK(sc_wBlockRouteClick)
    mapLayer.show_cursor = false
end

function st_wBlockRoute.done()
    MODEL.map.primary.exit_state()
end

function st_wBlockRoute.exit()
    MODEL.route.list.wblockroute.clear()
    MODEL.map.primary.clear_clicked_lists()
end

function sc_wBlockRouteClick()
    if not st_wBlockRoute.isActive then
        return
    end
    MODEL.map.primary.show_cursor = true
    MODEL.route.list.wblockroute.create_empty_route()
    if MODEL.lua.wBlockRoutePoint() then
        wBlockRouteEnd = MODEL.map.cursor.position()
    else
        wBlockRouteStart = MODEL.map.cursor.position()
    end
    MODEL.lua.wBlockRouteStatus = 1
    MODEL.my.map.select_gcoor(wBlockRouteStart)
    MODEL.route.list.wblockroute.waypoints.set_start()
    if wBlockRouteStart and wBlockRouteEnd then
        MODEL.my.map.select_gcoor(wBlockRouteEnd)
        MODEL.route.list.wblockroute.waypoints.add_destination()
        if MODEL.route.list.wblockroute.calculation_finished() then
            sc_wBlockRouteCalculated()
        else
            obs_wblockroute_calculated:START("NO_TRIGGER")
        end
    end
end

function sc_wBlockRouteCalculated()
    obs_wblockroute_calculated:STOP()
    MODEL.route.list.wblockroute.show_on_map = true
    MODEL.route.list.wblockroute.draw_flags = true
    MODEL.map.primary.route_model = "navigated,PL1,PL2,PL3,PL4,wblockroute"
    MODEL.lua.wBlockRouteStatus = 2
    doDelayed(1, sc_wBlockRoute_Fit)
end

function sc_wBlockRoute_Fit()
    local gcTL, gcBR, succ = MODEL.route.list.wblockroute.get_bounding_box()
    if succ then
        sc_routemenu_info_fit_open_from_main(gcTL, gcBR)
    end
end

function sc_wBlockRoute_Center()
    MODEL.map.primary.rotate = 0
    sc_LoadTempPos()
    local Pos = MODEL.my.map.selected_item.position()
    MODEL.map.cursor.position = Pos
    MODEL.map.primary.center = Pos
    MODEL.map.primary.cursor_icon = "cursor_places"
end

function sc_wBlockRouteSave()
    local name = MODEL.lua.wBlockRouteDir() == 2 and "Both directions" or MODEL.lua.wBlockRouteDir() == 1 and "Opposite direction" or "Direct direction"
    name = wstring.gsub(MODEL.route.list.wblockroute.waypoints.list[0].longname(), L"\n", L" ") .. L"\n" .. wstring.gsub(MODEL.route.list.wblockroute.waypoints.list[1].longname(), L"\n", L" ") .. L"\n" .. translated_format(m_i18n(name))
    MODEL.route.block_route("wblockroute", name, true, MODEL.lua.wBlockRouteDir())
    PREVSTATE()
    wBlockedFromCockpit = true
    NEXTSTATE(st_wBlockedRoadItem)
end

function sc_slicetoChars(char_list)
    local chars = {}
    local chars_length = string.len(char_list)
    for i = 1, chars_length do
        chars[i] = string.sub(char_list, i, i)
    end
    return chars
end

function sc_table_reverse(tab)
    local size = #tab
    local rev_tab = {}
    for i, j in ipairs(tab) do
        rev_tab[size - i + 1] = j
    end
    return rev_tab
end

function sc_createTempDigitsList(temperature)
    local temp_tab = sc_table_reverse(sc_slicetoChars(temperature))
    local size = #temp_tab
    if temp_tab[size] == "-" then
        temp_tab[size] = 10
        if temp_tab[size - 1] == "-" then
            temp_tab[size - 1] = 10
        end
    end
    for i = 1, size do
        temp_tab[i] = tonumber(temp_tab[i])
    end
    return {temp_tab, size}
end

function sc_DeleteTrafficEvent()
    local newMsgBox = MODEL.screen.msgbox.new
    newMsgBox.setup(2)
    newMsgBox.set_line(1, m_i18n("Are you sure ?"))
    newMsgBox.setup_button(1, "sc_DeleteTrafficEvent_ok", m_i18n("OK"), "", "ico_done_mid.bmp#3")
    newMsgBox.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_DeleteTrafficEvent_ok()
    gTmcOnOffDelay = doDelayed(15, function()
        MODEL.traffic.settings.traffic_enabled = not MODEL.traffic.settings.traffic_enabled()
        TrafficOnOff:trigger()
    end)
 --   local param = "\"" .. "\\Storage card4\\NNG\\Utility\\DeleteTrafficEvent.mscr" .. "\""
--		    START_APPLICATION("./rw_data/app_data/utility/restart/loading_finished.sh", "")
--sc_InfoMessageBox(tostring(MODEL.EXISTS.mydata.backup()), true)
		MODEL.other.create_process(true,L"//bin//bash",L"",L"//navi_rw//utility//TrafficEvent//DeleteTrafficEvent.sh",false)

--	debug_log("### Buldo ### ","buldo test sh", 3)
--    START_APPLICATION("./Utility/Mortscript.exe", param)
    ui_pleasewait:SHOW()
    gTmcOnOffDelay = doDelayed(100, function()
        MODEL.traffic.settings.traffic_enabled = not MODEL.traffic.settings.traffic_enabled()
        TrafficOnOff:trigger()
    end)
end

function sc_GoToStartState(Cleartomarker)
    sc_use_captureScreen()
    obs_FirstGPS:START()
    MODEL.lua.vDeviceActivationFromGetExtras = true
    if Cleartomarker then
        CLEARTOMARKER(1)
    end
    if MODEL.lua.vEasyNavMapMenuActive() or ui.vMapIsTheFirstState then
        STATE(st_EasyNav)
    else
        STATE(sc_GetStartState())
    end
    obs_other_timejump:START()
    GoToStartState:trigger()
    sc_sk_choup_LoadMyVariables()
end

function sc_sk_choup_LoadMyVariables()
end

MODEL.SETPERSISTENT.lua.SBFiltreNuit = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.SBSetFiltreNuit = INT_MODEL(26)
st_EasyNav:useLayers(primary, "ui_SB_ModeNuit")
function sc_SB_ModeNuitSet()
    spr_color_filter:ALPHA(MODEL.lua.SBSetFiltreNuit())
    txt_ModeNuit:TEXT(tostring(MODEL.lua.SBSetFiltreNuit()))
end

MODEL.SETPERSISTENT.lua.BdShowHouseNumber = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.CockpitButtonHoms = BOOL_MODEL(true)
MODEL.SET.lua.HwyPoiListIsVisible = BOOL_MODEL(false)
MODEL.SET.lua.VRAvailable = BOOL_MODEL(false)
backgroundLayers2 = {
    "ui_Title",
    "ui_Status",
    "ui_Footer",
    "ui_Background2",
    uieffect
}
backgroundLayersNoHead = {
    "ui_Footer",
    "ui_Background",
    uieffect
}
backgroundLayersNoFooter = {
    "ui_Title",
    "ui_Status",
    "ui_Background",
    uieffect
}
localMenuBasicLayers = {
    "ui_Local_Menu",
    "ui_Local_Menu_ListBg",
    "ui_Local_Menu_Background"
}
localMenuLayers = {
    "ui_Local_Menu_OpenBTN",
    localMenuBasicLayers
}
calcLayers = {
    "ui_CalcTitle",
    "ui_CalcStatus",
    "ui_Calculate",
    "ui_CalcVehicles"
}
MODEL.SETPERSISTENT.lua.ODA = INT_MODEL(14)
MODEL.SETPERSISTENT.lua.CBCJ = INT_MODEL(3)
MODEL.SETPERSISTENT.lua.CBCN = INT_MODEL(191)
MODEL.SETPERSISTENT.lua.OBC = INT_MODEL(6)
MODEL.SETPERSISTENT.lua.CBMJ = INT_MODEL(10)
MODEL.SETPERSISTENT.lua.CBMN = INT_MODEL(187)
MODEL.SETPERSISTENT.lua.OBM = INT_MODEL(14)
createState("st_CBC")
st_CBC:useLayers(backgroundLayers, "ui_CBC", "ui_List_Background")
function sc_CBC_OnRelease()
    sc_NextStateAnim(st_CBC, "horz_scroll", 1, "")
end

MODEL.SETPERSISTENT.lua.CFMJ1 = INT_MODEL(48)
MODEL.SETPERSISTENT.lua.CFMJ2 = INT_MODEL(6)
MODEL.SETPERSISTENT.lua.CFMN1 = INT_MODEL(192)
MODEL.SETPERSISTENT.lua.CFMN2 = INT_MODEL(0)
MODEL.SETPERSISTENT.lua.OFM = INT_MODEL(2)
createState("st_CFM")
st_CFM:useLayers(backgroundLayers, "ui_CFM", "ui_List_Background")
function sc_CFM_OnRelease()
    sc_NextStateAnim(st_CFM, "horz_scroll", 1, "")
end

MODEL.SETPERSISTENT.lua.VitCentr = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.CSVJ1 = INT_MODEL(10118)
MODEL.SETPERSISTENT.lua.CSVJ2 = INT_MODEL(63695)
MODEL.SETPERSISTENT.lua.CSVN1 = INT_MODEL(17706)
MODEL.SETPERSISTENT.lua.CSVN2 = INT_MODEL(41161)
MODEL.SETPERSISTENT.lua.OSV = INT_MODEL(4)
MODEL.SETPERSISTENT.lua.OSVS = INT_MODEL(10)
createState("st_CSV")
st_CSV:useLayers(backgroundLayers, "ui_CSV", "ui_List_Background")
function sc_CSV_OnRelease()
    sc_NextStateAnim(st_CSV, "horz_scroll", 1, "")
end

MODEL.SETPERSISTENT.lua.OBMED = INT_MODEL(20)
MODEL.SETPERSISTENT.lua.ORS = INT_MODEL(20)
createState("st_OB")
st_OB:useLayers(backgroundLayers, "ui_OB", "ui_List_Background")
function sc_OB_OnRelease()
    sc_NextStateAnim(st_OB, "horz_scroll", 1, "")
end

MODEL.SETPERSISTENT.lua.AfficherBoutonMedia = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.AfficherBoutoniPT = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.AfficherSurvitesse = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.AfficherVitesse = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.VFlash = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.AfficherTurnRestriction = BOOL_MODEL(true)
createState("st_SkinSettingsMenu")
st_SkinSettingsMenu:useLayers(backgroundLayers, "ui_SkinSettingsMenu", "ui_List_Background")
function st_SkinSettingsMenu.init()
    txtTitle.TEXT = m_i18n("Skin Settings")
end

createState("st_SkinTransparenceMenu")
st_SkinTransparenceMenu:useLayers(backgroundLayers, "ui_SkinTransparenceMenu", "ui_List_Background")
function st_SkinTransparenceMenu.init()
    txtTitle.TEXT = m_i18n("Skin Transparence")
end

createState("st_SkinColorMenu")
st_SkinColorMenu:useLayers(backgroundLayers, "ui_SkinColorMenu", "ui_List_Background")
function st_SkinColorMenu.init()
    txtTitle.TEXT = m_i18n("Skin Coulors")
end

createState("st_SkinEnableMenu")
st_SkinEnableMenu:useLayers(backgroundLayers, "ui_SkinEnableMenu", "ui_List_Background")
function st_SkinEnableMenu.init()
    txtTitle.TEXT = m_i18n("Activation buttons")
end

st_DemoStart:useLayers(backgroundLayers, "ui_About", localMenuLayers)
function st_DemoStart.init()
    txtTitle.TEXT = m_i18n("About")
    sc_init_local_menu("ui.lm_st_About.list")
end

function buldo_log_level(message, level)
    if MODEL.lua.logbuldo() then
        message = towstring(message)
        debug_log("### Buldo ### ", message, level)
    end
end

function buldo_debug_log(message, level)
    if MODEL.lua.logbuldo() then
        message = towstring(message)
        debug_log("### Buldo ### ", message, level)
    end
end

function buldo_log(message)
    if MODEL.lua.logbuldo() then
        message = towstring(message)
        debug_log("##### Buldo ##### ", message, 5)
    end
end

function sc_debugstate()
    if MODEL.lua.logbuldo() then
        debug_log("<STATE> BULDO **********", vActiveState(), 5)
    end
end

