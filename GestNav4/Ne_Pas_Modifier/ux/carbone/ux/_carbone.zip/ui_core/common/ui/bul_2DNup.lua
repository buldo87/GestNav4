MODEL.SETPERSISTENT.lua.MemMapMode = INT_MODEL(1)
MODEL.SETPERSISTENT.lua.MemCarPos = INT_MODEL(80)
function sc_Set_Navmap_3D(mapState)
    sc_Set_Common_3DMap(mapState)
    mapState.rotate = 0
    mapState.zoom_lock = false
    mapState.tilt_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = false
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.tilt_follow = true
    mapState.rotate_follow = true
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos3D()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos3D()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = true
    MODEL.map.primary.camera_settings.roundabout.centery = 50
end

function sc_Set_Navmap_Simulate(mapState)
    sc_Set_Common_3DMap(mapState)
    mapState.tilt = MODEL.lua.SBOverview3DTilt() * 100
    mapState.zoom_lock = false
    mapState.tilt_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = true
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.tilt_follow = true
    mapState.rotate_follow = true
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos3D()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos3D()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = false
    mapState.breadcrumbs = false
    MODEL.map.primary.camera_settings.roundabout.centery = 50
end

function sc_Set_Navmap_Simulate_2d(mapState)
    sc_Set_Common_2DMap(mapState)
    mapState.zoom_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = true
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.rotate_follow = true
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos2D()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos2D()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = false
    mapState.breadcrumbs = false
end

function sc_Set_Navmap_2D_Headup(mapState)
    sc_Set_Common_2DMap(mapState)
    mapState.rotate = 0
    mapState.zoom_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = false
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.rotate_follow = true
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos2D()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos2D()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = true
    MODEL.map.primary.camera_settings.roundabout.centery = 50
end

EMapMode.Mode_2Dnorthup = 2
EMapMode.Mode_2D = 3
MODEL.SET.lua.vDragMapMode = INT_MODEL(1)
function sc_Easy2D()
    MODEL.lua.MemMapMode = 3
    local mapLayer = MODEL.map.primary()
    if not MODEL.lua.dragMode() then
        mapLayer.center_follow = true
        mapLayer.rotate_follow = true
    end
    mapLayer.save_state(mapLayer.state())
    mapLayer.switch_state("2dheadup", 0)
    if not MODEL.lua.dragMode() then
        mapLayer.zoom_follow = true
        mapLayer.car_posy = MODEL.lua.SBCarPos2D()
        mapLayer.center_posy = MODEL.lua.SBCarPos2D()
    end
    if MODEL.lua.bFollowRotation() then
        mapLayer.rotate_follow = true
    else
        mapLayer.rotate = 0
        mapLayer.rotate_follow = false
    end
    mapLayer.breadcrumbs = sc_VehicleIsPedestrian()
end

function sc_Easy3D()
    MODEL.lua.MemMapMode = 1
    local mapLayer = MODEL.map.primary()
    if not MODEL.lua.dragMode() then
        mapLayer.center_follow = true
        mapLayer.rotate_follow = true
    end
    mapLayer.save_state(mapLayer.state())
    mapLayer.switch_state("navmap3d", 1)
    if not MODEL.lua.dragMode() then
        mapLayer.zoom_follow = true
        mapLayer.tilt_follow = true
    end
    mapLayer.rotate_follow = true
    if MODEL.lua.vEasyMapMode() == 2 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2DNu()
    elseif MODEL.lua.vEasyMapMode() == 3 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2D()
    else
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
    end
end

function sc_Easy2D_northup()
    MODEL.lua.MemMapMode = 2
    local mapLayer = MODEL.map.primary()
    if not MODEL.lua.dragMode() then
        mapLayer.center_follow = true
        mapLayer.rotate = 0
        mapLayer.rotate_follow = false
    end
    mapLayer.save_state(mapLayer.state())
    mapLayer.switch_state("2dnorthup", 1)
    mapLayer.zoom_follow = true
    mapLayer.car_posy = MODEL.lua.SBCarPos2DNu()
    mapLayer.center_posy = MODEL.lua.SBCarPos2DNu()
end

function sc_set_Sim2D3D()
    if MODEL.lua.MemMapMode() == 3 then
        sc_Simulate2D()
    elseif MODEL.lua.MemMapMode() == 2 then
        sc_Simulate2D_northup()
    else
        sc_Simulate3D()
    end
end

function sc_Simulate2D()
    local mapLayer = MODEL.map.primary()
    mapLayer.save_state(mapLayer.state())
    mapLayer.switch_state("simulate_2d", 1)
end

function sc_Simulate3D()
    local mapLayer = MODEL.map.primary()
    mapLayer.center_follow = true
    mapLayer.rotate_follow = true
    mapLayer.save_state(mapLayer.state())
    mapLayer.switch_state("simulate", 1)
end

function sc_ChangeHeadupNorthup()
    if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
        MODEL.lua.vEasyMapMode = EMapMode.Mode_2Dnorthup
    elseif MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
        MODEL.lua.vEasyMapMode = EMapMode.Mode_3D
    else
        MODEL.lua.vEasyMapMode = EMapMode.Mode_2D
    end
    MODEL.lua.MemMapMode = MODEL.lua.vEasyMapMode()
    sc_set_Nav2D3D()
    sc_SetNavCarPos()
end

function sc_ChangeHeadupNorthup_ondrag()
    local mapLayer = MODEL.map.primary()
    if mapLayer.mode() == "2d" and MODEL.lua.vDragMapMode() == EMapMode.Mode_2Dnorthup and mapLayer.zoom() <= maxZoom then
        mapLayer.autochange_mode_for_zoom = true
        mapLayer.rotate = 4096 - MODEL.navigation.car.heading()
        MODEL.lua.vDragMapMode = EMapMode.Mode_3D
        sc_Easy3Ddragmode()
    elseif mapLayer.mode() == "3d" or mapLayer.mode() == "2d" and MODEL.lua.vDragMapMode() == EMapMode.Mode_2D and mapLayer.zoom() > maxZoom then
        mapLayer.autochange_mode_for_zoom = false
        mapLayer.rotate = 4096 - MODEL.navigation.car.heading()
        MODEL.lua.vDragMapMode = EMapMode.Mode_2D
        sc_Easy2Ddragmode()
    else
        mapLayer.autochange_mode_for_zoom = false
        mapLayer.rotate = 0
        MODEL.lua.vDragMapMode = EMapMode.Mode_2Dnorthup
        sc_Easy2D_northup_dragmode()
    end
end

function sc_ChangeHeadupNorthup_onmap(mapmode)
    MODEL.lua.vEasyMapMode = mapmode
    if not MODEL.navigation.is_in_simulation() then
        sc_set_Nav2D3D()
    else
        sc_set_Sim2D3D()
    end
    sc_SetNavCarPos()
end

CockpitInit:register(function()
    if MODEL.lua.vEasyMapMode() == 2 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2DNu()
    elseif MODEL.lua.vEasyMapMode() == 3 then
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos2D()
    else
        MODEL.map.primary.car_posy = MODEL.lua.SBCarPos3D()
    end
    MODEL.map.primary.zoom_lock = false
end
)
function sc_set_Nav2D3D()
    if MODEL.lua.vEasyMapMode() == 3 then
        sc_Easy2D()
        MODEL.map.primary.rotate_lock = false
        MODEL.map.primary.tilt_lock = true
    elseif MODEL.lua.vEasyMapMode() == 2 then
        sc_Easy2D_northup()
        MODEL.map.primary.rotate_lock = true
        MODEL.map.primary.tilt_lock = true
    else
        if MODEL.lua.vEasyMapMode() == 1 then
            sc_Easy3D()
            MODEL.map.primary.rotate_lock = false
            MODEL.map.primary.zoom_lock = false
            MODEL.map.primary.tilt_lock = false
        else
        end
    end
end

function sc_Set_Follow_On()
    local mapLayer = MODEL.map.primary()
    if not sc_VehicleIsPedestrian() then
        mapLayer.zoom_follow = true
        mapLayer.tilt_follow = true
    end
    mapLayer.center_follow = true
    if MODEL.lua.vEasyMapMode() ~= EMapMode.Mode_2Dnorthup then
        mapLayer.rotate_follow = true
    end
end

function sc_btnSim_Stop_Easy_onrelease(HwKey)
    if not HwKey then
        uieffect:GRAB()
    end
    StopSimulation:trigger()
    local primary = MODEL.map.primary
    if primary.state() == "simulate_2d" or primary.state() == "simulate" or primary.state() == "simulate_2dnorthup" then
        obs_enter_drag_mode:STOP()
        primary.exit_state()
        obs_enter_drag_mode:START("NO_TRIGGER")
    else
        ASSERT(false, "Not in simulation mapstate?")
    end
    MODEL.route.stop_simulation()
    MODEL.navigation.autoreplan = true
    MODEL.navigation.car.is_on_highway = false
    MODEL.navigation.car.is_on_highway_or_entry_ramp = false
    MODEL.route.list.navigated.waypoints.autocreate_start = MODEL.navigation.autoreplan()
    if not HwKey then
        uieffect:DO_ANIM("fade", 1, "")
    end
end

function sc_dragmode(SetCursor)
    if MODEL.navigation.is_in_simulation() then
        ASSERT(false, "Dragmode in simulation?")
        local centerLock = MODEL.map.primary.center_lock()
        local follow = MODEL.map.primary.center_follow()
        MODEL.map.primary.center_lock = true
        MODEL.map.primary.center_follow = true
        return
    end
    if st_RouteItinerMap.isActive then
        ASSERT(false, "Dragmode in itinerview?")
    end
    local mapLayer = MODEL.map.primary()
    if mapLayer.state() == "dragmode" then
        return
    end
    mapLayer.save_state("dragmode")
    mapLayer.switch_state("dragmode")
    sc_Set_Follow_Off()
    mapLayer.show_cursor = true
    if SetCursor then
        MODEL.map.primary.cursor_icon = "cursor"
    end
    mapLayer.auto_set_cursor = true
    if SetCursor then
        MODEL.map.cursor.position = MODEL.navigation.car.position()
        MODEL.my.map.select_address(MODEL.navigation.car.position())
    end
    obs_Dragmode_Type:START("no_trigger")
    obs_InvalidateClickedListEvent:START("no_trigger")
    sc_reset_primary(false)
    if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
        MODEL.lua.vDragMapMode = EMapMode.Mode_2D
        sc_Easy2Ddragmode()
    elseif MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
        MODEL.lua.vDragMapMode = EMapMode.Mode_2Dnorthup
        sc_Easy2D_northup_dragmode()
    else
        MODEL.lua.vDragMapMode = EMapMode.Mode_3D
        mapLayer.autochange_mode_for_zoom = true
        sc_Easy3Ddragmode()
    end
    if g_MapModeBeforeDragMode < 0 then
        g_MapModeBeforeDragMode = MODEL.lua.vEasyMapMode()
    end
    DragModeOn:trigger()
end

function sc_backFromdragmode()
    obs_InvalidateClickedListEvent:STOP()
    nextRotate = 0
    MODEL.lua.dragMode = false
    MODEL.map.primary.autochange_mode_for_zoom = true
    obs_Dragmode_Type:STOP()
    sc_SetCockpitMap()
    MODEL.lua.vEasyMapMode = g_MapModeBeforeDragMode
    g_MapModeBeforeDragMode = -1
    if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
        sc_Easy2DFromDragmode()
    elseif MODEL.lua.vEasyMapMode() == EMapMode.Mode_2Dnorthup then
        sc_Easy2D_northup_FromDragmode()
    else
        sc_Easy3DFromDragmode()
    end
    BackFromDragMode:trigger()
end

function sc_Set_Navmap_2D_Northup(mapState)
    sc_Set_Common_2DMap(mapState)
    mapState.rotate = 0
    mapState.zoom_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = false
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.rotate_follow = false
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos2DNu()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos2DNu()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = true
    MODEL.map.primary.camera_settings.roundabout.centery = 50
end

function sc_Set_Navmap_Simulate_2d_Northup(mapState)
    sc_Set_Navmap_Simulate_2d(mapState)
    mapState.rotate = 0
    mapState.zoom_lock = false
    mapState.rotate_lock = true
    mapState.center_lock = true
    mapState.center_follow = true
    mapState.zoom_follow = true
    mapState.rotate_follow = false
    mapState.car_posx = 50
    mapState.car_posy = MODEL.lua.SBCarPos2DNu()
    mapState.center_posx = 50
    mapState.center_posy = MODEL.lua.SBCarPos2DNu()
    mapState.show_historical_speed = false
    mapState.show_cursor = false
    mapState.auto_set_cursor = false
    mapState.breadcrumbs = false
end

function sc_Easy2D_northup_FromDragmode()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.dragMode = false
    MODEL.lua.tiltVisible = false
    mapLayer.switch_state("2dnorthup", 1)
    mapLayer.rotate_follow = false
    mapLayer.rotate = 0
    mapLayer.breadcrumbs = false
    mapLayer.center_posy = MODEL.lua.SBCarPos2DNu()
    mapLayer.car_posy = MODEL.lua.SBCarPos2DNu()
    mapLayer.zoom_follow = true
end

function sc_2Dzoom_sync()
    if MODEL.map.primary.state() == "navmap3d" then
        MODEL.map.states["2dnorthup"].zoom_follow = MODEL.map.states["2dheadup"].zoom_follow()
        MODEL.map.states["2dnorthup"].zoom = MODEL.map.states["2dheadup"].zoom()
    elseif MODEL.map.primary.state() == "2dnorthup" then
        MODEL.map.states["2dheadup"].zoom_follow = MODEL.map.states["2dnorthup"].zoom_follow()
        MODEL.map.states["2dheadup"].zoom = MODEL.map.states["2dnorthup"].zoom()
    end
end

function sc_Easy2D_northup_dragmode()
    local mapLayer = MODEL.map.primary()
    sc_Set_Common_2DMap(mapLayer)
    mapLayer.center_posy = 60
    carPosySave = mapLayer.center_posy()
    MODEL.lua.dragMode = true
    MODEL.lua.tiltVisible = false
    mapLayer.zoom_lock = false
    mapLayer.rotate_lock = false
    mapLayer.center_lock = false
    mapLayer.center_follow = false
    mapLayer.zoom_follow = false
    mapLayer.rotate_follow = false
    mapLayer.navi_mode_3d_labels = false
    gdrag2dNorthUp = true
end

function sc_Easy2Ddragmode()
    local mapLayer = MODEL.map.primary()
    sc_Set_Common_2DMap(mapLayer)
    mapLayer.center_posy = MODEL.lua.SBCarPos2D()
    carPosySave = mapLayer.center_posy()
    MODEL.lua.dragMode = true
    MODEL.lua.tiltVisible = false
    mapLayer.zoom_lock = false
    mapLayer.rotate_lock = false
    mapLayer.center_lock = false
    mapLayer.center_follow = false
    mapLayer.zoom_follow = false
    mapLayer.rotate_follow = false
    mapLayer.breadcrumbs = sc_VehicleIsPedestrian()
    mapLayer.navi_mode_3d_labels = false
end

function sc_Easy3DFromDragmode()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.dragMode = false
    MODEL.lua.tiltVisible = false
    mapLayer.switch_state("navmap3d", 0)
    mapLayer.zoom_follow = true
    mapLayer.tilt_follow = true
    mapLayer.rotate_follow = true
end

function sc_Easy2DFromDragmode()
    local mapLayer = MODEL.map.primary()
    MODEL.lua.dragMode = false
    MODEL.lua.tiltVisible = false
    mapLayer.switch_state("2dheadup", 0)
    mapLayer.zoom_follow = true
    mapLayer.breadcrumbs = false
    mapLayer.center_posy = MODEL.lua.SBCarPos2D()
end

MapStateInitScripts["2dnorthup"] = sc_Set_Navmap_2D_Northup
MapStateInitScripts.simulate_2dnorthup = sc_Set_Navmap_Simulate_2d_Northup
function sc_Simulate2D_northup()
    local mapLayer = MODEL.map.primary()
    mapLayer.center_follow = true
    mapLayer.save_state(mapLayer.state())
    sc_2Dzoom_sync()
    mapLayer.switch_state("simulate_2dnorthup")
    mapLayer.rotate_follow = false
    mapLayer.rotate = 0
    mapLayer.car_posy = MODEL.lua.SBCarPos2DNu()
    mapLayer.center_posy = MODEL.lua.SBCarPos2DNu()
end

