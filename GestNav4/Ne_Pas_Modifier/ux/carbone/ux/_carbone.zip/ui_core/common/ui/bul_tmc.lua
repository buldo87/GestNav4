MODEL.SETPERSISTENT.lua.holdStationTime = INT_MODEL(15)
MODEL.SETPERSISTENT.lua.testStationTime = INT_MODEL(3)
MODEL.SET.lua.wLocalMenuHide = BOOL_MODEL(false)
MODEL.SET.lua.wSettingDistSoundName = WSTRING_MODEL(L"")
MODEL.SET.lua.wSettingProgramParameter = WSTRING_MODEL(L"")
MODEL.SET.lua.wSettingDistOn = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.wTMCFixedStation = WSTRING_MODEL(L"")
MODEL.SETPERSISTENT.lua.wTMCTunerMode = INT_MODEL(1)
wTmcF1 = L"75"
wTmcF2 = L"75"
wTmcScan = sc_GetSysEntry("tmc", "hold_station_time", 15)
wTmcSearchMode = false
wTmcSearch = -1
wTmcScanFixed = sc_GetSysEntry("tmc", "test_fixedstation_time", 2)
function sc_wGetSignificantEventsSize(value)
    return translate(m_i18n("Significant Events:")) .. towstring(value)
end

function sc_wGetTmcListFrequencyText(value)
    return translated_format(m_i18n("%s MHz"), value)
end

function sc_wTmcChangeTunning()
    if MODEL.lua.wTMCTunerMode() == 1 or MODEL.lua.wTMCTunerMode() == 5 then
        obs_wtmctuner:STOP()
        if MODEL.tmc.auto_tuning_available() then
            sc_wTmcChangeTunning_done(true)
        else
            sc_wTmcChangeTunning_done(false)
            MODEL.lua.wTMCTunerMode = 0
        end
    elseif MODEL.lua.wTMCTunerMode() == 0 then
        obs_wtmctuner:STOP()
        sc_wTmcChangeTunning_done(false)
    else
        sc_wTmcChangeTunning_done(false)
        obs_wtmctuner:START()
    end
end

function sc_wTmcChangeTunning_done(mode)
    if (not mode or MODEL.tmc.auto_tuning_available()) and MODEL.tmc.auto_tuning() ~= mode then
        MODEL.tmc.auto_tuning = mode
        MODEL.tmc.change_tuning_mode()
    end
end

function sc_wtmcstatechange()
    if MODEL.tmc.station_tuned() then
        wTmcScan = sc_GetSysEntry("tmc", "hold_station_time", 15)
    else
        wTmcScan = sc_GetSysEntry("tmc", "test_station_time", 3)
    end
end

function sc_wTmcAutoScan()
    if MODEL.tmc.station_tuned() then
        wTmcScan = sc_GetSysEntry("tmc", "hold_station_time", 15)
    elseif MODEL.EXISTS.tmc.present() and MODEL.tmc.present() then
        wTmcF1 = wTmcF2
        wTmcF2 = MODEL.tmc.current_station_frequency_short()
        if wTmcSearchMode and DOUBLE.new(tostring(wTmcF1)) > DOUBLE.new(tostring(wTmcF2)) then
            wTmcSearchMode = false
            wTmcSearch = -1
        end
        if wTmcScan > 0 then
            wTmcScan = wTmcScan - 1
        else
            if MODEL.lua.wTMCTunerMode() == 5 or MODEL.lua.wTMCTunerMode() == 2 or wTmcSearchMode and MODEL.lua.wTMCTunerMode() ~= 3 or MODEL.ui.wSelectStation.list.isempty() then
                MODEL.tmc.tuner_search_up()
            else
                wTmcSearch = wTmcSearch + 1
                if wTmcSearch < MODEL.ui.wSelectStation.list.size() then
                    MODEL.tmc.set_frequency_manual(MODEL.ui.wSelectStation[wTmcSearch].frequency())
                elseif MODEL.lua.wTMCTunerMode() == 3 then
                    wTmcSearch = -1
                else
                    wTmcSearch = -1
                    wTmcSearchMode = true
                    wTmcF1 = L"75"
                    wTmcF2 = wTmcF1
                    MODEL.tmc.set_frequency_manual(wTmcF1)
                end
            end
            wTmcScan = sc_GetSysEntry("tmc", "test_station_time", 3)
        end
    end
end

function sc_wTmcFixed()
    if MODEL.lua.wTMCFixedStation() == L"" then
        sc_wTmcAutoScan()
    elseif (not MODEL.tmc.station_tuned() or MODEL.tmc.current_station_frequency_short() ~= MODEL.lua.wTMCFixedStation()) and MODEL.EXISTS.tmc.present() and MODEL.tmc.present() then
        if wTmcScanFixed > 0 then
            wTmcScanFixed = wTmcScanFixed - 1
        else
            MODEL.tmc.set_frequency_manual(MODEL.lua.wTMCFixedStation())
            wTmcScanFixed = sc_GetSysEntry("tmc", "test_fixedstation_time", 2)
        end
    end
end

function sc_wEnterfreqFixedStation()
    sc_wEditStationFrequency_init(MODEL.lua.wTMCFixedStation(), sc_wInputFrequencyFixedStationDone)
end

function sc_wInputFrequencyFixedStationDone()
    MODEL.lua.wTMCFixedStation = ui.inpwFrequency.VALUE()
    sc_back()
end

function sc_wAutoAddTmcStation()
    if MODEL.ui.wSelectStation.list.size() < sc_GetSysEntry("tmc", "saved_stations", 30) then
        wTmcF1 = wTmcF2
        wTmcF2 = MODEL.tmc.current_station_frequency_short()
        if DOUBLE.new(tostring(wTmcF2)) > DOUBLE.new("108") or DOUBLE.new(tostring(wTmcF1)) < DOUBLE.new("75") then
            return
        end
        local station_exist = false
        for item in ModelList_iter(MODEL.ui.wSelectStation) do
            if DOUBLE.new(tostring(item.frequency())) == DOUBLE.new(tostring(MODEL.tmc.current_station_frequency_short())) then
                station_exist = true
                break
            end
        end
        if not station_exist then
            ui.wSelectStation:add({
                name = MODEL.tmc.current_station_name(),
                frequency = MODEL.tmc.current_station_frequency_short()
            })
            MODEL.ui.wSelectStation.save()
        end
    end
end

function sc_wSelectStation()
    sc_NextStateAnim(st_wSelectStation, "horz_scroll", 1, "")
end

createState("st_wSelectStation")
st_wSelectStation:useLayers(backgroundLayers, "ui_List_Background", "ui_wSelectStation")
function st_wSelectStation.init()
    txtTitle.TEXT = m_i18n("Select station")
end

function sc_wSelectStationOnRelease()
    if MODEL["*"].frequency() ~= L"" then
        MODEL.tmc.set_frequency_manual(MODEL["*"].frequency())
    end
    sc_back()
end

function sc_wSelectStationDel_OnRelease()
    local text = translated_format(m_i18n("Are you sure you want to delete this station from list?"))
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line_wstr(1, text)
    MODEL.screen.msgbox.new.set_line_wstr(2, MODEL["*"].name())
    MODEL.screen.msgbox.new.setup_button(1, "sc_wSelectStationDel_OnRelease_OK", m_i18n("Delete"), "", "ico_del_sml.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_wSelectStationDel_OnRelease_OK()
    MODEL.ui.wSelectStation.remove(MODEL.ui.wSelectStation.list.index())
    MODEL.ui.wSelectStation.save()
end

function sc_wSelectStationAll_OnRelease()
    MODEL.screen.msgbox.new.setup(2)
    MODEL.screen.msgbox.new.set_line(1, m_i18n("Are you sure you want to delete all stations from list?"))
    MODEL.screen.msgbox.new.setup_button(1, "sc_wSelectStationAll_OnRelease_OK", m_i18n("Delete All"), "", "ico_DeleteAll_mid.bmp#3")
    MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
    MODEL.screen.msgbox.create_new()
end

function sc_wSelectStationAll_OnRelease_OK()
    MODEL.ui.wSelectStation.clear()
    MODEL.ui.wSelectStation.save()
end

function sc_wAddSelectStation_OnRelease()
    ui.wSelectStation:add({name = L"", frequency = L""})
    MODEL.ui.wSelectStation.save()
    local add_index = MODEL.ui.wSelectStation.list.size() - 1
    local current = MODEL.ui.wSelectStation[add_index]
    wSettingDistOverIndex = add_index
    MODEL.lua.wSettingDistSoundName = current.name()
    MODEL.lua.wSettingProgramParameter = current.frequency()
    sc_NextStateAnim(st_wSelectStationEdit, "horz_scroll", 1, "")
end

function sc_wSelectStationEdit_OnRelease()
    local current = MODEL["*"]
    wSettingDistOverIndex = index
    MODEL.lua.wSettingDistSoundName = current.name()
    MODEL.lua.wSettingProgramParameter = current.frequency()
    sc_NextStateAnim(st_wSelectStationEdit, "horz_scroll", 1, "")
end

createState("st_wSelectStationEdit")
st_wSelectStationEdit:useLayers(backgroundLayers, "ui_wSelectStationEdit")
function st_wSelectStationEdit.init()
    txtTitle.TEXT = m_i18n("Edit station entry")
end

function st_wSelectStationEdit.exit()
    local current = MODEL.ui.wSelectStation[wSettingDistOverIndex]
    current.name = MODEL.lua.wSettingDistSoundName()
    current.frequency = MODEL.lua.wSettingProgramParameter()
    MODEL.ui.wSelectStation.save()
end

function sc_wEditStationName()
    MODEL.regional.keyboard.smartkey_model("")
    inpSI_Text.VALUE = MODEL.lua.wSettingDistSoundName()
    inpSI_Text.EMPTYTITLE = m_i18n("<Enter Station Name>")
    MODEL.lua.easyShowDoneKey = true
    ui.vKeyTableDone = sc_EditStationNameDone
    inputFieldRequired = false
    txtTitle.TEXT = m_i18n("Set Station Name")
    sc_NextStateAnim(st_SimpleInputText, "fade", 1, "")
end

function sc_EditStationNameDone()
    MODEL.lua.wSettingDistSoundName = ui.inpSI_Text.VALUE()
    sc_back()
end

function sc_wEnterfreqManual()
    sc_wEditStationFrequency_init(L"", sc_wInputFrequencyManualDone)
end

function sc_wEditStationFrequency()
    sc_wEditStationFrequency_init(MODEL.lua.wSettingProgramParameter(), sc_wInputFrequencyDone)
end

function sc_wEditStationFrequency_init(startvalue, donescript)
    sc_NextStateAnim(st_wInputFrequency, "horz_scroll", 1, "")
    inpwFrequency.VALUE = startvalue
    ui.vKeyTableDone = donescript
end

createState("st_wInputFrequency")
st_wInputFrequency:useLayers(backgroundLayers, "ui_wInputFrequency")
function st_wInputFrequency.init()
    MODEL.lua.easyShowDoneKey = true
    local keyboard = MODEL.regional.keyboard
    keyboard.load_panel_by_type(EInputPanelType.Numeric)
    keyboard.load_panel_by_name(L"Core Numbers")
    sc_wInputFrequency_onchange()
    keyboard.smartkey_model("lua.validator_chars")
    MODEL.lua.keyb_done = MODEL.lua.validator_done()
    keyboard.modifiers = 0
    inpwFrequency.EMPTYTITLE = translated_format(m_i18n("<Enter Number (%s)>"), L"75.0-108.0")
    inpwFrequency:SELECT()
    inpwFrequency:SYNCKBPANEL()
    txtTitle.TEXT = m_i18n("Set Station Frequency")
end

function st_wInputFrequency.done()
    closeKeyboard:trigger()
    MODEL.regional.keyboard.on_close_panel()
    MODEL.regional.keyboard.smartkey_model("")
end

function sc_wInputFrequency_onchange()
    sc_CheckNextChar("double", ui.inpwFrequency.VALUE(), "75.00", "108.00", 1)
    MODEL.lua.keyb_done = MODEL.lua.validator_done()
end

function sc_wInputFrequencyManualDone()
    MODEL.tmc.set_frequency_manual(ui.inpwFrequency.VALUE())
    sc_back()
end

function sc_wInputFrequencyDone()
    MODEL.lua.wSettingProgramParameter = ui.inpwFrequency.VALUE()
    PREVSTATE()
end

sc_TMC_SearchResult_orig = sc_TMC_SearchResult
function sc_TMC_SearchResult()
    sc_TMC_SearchResult_orig()
    if MODEL.lua.tmcWasPresented() and MODEL.tmc.present() then
        sc_wTmcChangeTunning()
    end
end

st_Traffic_Summary:removeLayers(localMenuLayers)
function st_Traffic_Summary.init()
    txtTitle.TEXT = m_i18n("Traffic Summary")
    MODEL.traffic.events.auto_update(true)
    sc_UpdateNextTrafficEventText()
    nextEventUpdateTimerId = doDelayed(100, sc_UpdateNextTrafficEventText, true)
    MODEL.lua.wLocalMenuHide = true
end

st_Traffic_Summary_done_orig = st_Traffic_Summary.done
function st_Traffic_Summary.done()
    MODEL.lua.wLocalMenuHide = false
    st_Traffic_Summary_done_orig()
end

function sc_LocalMenuOpenTrafficSettings()
    gTmcSettingsFromSum = true
    sc_btnASM_Traffic_OnRelease()
end

function sc_w_timer()
    if MODEL.lua.wTMCTunerMode() == 5 then
        sc_wTmcFixed()
    elseif MODEL.lua.wTMCTunerMode() > 1 then
        sc_wTmcAutoScan()
    end
end

