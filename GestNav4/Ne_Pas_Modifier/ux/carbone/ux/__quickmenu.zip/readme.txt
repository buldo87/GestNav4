Quick Menu *******************************************************************
This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

Historique des versions
-----------------------
1.4   04/10/2017 Msieurlolo
- Adaptation de l'ux quick_menu pour Medianav Evolution (Renault/Dacia) avec skin Carbone.

1.3   18/01/2015  THL
- Ajout : [softsoft] Support de la r�solution d'�cran 400_240.

1.2   18/10/2014  THL
- Ajout : �cran "A propos" accessible par un appui long sur le bouton de la rubrique [Personnaliser le menu rapide] du menu "R�glages"

1.1   29/05/2014  THL
- Version "multi-r�solutions" regroupant dans un seul Mod les diff�rentes r�solutions d'�cran (320_240, 480_272 et 800_480).

1.0   11/01/2014  THL
- Version initiale bas�e sur celle int�gr�e aux skins d'Aldo51, de la Team Phenix et de diMkaWA Tomsoft P171.

Description
-----------
Ce Mod UX regroupe la plupart des fonctions Primo dans 3 �crans du menu rapide (15 fonctions par �cran).

Installation
------------
Le fichier zip est � copier tel quel, sans le d�compresser et sans le renommer, dans le sous-r�pertoire UX.
Si le sous-r�pertoire UX n'existe pas, il doit �tre cr�� sous le r�pertoire principal dans lequel se situent le fichier ex�cutable de primo et le fichier data.zip.

Configuration
-------------
La configuration des boutons est r�alis�e apr�s appui sur le bouton de la rubrique [Personnaliser le menu rapide] du menu "R�glages" [Menu Navigation/Plus.../R�glages/Personnaliser le menu rapide].

Selon le type d'appui sur l'intitul� de la rubrique
  . court : acc�s � la configuration des boutons.
  . long : affiche l'�cran "A propos".

Utilisation
-----------
Les �crans de fonction sont accessibles par le "menu rapide".
L'appel d'une fonction est r�alis� par appui sur le bouton correspondant.
