-- Quick Menu ******************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

sc_thl_QM_Settings_OnRelease = function()
  sc_NextStateAnim(st_thl_QM_Settings, "horz_scroll", 1, "")
end

createState("st_thl_QM_Settings")
st_thl_QM_Settings:useLayers(backgroundLayers, "ui_thl_QM_Settings")
st_thl_QM_Settings.init = function()
  txtTitle:SET(m_i18n("Quick Menu Settings"))
end

sc_btnASM_CustomizeQuickMenu_OnRelease_orig = sc_btnASM_CustomizeQuickMenu_OnRelease
sc_btnASM_CustomizeQuickMenu_OnRelease = function()
  MODEL.ui.lst_MenuList.current_page = 0
  sc_NextStateAnim(st_CustomizeQuickMenu, "horz_scroll", 1, "")
end

sc_FindFirstNotUsedItemInFullList_orig = sc_FindFirstNotUsedItemInFullList
sc_FindFirstNotUsedItemInFullList = function()
  for item,index in ModelList_iter(MODEL.ui.fullMapLocalMenuList) do
    local used = false
    for i = 0, 14 do
      local itemIdx = PERSISTENT.savedMapLocalMenu[i]()
      if itemIdx == item.id() then
        used = true
      end
    end
    if not used then
      return index
    end
  end
end

sc_BuildMapLocalMenu_orig = sc_BuildMapLocalMenu
sc_BuildMapLocalMenu = function()
  local menuItems = {}
  for i = 0, 14 do
    local itemIdx = sc_FindItemInFullList(PERSISTENT.savedMapLocalMenu[i]())
    MODEL.ui.fullMapLocalMenuList[itemIdx].is_in_menu = true
    MODEL.ui.fullMapLocalMenuList[itemIdx].menu_index = i
    PERSISTENT.savedMapLocalMenu[i] = MODEL.ui.fullMapLocalMenuList[itemIdx].id()
  end
end

sc_ReplaceSelectedMapLocalMenuItem_orig = sc_ReplaceSelectedMapLocalMenuItem
sc_ReplaceSelectedMapLocalMenuItem = function(itemId)
  local oldId = PERSISTENT.savedMapLocalMenu[vMapMenuButtonAct]()
  local oldItemIdx = sc_FindItemInFullList(oldId)
  local newItemIdx = sc_FindItemInFullList(itemId)
  if MODEL.ui.fullMapLocalMenuList[newItemIdx].is_in_menu() then
    if itemId == oldId then
      return
    end
    local newItemIdxForSwap = MODEL.ui.fullMapLocalMenuList[newItemIdx].menu_index()
    MODEL.ui.fullMapLocalMenuList[oldItemIdx].menu_index = MODEL.ui.fullMapLocalMenuList[newItemIdx].menu_index()
    MODEL.ui.fullMapLocalMenuList[newItemIdx].menu_index = vMapMenuButtonAct
    PERSISTENT.savedMapLocalMenu[vMapMenuButtonAct] = itemId
    PERSISTENT.savedMapLocalMenu[newItemIdxForSwap] = oldId
  else
    MODEL.ui.fullMapLocalMenuList[oldItemIdx].is_in_menu = false
    MODEL.ui.fullMapLocalMenuList[oldItemIdx].menu_index = 100
    MODEL.ui.fullMapLocalMenuList[newItemIdx].is_in_menu = true
    MODEL.ui.fullMapLocalMenuList[newItemIdx].menu_index = vMapMenuButtonAct
    PERSISTENT.savedMapLocalMenu[vMapMenuButtonAct] = itemId
  end
end

