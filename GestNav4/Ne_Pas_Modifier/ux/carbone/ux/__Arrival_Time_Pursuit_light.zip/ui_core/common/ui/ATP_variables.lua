-- Arrival Time Pursuit ********************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

MODEL.SET.lua.thl_ATP_TmpTime = TIME_MODEL(0)
MODEL.SET.lua.thl_ATP_ShowArrTime = TIMESPAN_MODEL(0)
MODEL.SETPERSISTENT.lua.thl_ATP_Form = BOOL_MODEL(false)

MODEL.SET.lua.thl_ATP_Debug = BOOL_MODEL(false)
