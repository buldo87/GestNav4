-- Arrival Time Pursuit ********************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

st_EasyNav:useLayers("ui_EasyNav_THL_OrdiBord1")
st_EasyNav:useLayers("ui_EasyNav_THL_OrdiBord2")

-- Start Stop Observers --------------------------------------------------------
sc_thl_ATP_StartStopObs = function()
  if MODEL.lua.thl_ATP_Form() then
    obs_thl_ATP_timer:START()
  else
    obs_thl_ATP_timer:STOP()
  end
end

-- Reset -----------------------------------------------------------------------
sc_thl_ATP_Reset = function()
  MODEL.lua.thl_ATP_TmpTime = MODEL.navigation.eta_at_destination()
  MODEL.lua.thl_ATP_ShowArrTime = 0
end

-- Blink  ----------------------------------------------------------------------
sc_thl_ATP_Blink = function()
  if MODEL.lua.thl_ATP_Form() then
    if MODEL.navigation.has_route() then
      local DestATPETA = MODEL.navigation.eta_at_destination()
      local DestATPTmp = MODEL.lua.thl_ATP_TmpTime()
      local DestATPTmpFmt = tostring(DestATPTmp)
      if DestATPTmp > DestATPETA then
        MODEL.lua.thl_ATP_ShowArrTime = (DestATPTmp-DestATPETA)
      elseif DestATPTmpFmt == "0:0:0.0" then
        sc_thl_ATP_Reset()
      else
        MODEL.lua.thl_ATP_ShowArrTime = (DestATPTmp-DestATPETA) * -1
      end
    else
      sc_thl_ATP_Reset()
    end
  else
    sc_thl_ATP_StartStopObs()
  end
end

-- Msgbox ----------------------------------------------------------------------
sc_thl_ATP_Msgbox = function()
  sc_back_to_cockpit()
  MODEL.screen.msgbox.new.setup(2)
  MODEL.screen.msgbox.new.set_line(1, m_i18n("Are you sure you want to reset the trip computer?"))
  MODEL.screen.msgbox.new.setup_button(1, "sb_resetOrdi", m_i18n("Yes"), L"", "ico_done_mid.bmp#3")
  MODEL.screen.msgbox.new.setup_button(2, "", m_i18n("No"), L"", "ico_cancel_mid.bmp#3")
  MODEL.screen.msgbox.create_new()
end

-- About -----------------------------------------------------------------------
sc_thl_ATP_About = function()
  ui_xhtml_sublayer.FILENAME = "ui_core/" .. tostring(uiRes) .. "/ui/ATP_about.xhtml"
  sc_NextStateAnim(st_xhtml, "fade", 1, "")
  txtTitle.TEXT = "About"
end