function sc_OtherPoi_Search_ByCat()
	if gPOIResults ~= 0 then
		sc_OtherPoi_SetupSearch()
		sc_NextStateAnim(st_FindPOIStructuredList, "horz_scroll", 1, "");
	end	
	gPOIResults = 1	
end

do
	local old_func = sc_first_start_default_settings
	function sc_first_start_default_settings()
		old_func()
		MODEL.lua.tripInfoVisible = true
		MODEL.warning.speedlimit_warning_visual = false
		MODEL.warning.speedlimit_warning_voice = false 
		MODEL.sound.ding_muted = true
		MODEL.lua.Currency = L"PKR"
		MODEL.regional.units = 1
		gSetDefaultVolumeUnit = false
		MODEL.lua.volume_unit = EVolumeUnit.lpkm
	end
end		

do
	local old_func = sc_SetAutoRecordedTrackVisibility
	function sc_SetAutoRecordedTrackVisibility()
		old_func()
		local isVisible = MODEL.BOOL.mydata.tracks.list.current.visible()
		if isVisible then 
			MODEL.lua.TrackShowOnMap = true
		end	
	end
end	

function sc_SearchCarBrandPOI()
	sc_ForcePoiInit()
	MODEL.poi.flat_search.reset()
	MODEL.poi.flat_search.name_filter = MODEL.lua.nBrandName()
	MODEL.poi.flat_search.search_root = MODEL.poi.find_group("Automotive")
	MODEL.poi.flat_search.area = 500000
	MODEL.poi.flat_search.max_result = 100
	MODEL.poi.flat_search.sort = "distance"
	MODEL.poi.flat_search.execute()
	sc_NextStateAnim(st_FindPOIFlatList, "horz_scroll", 1, "");
end

MODEL.SETPERSISTENT.lua.nBrandName = WSTRING_MODEL(L"Renault")
MODEL.SETPERSISTENT.lua.nBrandIcon = CSTRING_MODEL("ico_Renault.bmp")
createState("st_ChoiceBrand")
st_ChoiceBrand:useLayers(backgroundLayersNoFooter, "ui_ChoiceBrand", "ui_ChoiceBrand_footer", "ui_List_Background")

st_ChoiceBrand.init = function()
  txtTitle:SET(sc_st_ChoiceBrandTitle())
end

sc_st_ChoiceBrandTitle = function()
    return m_i18n("Car Choice Brand")
end

sc_nRunChoiceBrand = function()
  sc_NextStateAnim(st_ChoiceBrand, "horz_scroll", 1, "")
  sc_nCreateListBrand()
end

sc_nCreateListBrand = function()
   MODEL.ui.brandlist.clear()
   local brand = {"Abarth", "Acura", "Alfa Romeo", "Aston Martin", "Audi", "Bentley", "BMW", "Bugatti", "Buick", "Cadillac", "Chery", "Chevrolet", "Chrysler", "Citroen", "Dacia", "Daf", "Daewoo" , "Daihatsu", "Datsun", "Dodge", "Ferrari", "Fiat", "Fisker", "Ford", "GAZ", "Holden", "Honda", "Hummer", "Hyundai", "Infiniti", "Iris", "Iveco", "Jaguar", "Jeep", "Kia", "Lada", "Lamborghini", "Lancia", "Land Rover", "Lexus", "Lotus","LPG", "Maserati", "Maybach", "Mazda", "Mercury", "Mersedes Benz", "Mini", "Mitsubishi", "Nissan", "Opel", "Pagani", "Peugeot", "Pontiac", "Porshe", "Proton", "Renault", "Rolls Royce", "Rover", "Saab", "Scania", "Scion", "Seat", "Skoda", "Smart", "Ssang Yong", "Subaru", "Suzuki", "Toyota", "Vanhool", "Vauxhall", "Volkswagen", "Volvo"}
	 for i = 1, #brand, 1 do
	    ui.brandlist:add({name = brand[i], icon = tostring("ico_" .. brand[i] .. ".bmp")})       
	 end
   MODEL.ui.brandlist.save()
end

sc_nMemberChoice = function()
   MODEL.lua.nBrandName = MODEL["*"].name()
   MODEL.lua.nBrandIcon = MODEL["*"].icon() 
   sc_back()
end  

sc_nIconBrand = function()
   return MODEL.lua.nBrandIcon()
end
