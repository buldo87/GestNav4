Arrival Time Pursuit ***********************************************************
This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

Historique des versions
-----------------------
5.1   25/04/2024 cacou13
- modif image et format pour adaptation skin bleu
insertion trad allemand faite par Vukasin

5.0   03/01/2015  THL
- Ajout : choix entre les formats "ordinateur de bord DT" et "bouton 3in1".
- Am�lioration : positionnement des informations en alignement avec celles du bouton "3 en 1" du Mod UX 3in1.

4.9   06/12/2014  THL
- Ajout : [softsoft] Support de la r�solution d'�cran 400_240.
- Am�lioration : Mod UX rendu ind�pendant du Mod UX de base dt_ux_WinCE_99_Base_Mods_UX_vx.x_THL_Multi_Res.zip

4.8   30/08/2014  THL
- Modification : la dur�e du trajet en cours adopte un format d'affichage variant en fonction de sa valeur. "SS sec" jusqu'� 59 secondes, "MN min" jusqu'� 59 minutes et "HH:MN" au del�.
- Modification : le pourtour de l'information d'�cart de dur�e est d�sactiv� en mode nuit. Pour �tre lisible, il continue � �tre activ� en mode jour en cas d'avance (affichage en vert)et, en cas de retard (affichage en rouge), le pourtour est activ� uniquement lorsque la transparence du bouton "Ordinateur de Bord" n'est pas compl�tement opaque.
- Modification : prise en compte des nouveaux noms du Mod UX de base commune dt_ux_WinCE_99_Base_Mods_UX_vx.x_THL_Multi_Res.zip et de la variable de d�tection de son installation.

4.7   27/08/2014  THL
- Ajout : �cran "A propos" accessible par un appui long sur le bouton, ou la case � cocher, de la rubrique "Suivre l'heure d'arriv�e" du menu "R�glage du guidage visuel".
- Modification : le format de l'information de distance parcourue a �t� modifi� pour permettre son affichage sur les versions Primo 2.0. Cette modification conduit � ce que l'unit� de distance (km ou m) n'est plus affich�e en exposant (en haut) mais en indice (en bas).
- Modification : suppression des secondes du format d'affichage de la dur�e du trajet en cours (1:10:36 => 1:10).

4.6   31/07/2014  THL
- Am�lioration : diminution de la taille de la police d'indication d'�cart de dur�e.
- Modification : r�tablissement du format d'affichage de l'information d'�cart de dur�e utilis� avant la version 4.5 (+ 20 sec vs + 00:20)

4.5   26/07/2014  THL
- �volution : [Kamille] Uniformisation de la forme du bouton avec celui des boutons 3in1.

4.4   29/06/2014  THL
- Am�lioration : ajout d'une variable pour permettre le contr�le de sa pr�sence par les Mods UX pour lesquels ce Mod UX "Base EasyNav_Main" doit �tre install� afin d'�viter des probl�mes d'affichage.

4.3   07/05/2014  THL
- Correction : de l'absence d'affichage du bouton "ordinateur de bord" pour la r�solution 480_272.
- Am�lioration : de la gestion du d�marrage automatique de l'observateur d'�v�nement (ATP_observer.ui).
- Am�lioration : version "multi-r�solutions" regroupant dans un seul Mod les diff�rentes r�solutions d'�cran (320_240, 480_272 et 800_480).

4.2   15/03/2014  THL
- Modification : de la gestion des �l�ments de l'�cran de navigation.
  ==> Le Mod UX de base, commun � plusieurs Mods UX, dt_ux_WinCE_99_Base_Mods_UX_vx.x_THL_Multi_Res.zip doit �tre aussi install�.

4.1   05/03/2014  THL
- Correction : de la gestion de la sauvegarde du pointeur vers sc_start_customize dans ATP.lua afin de permettre le d�marrage de l'autorad.

4.0   21/12/2013  THL
- Modification : transfert de la gestion du choix du type d'affichage dans le menu "R�glage du guidage visuel" avec cr�ation d'une ic�ne sp�cifique.
- Modification : de la forme et de la taille de la zone de l'ordinateur de bord sur l'�cran de navigation (forme du skin DT remplac�e par la forme 3D Tomsoft).
- Modification : renommage du Mod UX avec le nom complet au lieu de son abr�viation + indication de la r�solution pour laquelle il est d�velopp� en fin de nom.

3.0   07/12/2013  THL
- Modification : de la zone de l'ordinateur de bord sur l'�cran de navigation en bouton 3D si le Mod UX I3D est utilis�.
- Am�lioration : augmentation des espaces entre les informations affich�es dans la zone de l'ordinateur de bord sur l'�cran de navigation pour une meilleure lisibilit�.

2.0   11/11/2013  THL
- Modification : de l'affichage de l'information en adoptant une �crire verte ou rouge et un pourtour blanc d'un pixel (480_272) � deux pixels (800_480).
- Modification : de la forme de la zone de l'ordinateur de bord sur l'�cran de navigation (forme du skin DT rempla�ant la forme 3D Tomsoft).
- Modification : renommage du Mod UX pour �tre conforme avec les conventions de nommage DT et pour le classement dans le menu "Extras".

1.1   01/11/2013  THL
- Am�lioration : du positionnement de l'information dans la zone de l'ordinateur de bord.
- Am�lioration : de la gestion de la r�initialisation du compteur en cas de nouveau trajet et du d�marrage de primo avec un trajet existant.
- Ajout : d'un pourtour color� en fonction du retard ou de l'avance.
- Modification : de la couleur de l'information selon le mode jour ou nuit.
- Am�lioration : traduction en fran�ais du libell� "Suivre l'heure d'arriv�e" du param�tre d'affichage dans le fichier "040c.lang".

1.0   21/09/2013  THL
- Version initiale bas�e sur la fonction issue du skin diMkaWA Tomsoft P171.

Description
-----------
Ce Mod UX ajoute une information d'�cart de dur�e par rapport � l'heure d'arriv�e initialement estim�e.

L'information est ajout�e � l'ordinateur de bord sans tachym�tre lorsque celui-ci est activ� sur l'�cran de navigation.

Elle est pr�c�d�e :
- du signe "-" et de couleur verte en cas d'avance,
- du signe "+" et de couleur rouge en cas de retard,
par rapport � l'heure d'arriv�e estim�e lors du dernier calcul du trajet.

Installation
------------
Le fichier zip est � copier tel quel, sans le d�compresser et sans le renommer, dans le sous-r�pertoire UX.
Si le sous-r�pertoire UX n'existe pas, il doit �tre cr�� sous le r�pertoire principal dans lequel se situent le fichier ex�cutable de primo et le fichier data.zip.

Configuration
-------------
L'activation de la fonction est r�alis�e depuis le bouton de la rubrique [Suivre l'heure d'arriv�e] du menu "R�glage du guidage visuel" [Menu Navigation/Plus.../R�glages/R�glage du guidage visuel/Suivre l'heure d'arriv�e].

Selon le type d'appui sur l'intitul� de la rubrique [Policier anim�]
  . court : alterne les choix possibles entre "Forme 3in1" (format du bouton 3 en 1), "Forme DT" (format du bouton de la DT) et "�teint" (fonction d�sactiv�e).
  . long : affiche l'�cran "A propos".

Utilisation
-----------
Sur la zone de l'ordinateur de bord sur l'�cran de navigation :
- Un appui court r�initialise le compteur d'�cart de dur�e.
- Un appui long permet d'acc�der aux informations d�taill�es de l'ordinateur de bord.
- Un appui long sur la zone d'informations d�taill�es permet la r�initialisation des informations de l'ordinateur de bord apr�s confirmation.

Lorsque la fonction est d�sactiv�e (choix "�teint"), on retrouve le format et le fonctionnement du bouton de l'ordinateur de bord du skin de la DreamTeam.
