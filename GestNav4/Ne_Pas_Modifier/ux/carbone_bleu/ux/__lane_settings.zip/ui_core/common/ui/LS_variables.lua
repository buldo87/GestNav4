-- Lane Settings ***************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.
-- Adapté pour carbone par Jthiriet et Buldo
MODEL.SETPERSISTENT.lua.thl_LS_Signpost = INT_MODEL(3)
MODEL.SETPERSISTENT.lua.thl_LS_SignpostRoad_Enable = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.thl_LS_SignpostHighway_Enable = BOOL_MODEL(true)

MODEL.SETPERSISTENT.lua.thl_LS_Lane = INT_MODEL(3)
MODEL.SETPERSISTENT.lua.thl_LS_LaneRoad_Enable = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.thl_LS_LaneHighway_Enable = BOOL_MODEL(true)

MODEL.SETPERSISTENT.lua.SbTransLane = INT_MODEL(15)
MODEL.SETPERSISTENT.lua.SbTransSignPost = INT_MODEL(15)
MODEL.SETPERSISTENT.lua.SBSignpostOn = BOOL_MODEL(true)

MODEL.SETPERSISTENT.lua.JunctionViewPosition = INT_MODEL(false)

