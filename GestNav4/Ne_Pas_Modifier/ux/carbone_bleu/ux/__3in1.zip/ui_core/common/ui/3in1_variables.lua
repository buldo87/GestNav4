-- 3in1 ************************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

MODEL.SETPERSISTENT.lua.thl_3in1_Enable = BOOL_MODEL(true)
MODEL.SET.lua.thl_3in1_Azimuth = PROXY_INT_MODEL({
  getter = function()
    local azimuth = (360 - (MODEL.navigation.car.heading() * 45 / 512))
    if azimuth == 360 then
      azimuth = 0
    end
    return azimuth
  end,
  observe = MODEL.navigation.car.heading
})
