MODEL.SET.lua.WML_NextTrafficEventText_OnMap = WSTRING_MODEL(L"")
MODEL.SETPERSISTENT.lua.ViewTMC_onMap = BOOL_MODEL(true)
MODEL.SET.lua.TMC_Active = BOOL_MODEL(false)
st_EasyNav:useLayers(primary, "ui_morco_TMConMap")
MODEL.SETPERSISTENT.lua.CTMCI = INT_MODEL(16711680)
MODEL.SETPERSISTENT.lua.CTMCB = INT_MODEL(0)


if MODEL.lua.ViewTMC_onMap() then
    obs_ViewTMC_onMap:START("no_trigger")
else
    obs_ViewTMC_onMap:STOP()
end

createState("st_ColorTMC")
st_ColorTMC:useLayers(backgroundLayers, "ui_ColorTMC", "ui_List_Background")
function st_ColorTMC.init()
    txtTitle.TEXT = m_i18n("TMC Colors")
end

oldtmcevnt = L""
newtmcevnt = L""
function sc_TMCEventListChanged_onMap()
    obs_ViewTMC_onMap:STOP()
    if MODEL.traffic.events.significant_events.size() > 0 then
        MODEL.traffic.events.auto_update(true)
        sc_UpdateNextTrafficEventText_OnMap()
    else
        MODEL.lua.WML_NextTrafficEventText_OnMap = L"morco Tmc"
        oldtmcevnt = L""
        obs_ViewTMC_onMap:START("no_trigger")
        MODEL.lua.TMC_Active = false
    end
end

function sc_UpdateNextTrafficEventText_OnMap()
    local closestIndexOnMap = sc_GetClosestEventData()
    local fullDelayOnMap = MODEL.traffic.events.full_delay()
    local delayTextOnMap = sc_GetDelayText(fullDelayOnMap, MODEL.traffic.events.has_block_on_route())
    if delayTextOnMap == L"-0:00" then
        delayTextOnMap = L"0:00"
    end
    newtmcevnt = MODEL.traffic.events.significant_events["@" .. closestIndexOnMap].description()
    if MODEL.traffic.events.significant_events[closestIndexOnMap].distance() == 0 then
        MODEL.lua.WML_NextTrafficEventText_OnMap = newtmcevnt
    elseif MODEL.traffic.events.significant_events[closestIndexOnMap].distance() > 0 then
        MODEL.lua.WML_NextTrafficEventText_OnMap = translated_format(m_i18n("in %s"), Format_Distance(MODEL.traffic.events.significant_events[closestIndexOnMap].distance())) .. L" " .. newtmcevnt
    end
 MODEL.traffic.events.auto_update(false)
    obs_ViewTMC_onMap:START("no_trigger")

   
    oldtmcevnt = MODEL.traffic.events.significant_events["@" .. closestIndexOnMap].description()
end




