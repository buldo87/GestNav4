-- Next Maneuver Bar Graph *****************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.
MODEL.SETPERSISTENT.lua.sbFormatChrono = INT_MODEL(1)
MODEL.SETPERSISTENT.lua.sbchrono = BOOL_MODEL(true)

-- Settings --------------------------------------------------------------------
MODEL.SETPERSISTENT.lua.thl_NMBG_Enable = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.thl_NMBG_2D3D = BOOL_MODEL(true)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step0 = INT_MODEL(450)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step1 = INT_MODEL(350)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step2 = INT_MODEL(250)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step3 = INT_MODEL(180)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step4 = INT_MODEL(140)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step5 = INT_MODEL(100)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step6 = INT_MODEL(80)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step7 = INT_MODEL(60)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step8 = INT_MODEL(40)
MODEL.SETPERSISTENT.lua.thl_NMBG_Step9 = INT_MODEL(20)

-- BarGraph position settings --------------------------------------------------
MODEL.SET.lua.thl_NMBG_DragControlsVisible = BOOL_MODEL(true)

MODEL.SET.lua.thl_NMBG_top = INT_MODEL(0)
MODEL.SET.lua.thl_NMBG_right = INT_MODEL(0)
MODEL.SET.lua.thl_NMBG_w = INT_MODEL(0)
MODEL.SET.lua.thl_NMBG_h = INT_MODEL(0)

MODEL.SETPERSISTENT.lua.thl_NMBG_right_800 = INT_MODEL(17)
MODEL.SETPERSISTENT.lua.thl_NMBG_top_480 = INT_MODEL(2)
MODEL.SETPERSISTENT.lua.thl_NMBG_w_800 = INT_MODEL(13)
MODEL.SETPERSISTENT.lua.thl_NMBG_h_800 = INT_MODEL(128)


MODEL.SET.lua.thl_NMBG_DragUpEnable = BOOL_MODEL(true)
MODEL.SET.lua.thl_NMBG_DragDownEnable = BOOL_MODEL(true)
MODEL.SET.lua.thl_NMBG_DragLeftEnable = BOOL_MODEL(true)
MODEL.SET.lua.thl_NMBG_DragRightEnable = BOOL_MODEL(true)
