-- Next Maneuver Bar Graph *****************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

-- BarGraph position settings --------------------------------------------------
sc_thl_NMBG_Pos_Settings = function()

    MODEL.lua.thl_NMBG_right = MODEL.lua.thl_NMBG_right_800()
    MODEL.lua.thl_NMBG_top = MODEL.lua.thl_NMBG_top_480()
    MODEL.lua.thl_NMBG_w = MODEL.lua.thl_NMBG_w_800()
    MODEL.lua.thl_NMBG_h = MODEL.lua.thl_NMBG_h_800()

  sc_NextStateAnim(spr_thl_NMBG_Pos_Settings, "fade", 1, "")
end

createState("spr_thl_NMBG_Pos_Settings")
spr_thl_NMBG_Pos_Settings:useLayers(backgroundLayers, "ui_EasyNav_THL_NextMan", "ui_thl_NMBG_Pos_Settings")
spr_thl_NMBG_Pos_Settings.init = function()
  MODEL.lua.dragMode = false
  MODEL.map.primary.enter_state("NMBG_Pos_DragControls")
end
spr_thl_NMBG_Pos_Settings.done = function()
  MODEL.map.primary.exit_state()
end

sc_thl_NMBG_SetHorizontal = function()
  MODEL.lua.thl_NMBG_right_800 = MODEL.lua.thl_NMBG_right() 
  MODEL.lua.thl_NMBG_DragLeftEnable = (MODEL.lua.thl_NMBG_right() < btn_Manoeuvre.prop.W )
  MODEL.lua.thl_NMBG_DragRightEnable = (MODEL.lua.thl_NMBG_right() > MODEL.lua.thl_NMBG_w())
end


sc_thl_NMBG_SetVertical = function()
  MODEL.lua.thl_NMBG_top_480 = MODEL.lua.thl_NMBG_top() * 480 / uiResH
  MODEL.lua.thl_NMBG_DragUpEnable = (MODEL.lua.thl_NMBG_top() > 0)
  MODEL.lua.thl_NMBG_DragDownEnable = (MODEL.lua.thl_NMBG_top() < (btn_Manoeuvre.prop.H - MODEL.lua.thl_NMBG_h()))
end

sc_thl_NMBG_IconId2Bmp = function(IconId)
  local bmp, phase = nil, nil
  bmp, phase = MODEL.screen.get_icon_file_and_phase(IconId, provider_icon_index)
  return bmp
end

sc_thl_NMBG_Bmp2IconId = function(bmp)
  MODEL.screen.filter_unique_by_index(2)
  MODEL.screen.set_current_icongroup("poi")
  bmp = tostring(bmp)
  local iconid = -1
  local find = false
  local i = 0
  repeat
    if sc_thl_DBG_IconId2Bmp(i) == bmp then
      iconid = i
      find = true
    end
    i = i + 1
  until i > MODEL.screen.icons.size() - 1 or find
  return iconid
end

sc_thl_NMBG_BMP = function(bmp,defaultbmp)
  local isbmp = bmp
  if isbmp ~= nil then
    return bmp
  else
    return defaultbmp
  end
end

-- About -----------------------------------------------------------------------
sc_thl_NMBG_About = function()
  ui_xhtml_sublayer.FILENAME = "ui_core/" .. tostring(uiRes) .. "/ui/NMBG_about.xhtml"
  sc_NextStateAnim(st_xhtml, "fade", 1, "")
  txtTitle.TEXT = "About"
end