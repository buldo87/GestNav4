function sc_GetSysEntry_Init()
    if MODEL.EXISTS.other.weather() then
        MODEL.lua.showWeather = sc_GetSysEntry("interface", "show_weather", 1)
    end
    MODEL.lua.logbuldo = sc_GetSysEntry("carbone", "debug", 0)
    MODEL.lua.StationsEnabled = sc_GetSysEntry("poi", "enable_stations_for_japan", 0)
    MODEL.lua.petzaEnabled = sc_GetSysEntry("debug", "petza_enabled", 0)
    MODEL.lua.ShowBatteryPercent = sc_GetSysEntry("debug", "show_battery_percent", 0)
    noTravelMonkey = sc_GetSysEntry("debug", "no_travel_monkey", 0)
    noLogCollection = sc_GetSysEntry("debug", "no_logcollection_monkey", 0)
    MODEL.lua.Experimental_Features = sc_GetSysEntry("debug", "experimental_features", 0)
    MODEL.lua.smallBuild = sc_GetSysEntry("interface", "small_build", 0)
    MODEL.interface.uieffect_enabled = sc_GetSysEntry("debug", "animations", 1)
    gGoNavigationTimeout = sc_GetSysEntry("interface", "start_navigation_time", 10)
    MODEL.lua.ExtraSettings = sc_GetSysEntry("interface", "extra_settings", sc_GetSysEntry("interface", "ui_labs", 0))
    MODEL.lua.show_exit = sc_GetSysEntry("interface", "show_exit", 1)
    gShowMinimize = sc_GetSysEntry("interface", "show_minimize", false)
    MODEL.lua.wheelsound = sc_GetSysEntry("sound", "wheelsound", 0)
    gSkinDebug = sc_GetSysEntry("debug", "skindebug", 0)
    gPoiDistantDistance = sc_GetSysEntry("map", "poi_distant_distance", 3000)
    gMaxRealAlternativeCount = sc_GetSysEntry("route", "maximum_real_alternative_count", 4)
    gUseNightmodeInTunnel = sc_GetSysEntry("debug", "usenightmode_tunnel", 0)
    MODEL.lua.clearcityenabled = sc_GetSysEntry("interface", "clearcity", 0)
    tripOffset = sc_GetSysEntry("route", "trip_offset", 1000)
    MODEL.lua.automotive = sc_GetSysEntry("interface", "automotive", 0)
    MODEL.lua.priority_min = sc_GetSysEntry("other.taskmanager", "priority_min", 0)
    MODEL.lua.priority_max = sc_GetSysEntry("other.taskmanager", "priority_max", 255)
    MODEL.lua.truck_UI = sc_GetSysEntry("interface", "default_truck", 0)
    gFitOnlyRemaining = sc_GetSysEntry("interface", "fit_only_remaining", 1)
    MODEL.lua.RoutePlanningStateAnim = sc_GetSysEntry("interface", "route_planning_state_anim", 0)
    gMaxWaypointsSize = sc_GetSysEntry("route", "max_waypoints", 100)
    ui.vMapIsTheFirstState = sc_GetSysEntry("interface", "map_is_the_first_state", false)
    ui.vQuickMenuCloseDelay = sc_GetSysEntry("interface", "quick_menu_delay", 9)
    local swid = sc_GetSysEntry("swid", "activation", "device")
    if swid == "device" then
        activationLock = 1
    elseif swid == "card" then
        activationLock = 2
    else
        activationLock = 1
    end
        ui.vSyncToolExe = sc_GetSysEntry("interface", "synctool_exe", "")
        ui.vSyncToolDir = sc_GetSysEntry("interface", "synctool_dir", "")
        MODEL.lua.monkey_nopress = sc_GetSysEntry("debug", "monkey_nopress", 0)
    ui.vSynctoolStatus = MODEL.other.check_synctool()
    MODEL.mydata.history.sort_by_lasttime()
end

eMediaIconType = {
    "radio",
    "radio",
    "dab",
    "aux",
    "bt",
    "usb",
    "ipod",
    "phone",
    "aha",
    "siri",
	"carplay",
    "androidauto"
}
eScreenTypes = {
    Map = 0,
    Nav = 1,
    Home = 2,
    PointOnMap = 3,
    AHA = 4,
    Phone = 5,
    BackFromPhone = 6,
    BackFromSynctool = 7
}
eSynctoolScenarios = {
    AfterDefault = 0,
    AfterFingerprint = 1,
    AfterUpdate = 2,
    None = 3
}
eSynctoolStatus = {
    fine = 0,
    restored = 1,
    not_set = 2,
    not_found = 3
}
MODEL.SET.lua.TempoMute = INT_MODEL(1000)
function sc_GetMedia(phase)
    if phase >= 1 and phase <= 10 then
        return eMediaIconType[phase]
    end
    return ""
end

function sc_GestionSon()
    local tempo = 1000
    local media = sc_GetMedia(MODEL.other.lg_renault.media_type())
--    local params = "\"" .. " media=" .. "\"" .. media .. "\" tempo=\"" .. tempo .. "\""
--    START_APPLICATION("../Utility/GestionSon.exe", params)
end

function sc_loading_finished()
    MODEL.other.loading_finished = true
    startUp = false
	MODEL.other.create_process(true,L"//bin//bash",L"",L"//navi_rw//utility//restart//loading_finished.sh",false)
end

function sc_NavCtrl_ChangeMapColor(vMode)
    local FeuxCouleur = MODEL.lua.vEasyColorMode()
    if FeuxCouleur == 3 then
        MODEL.lua.vEasyColorMode = vMode
        sc_Set_DayNightMode()
        MODEL.lua.vEasyColorMode = 3
    end
end

function sc_Set_DayNightMode()
    local easyColorMode = MODEL.lua.vEasyColorMode()
    if easyColorMode == 0 then
        MODEL.map.auto_nightmode = false
        MODEL.screen.nightmode = false
    elseif easyColorMode == 1 then
        MODEL.map.auto_nightmode = false
        MODEL.screen.nightmode = true
    elseif easyColorMode == 2 then
        MODEL.map.auto_nightmode = true
    end
end

MODEL.SET.lua.monkey_nopress = BOOL_MODEL(false)
MODEL.lua.monkey_nopress = sc_GetSysEntry("debug", "monkey_nopress", 0)
function sc_lgHome(in_set_destination)
    local in_set_dest = false
    if in_set_destination ~= nil then
        in_set_dest = in_set_destination
    end
    MODEL.other.lg_renault.home_btn_pressed(in_set_dest)
end

function sc_Start_Screen_Handling()
    local scenario = MODEL.other.lg_renault.synctool_scenario()
    if scenario ~= eSynctoolScenarios.None then
        ui.vSynctoolStarted = 0
    end
    if scenario == eSynctoolScenarios.AfterFingerprint then
        NEXTSTATE(st_SettingsMenu)
        MODEL.lua.SettingsPaged = true
        NEXTSTATE(st_AboutContents)
    else
    end
end

function sc_Debug_Exit()
    MODEL.other.lg_renault.send_screen_message(eScreenTypes.Home)
    MODEL.other.lg_renault.initiate_shutdown()
end

function sc_Set_Voice_Testing_Mode(enabled)
    if enabled then
        MODEL.sound.tts_manager.starting_test()
    else
        MODEL.sound.tts_manager.stoping_test()
    end
    MODEL.other.lg_renault.voice_testing_mode = enabled
end

function sc_Is_LG_Screen(screenType)
    return MODEL.other.lg_renault.identify_lg_screen(screenType)
end

function sc_NavCtrl_ScreenChange(screenType)
    debug_log("lg_renault", 3, "lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
    sc_HwKeySelect()
    if screenType == eScreenTypes.Map then
        sc_GoToMap()
    elseif screenType == eScreenTypes.Nav then
        if MODEL.other.lg_renault.eco_support() then
            sc_GoToMap()
        else
            sc_GoTo_MainMenu()
        end
	elseif screenType == eScreenTypes.BackFromSynctool then
        debug_log("lg_renault", 3, "Looks like we\'re just back from synctool. Going to content screen.")
        NEXTSTATE(st_AboutContents)
	
    else
        debug_log("lg_renault", 1, "SERIOUS screen-change PROBLEM: lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
        sc_GoTo_MainMenu()
    end
end

function sc_Screen_Control(hook, screenType)
    local lgModel = MODEL.other.lg_renault
    debug_log("lg_renault", 3, "lua sc_Screen_Control screenType = " .. tostring(screenType))
    if lgModel.navi_on_voice_settings_screen() then
        if screenType == eScreenTypes.Phone then
            sc_Set_Voice_Testing_Mode(false)
        elseif screenType == eScreenTypes.BackFromPhone then
            sc_Set_Voice_Testing_Mode(true)
        end
    end
    if sc_Is_LG_Screen(screenType) then
        if lgModel.voice_testing_mode() then
            sc_Set_Voice_Testing_Mode(false)
        end
        lgModel.disable_render()
    else
	    MODEL.screen.msgbox.on_screen.close()
        lgModel.enable_render()
        if screenType == eScreenTypes.PointOnMap then
            lgModel.go_to_point_on_map()
        elseif screenType ~= eScreenTypes.BackFromPhone then
            sc_NavCtrl_ScreenChange(screenType)
        end
        lgModel.force_render_screen()
        lgModel.put_main_window_on_top()
    end
    lgModel.send_screen_message(screenType)
end

function sc_GetMediaButtonIcon(phase)
    local night = MODEL.other.lg_renault
    if phase >= 1 and phase <= 10 then
        return "ico_media_" .. eMediaIconType[phase] .. ".bmp#3"
    end
    return ""
end

function sc_SynctoolUpdate_onRelease()
    sc_close_local_menu()
    ui.vSynctoolStarted = 1
    local retval = MODEL.other.lg_renault.synctool_update_button_pressed()
    if retval == 0 then
        debug_log("lg_renault", "Synctool successfully started", 3)
        sc_NavCtrl_ShowWaitScreen()
    else
        debug_log("lg_renault", string.format("Cannot start synctool: %s", tostring(retval)), 2)
    end
end

function sc_StartSynctool()
    ui.vSynctoolStarted = 1
    if MODEL.other.create_process(0, towstring(ui.vSyncToolExe), towstring(ui.vSyncToolDir)) == 0 then
        MODEL.other.lg_renault.synctool_not_running = 0
        ui_PoiInitPleaseWait:SHOW()
    end
end

function sc_NavCtrl_ShutdownNavi()
    MODEL.screen.save_state_queue("synctool")
end

function sc_NavCtrl_ShowWaitScreen()
    ui_PoiInitPleaseWait:SHOW()
end

function sc_NavCtrl_HideWaitScreen()
    ui_PoiInitPleaseWait:HIDE()
end







tBatteryChargeLevels = {
    [0] = 0,
    [1] = 1,
    [2] = 1,
    [3] = 2,
    [4] = 3,
    [5] = 3
}
function sc_MakeValidBatteryGsmSignalValue(signal_name, signal_value, valuemin, valuemax)
    if valuemax < signal_value then
        debug_log("lg_renault", string.format("sc_MakeValidBatteryGsmSignalValue(): *** MODEL.other.lg_renault.%s() is INVALID!!! (%d)", signal_name, signal_value), 3)
        signal_value = valuemax
    elseif valuemin > signal_value then
        debug_log("lg_renault", string.format("sc_MakeValidBatteryGsmSignalValue(): *** MODEL.other.lg_renault.%s() is INVALID!!! (%d)", signal_name, signal_value), 3)
        signal_value = valuemin
    end
    return signal_value
end

function sc_getBatteryPhase()
    local batt_sig = MODEL.other.lg_renault.battery_signal()
    batt_sig = sc_MakeValidBatteryGsmSignalValue("battery_signal", batt_sig, 0, 5)
    debug_log("lg_renault", string.format("sc_getBatteryPhase(): MODEL.other.lg_renault.battery_signal()=%d, tBatteryChargeLevels[%d]=%d", MODEL.other.lg_renault.battery_signal(), batt_sig, tBatteryChargeLevels[batt_sig]), 3)
    return tBatteryChargeLevels[batt_sig]
end

function sc_getGsmPhase()
    local gsm_sig = MODEL.other.lg_renault.gsm_signal()
    gsm_sig = sc_MakeValidBatteryGsmSignalValue("gsm_signal", gsm_sig, 0, 5)
    debug_log("lg_renault", string.format("sc_getBatteryPhase(): MODEL.other.lg_renault.gsm_signal()=%d (%d)", MODEL.other.lg_renault.gsm_signal(), gsm_sig), 3)
    return gsm_sig
end

function sc_CheckCoordinatesEquality(waypoint, gcoor2, distanceBased)
    return waypoint.real_position() == gcoor2 or distanceBased and MODEL.other.calc_distance(waypoint.real_position(), gcoor2) <= gMaxDistanceBetweenEqualCoordinates or waypoint.history.position() == gcoor2 or distanceBased and MODEL.other.calc_distance(waypoint.history.position(), gcoor2) <= gMaxDistanceBetweenEqualCoordinates or waypoint.strapped_position() == gcoor2 or distanceBased and MODEL.other.calc_distance(waypoint.strapped_position(), gcoor2) <= gMaxDistanceBetweenEqualCoordinates
end

function sc_IsFollowingDuplicatedWaypoint(position)
    local position = position or MODEL.my.map.selected_item.position()
    local waypoints = MODEL.route.list.navigated.waypoints.list
    local distanceBased = true
    if EditRouteAddVIA == EAddViaMode.AddToEnd then
        local lastWaypoint = waypoints[#waypoints - 1]
        if sc_CheckCoordinatesEquality(lastWaypoint, position, distanceBased) then
            return true
        end
    elseif EditRouteAddVIA == EAddViaMode.InsertVia then
        local idx = waypoints.index()
        local actWaypoint = waypoints[idx]
        local nextWaypoint = waypoints[idx + 1]
        if sc_CheckCoordinatesEquality(actWaypoint, position, distanceBased) and idx ~= 0 or sc_CheckCoordinatesEquality(nextWaypoint, position, distanceBased) then
            return true
        end
    elseif EditRouteAddVIA == EAddViaMode.ChangeStart and #waypoints > 1 then
        local nextWaypoint = waypoints[waypoints.index() + 1]
        if sc_CheckCoordinatesEquality(nextWaypoint, position, distanceBased) then
            return true
        end
    end
    return false
end

function sc_CalculatTempWidth(temp)
    return string.len(temp) * CSS.Param.status_temp_char_width + CSS.Param.status_temp_padding
end





