MODEL.SET.lua.SelectMapContent = BOOL_MODEL(false)
MODEL.SET.lua.ReleaseFournisseur = BOOL_MODEL(false)
MODEL.SET.lua.ChangeMapOk = BOOL_MODEL(false)
MODEL.SET.lua.ReleaseMap = BOOL_MODEL(true)
MODEL.SET.lua.herepicture = BOOL_MODEL(false)
MODEL.SET.lua.tomtompicture = BOOL_MODEL(false)
MODEL.lua.SelectMapContent = sc_GetSysEntry("interface", "select_map_content")
MODEL.SET.lua.ChoixFournisseur = CSTRING_MODEL("")
MODEL.SET.lua.ActifFournisseur = CSTRING_MODEL("")
MODEL.SET.lua.MapStorage = CSTRING_MODEL("")
function sc_SelectMapContent()
    sc_NextStateAnim(st_SelectMapContent, "horz_scroll", 1, "")
end

createState("st_SelectMapContent")
st_SelectMapContent:useLayers(backgroundLayers, "ui_SelectMapContent", localMenuLayers)
function st_SelectMapContent.init()
    txtTitle:SET(m_i18n("Select Map Provider"))
    sc_init_local_menu("ui.lm_content_mapchanger.list")
    MODEL.lua.MapStorage = sc_GetSysEntry("mapchanger", "storage", "str")
    MODEL.lua.ActifFournisseur = sc_GetSysEntry("mapchanger", "fournisseur", "map")
    MODEL.lua.ReleaseFournisseur = MODEL.map.prefer_larger_supplierid()
    if sc_GetSysEntry("mapchanger", "fournisseur", "map") == "map" then
        MODEL.lua.ReleaseMap = true
    else
        MODEL.lua.ReleaseMap = false
    end
    MODEL.lua.ChangeMapOk = false
end

function sc_GetSysEntry_Init_addon()
    MODEL.lua.SelectMapContent = sc_GetSysEntry("interface", "select_map_content")
end

StateExtender = createState({
    init = function()
        sc_GetSysEntry_Init_addon()
    end
})
st_Start.extends = {
    StateExtender,
    var.unpack(st_Start.extends)
}
if MODEL.lua.ActifFournisseur() == "tomtom" then
    MODEL.lua.tomtompicture = true
    MODEL.lua.herepicture = false
elseif MODEL.lua.ActifFournisseur() == "here" then
    MODEL.lua.tomtompicture = false
    MODEL.lua.herepicture = true
elseif MODEL.map.prefer_larger_supplierid() == true then
    MODEL.lua.tomtompicture = true
    MODEL.lua.herepicture = false
else
    MODEL.lua.herepicture = true
    MODEL.lua.tomtompicture = false
end
function sc_MapchangerRelease()
    MODEL.lua.ChangeMapOk = true
end

function sc_btnMapChange_OnRelease()
    if MODEL.lua.ReleaseMap() == true then
        MODEL.lua.ChoixFournisseur = "map"
    elseif MODEL.lua.ReleaseFournisseur() == true then
        MODEL.lua.ChoixFournisseur = "tomtom"
    else
        MODEL.lua.ChoixFournisseur = "here"
    end
    sc_ModifOK()
end

function sc_ModifOK()
    if MODEL.lua.ChangeMapOk() == true then
        MODEL.lua.ChangeMapOk = false
        local newMsgBox = MODEL.screen.msgbox.new
        newMsgBox.setup(3)
        newMsgBox.set_line(1, m_i18n("Please restart now"))
        newMsgBox.setup_button(1, "sc_SettingMapChange", m_i18n("OK"), "", "ico_done_mid.bmp#3")
        newMsgBox.setup_button(2, "sc_SettingMapChangeLater", m_i18n("No"), "", "ico_done2_mid.bmp#3")
        newMsgBox.setup_button(3, "", m_i18n("Cancel"), "", "ico_cancel_mid.bmp#3")
        MODEL.screen.msgbox.create_new()
    else
        sc_back()
    end
end

function sc_EnvoieMapchanger()
 --   local params = "\"" .. "\\Storage card4\\NNG\\Utility\\mapChanger.mscr" .. "\" fournisseur=\"" .. MODEL.lua.ChoixFournisseur() .. "\" storage=\"" .. MODEL.lua.MapStorage() .. "\""
	local params = "//navi_rw//utility//Mapchanger.sh " .. tostring(MODEL.lua.ChoixFournisseur()) .. " " .. tostring(MODEL.lua.MapStorage()) 
	MODEL.other.create_process(true,L"//bin//bash",L"",towstring(params),false)

 --   START_APPLICATION(exe, params)
  MODEL.map.prefer_larger_supplierid = MODEL.lua.ReleaseFournisseur() -------------------------- ?
end

function sc_SettingMapChange()
    sc_InfoMessageBox(m_i18n("Mercie de patienter ..."), true)
    sc_EnvoieMapchanger()
	local params = "//navi_rw//utility//restart//restart.sh appmain"
	MODEL.other.create_process(true,L"//bin//bash",L"",towstring(params),false)

 --   START_APPLICATION(exe, params)
 	doDelayed(100, function()
		sc_back()
		sc_Debug_Exit()
		
	end)

end

function sc_SettingMapChangeLater()
    sc_EnvoieMapchanger()
    sc_back()
end

