MODEL.SETPERSISTENT.lua.APVehicle_size = INT_MODEL(70)
MODEL.SET.lua.drivengine = CSTRING_MODEL("")
function sc_CarSize_Reset()
    MODEL.lua.APVehicle_size = 70
    MODEL.map.car_display.map_scale = MODEL.lua.APVehicle_size()
    MODEL.lua.SBCarPos3D = 71
    MODEL.lua.SBCarPos2DNu = 49
    MODEL.lua.SBCarPos2D = 71
end

function sc_vehicle_size()
    MODEL.map.car_display.map_scale = MODEL.lua.APVehicle_size()
end

MODEL.SET.lua.carDisplayCategory = INT_MODEL(0)
MODEL.SET.lua.carRotate = INT_MODEL(0)
vCarDisplayCategory = nil
EVehicleType = {
    Car = 0,
    Taxi = 1,
    Bus = 2,
    Truck = 3,
    Emergency = 4,
    Pedestrian = 5,
    Bicycle = 6,
    SlowCar = 7,
    FastCar = 8,
    MotorCycle = 9,
    Last = 9
}
function sc_makeVehicleList()
    local vehiclesTable = {
        EVehicleType.Car,
        EVehicleType.Emergency,
        EVehicleType.Pedestrian,
        EVehicleType.Bus,
        EVehicleType.Taxi,
        EVehicleType.Truck
    }
    local vehicle = MODEL.mydata.vehicle_profile
    local listSize = vehicle.list.size() - 1
    for cntr = listSize, 0, -1 do
        local vtype = vehicle.list[cntr].vehicle_type()
        local VehicleIsEnabled = false
        for cntr2 = 1, #vehiclesTable do
            if vtype == vehiclesTable[cntr2] then
                VehicleIsEnabled = true
                break
            end
        end
        if not VehicleIsEnabled then
            if cntr == 0 then
                vehicle.selected_profile = 1
            end
            vehicle.delete_profile(cntr)
        end
    end
    vehicle.selected_profile = 0
    MODEL.route.list.navigated.recalculate()
    vehicle.save_profiles()
end

function sc_btnSVM_CarDisplay_OnRelease()
    sc_NextStateAnim(st_SettingVisualCar, "horz_scroll", 1, "")
end

createState("st_SettingVisualCar")
st_SettingVisualCar:useLayers(backgroundLayers, "ui_Footer", "ui_SettingVisualCarModels", "ui_CarModelPreview2", uieffect, primary)
function st_SettingVisualCar.enter()
    MODEL.map.ui_carmodelpreview.mode = "model"
end

function st_SettingVisualCar.init()
	MODEL.lua.drivengine = sc_GetSysEntry("rawdisplay", "driver", "")
    txtTitle.TEXT = m_i18n("Vehicle Gallery")
    ui.primary.X = 549
    ui.primary.Y = 69
    ui.primary.W = 239
    primary:SCALE(float.new("1"))
    ui.primary.Z = 40
    ui.primary.H = 173
    gmemZoomMinimap = MODEL.map.primary.zoom()
end

function st_SettingVisualCar.done()
    primary.X = 0
    primary.Y = 0
    primary.Z = 0
    primary.W = mapResW
    primary.H = mapResH
    MODEL.map.primary.zoom = gmemZoomMinimap
end

function sc_SelectCarModel(displayCategory, categoryName, categoryIdx)
    MODEL.lua.carDisplayCategory = displayCategory
    vCarDisplayCategory = categoryName
    MODEL.map.car_display.models.index = categoryIdx
    sc_NextStateAnim(st_SettingVisualCar, "horz_scroll", 1, "")
end

function sc_setcar()
    ASSERT(vCarDisplayCategory ~= nil)
    MODEL[vCarDisplayCategory] = MODEL.map.car_display.models.index()
end

function sc_SetVehicleSpecificSettings()
    MODEL.map.show_oneway = true
    MODEL.sound.voice.guidance_enabled = true
    if MODEL.EXISTS.map.reset_breadcrumb() then
        MODEL.map.reset_breadcrumb()
    end
    if vehicleType == EVehicleType.Car then
        MODEL.map.car_display.set_category("car")
    else
        MODEL.map.car_display.set_category("other")
    end
    sc_SetPoiVisibilities()
end

