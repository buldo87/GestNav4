-- Quick Menu ******************************************************************
-- This Mod UX has been initially cooked by THL for the skin Sbertaud13 DreamTeam Primo 2.X WinCE.

MODEL.SETPERSISTENT.lua.QuickMenu15 = BOOL_MODEL(true)

PERSISTENT.QMsavedMapLocalMenu[0]("Favourites")
PERSISTENT.QMsavedMapLocalMenu[1]("Overview")
PERSISTENT.QMsavedMapLocalMenu[2]("Quick Place\nSearch")
PERSISTENT.QMsavedMapLocalMenu[3]("Map Settings")
PERSISTENT.QMsavedMapLocalMenu[4]("Visual Guidance Settings")
PERSISTENT.QMsavedMapLocalMenu[5]("Traffic")
PERSISTENT.QMsavedMapLocalMenu[6]("Avoid")
PERSISTENT.QMsavedMapLocalMenu[7]("Cancel Route/Remove Next Waypoint")

PERSISTENT.QMsavedMapLocalMenu[9]("Where Am I?")
PERSISTENT.QMsavedMapLocalMenu[10]("Create Route/Edit Route")

PERSISTENT.QMsavedMapLocalMenu[12]("Route Settings")

PERSISTENT.QMsavedMapLocalMenu[14]("History")
PERSISTENT.QMsavedMapLocalMenu[15]("Find Places")
PERSISTENT.QMsavedMapLocalMenu[16]("Simulate\nNavigation")

PERSISTENT.QMsavedMapLocalMenu[18]("GPS Info")
PERSISTENT.QMsavedMapLocalMenu[19]("Itinerary")

PERSISTENT.QMsavedMapLocalMenu[21]("Settings")
PERSISTENT.QMsavedMapLocalMenu[22]("Route menu")
--PERSISTENT.QMsavedMapLocalMenu[23]("Weather")
PERSISTENT.QMsavedMapLocalMenu[24]("Find")
PERSISTENT.QMsavedMapLocalMenu[25]("Exit")
PERSISTENT.QMsavedMapLocalMenu[26]("More...")
PERSISTENT.QMsavedMapLocalMenu[27]("Overview Mode")
--PERSISTENT.QMsavedMapLocalMenu[28]("Save Route")
--PERSISTENT.QMsavedMapLocalMenu[29]("Load Route")

PERSISTENT.QMsavedMapLocalMenu[31]("Parking")
PERSISTENT.QMsavedMapLocalMenu[32]("2d3d")
PERSISTENT.QMsavedMapLocalMenu[33]("Route Alternatives")
PERSISTENT.QMsavedMapLocalMenu[34]("Transparency")
PERSISTENT.QMsavedMapLocalMenu[35]("Colour")
--PERSISTENT.QMsavedMapLocalMenu[36]("Activation")
PERSISTENT.QMsavedMapLocalMenu[37]("Map provider")
PERSISTENT.QMsavedMapLocalMenu[38]("About Memory")
--PERSISTENT.QMsavedMapLocalMenu[39]("Statistiques")
PERSISTENT.QMsavedMapLocalMenu[40]("TMC Receiver")
PERSISTENT.QMsavedMapLocalMenu[41]("Clear Memory")
PERSISTENT.QMsavedMapLocalMenu[42]("Filter")
PERSISTENT.QMsavedMapLocalMenu[43]("Proximity Alerts")
PERSISTENT.QMsavedMapLocalMenu[44]("Warning Sign Alerts")
PERSISTENT.QMsavedMapLocalMenu[45]("Speed Warning Settings")
PERSISTENT.QMsavedMapLocalMenu[46]("Tilt settings")
