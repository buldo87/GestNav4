-- Decompiled using by LuaDec v.0.3 for iGO8 - Sun Apr 16 21:01:21 2017
-- File name: navigatemap.lua

gCockpitAutoClosed = false
gCockpitJustOpened = false
gCheckCockpitID = -1
carPosySave = 0
nextRotate = 0
mapPopupWasEmpty = true
mapPopupNextId = 0
mapPopupOffTimerId = -1
daResetTimerId = -1
PoiSelected = false
maxZoom = DOUBLE.new(sc_GetSysEntry("map", "3d_max_zoomlevel", 14000))
satMaxPhase = 24
EMapMode = {Mode_3D = 1, Mode_2D = 2}
EViewMode = {Close = 0, Normal = 1, Far = 2}
g_MapModeBeforeDragMode = -1
 
sc_SignPostLayerShow = function()
  if st_EasyNav.active and not MODEL.lua.SignpostIsValid() and MODEL.lua.SignpostOn() then
    sc_AngleSignPost()
    MODEL.lua.SignpostIsValid = true
    ui_NavigateMapSingpost.Y = -vLaneInfoSignpostHeight()
    ui_NavigateMapSingpost:YBLEND(0, 15)
  end
  SignPostShow:trigger()
end
 
sc_SignPostLayerHide = function()
  if MODEL.lua.SignpostIsValid() then
    sc_RestoreSmartZoom()
    MODEL.lua.SignpostIsValid = false
    ui_NavigateMapSingpost:YBLEND(-vLaneInfoSignpostHeight() - 5, 15)
  end
  SignPostHide:trigger()
end
 
g_cursor_strapped = false
sc_ResetStrappedCursor = function()
  MODEL.map.primary.cursor_icon = "cursor"
  g_cursor_strapped = false
  PoiSelected = false
end
 
obs_user_browsing_map = var.observer({ONCHANGE = function()
  if g_cursor_strapped == false then
    return 
  end
  sc_ResetStrappedCursor()
end
, MODEL = {MODEL.map.primary.center, MODEL.map.primary.rotate, MODEL.map.primary.zoom, MODEL.map.primary.tilt, MODEL.map.primary.mode, MODEL.map.cursor.position}, TRIGGER_ON_START = false})
st_EasyNav:useLayers(primary, "ui_PropLayer", "ui_EasyNav_Main", "ui_SideList", "ui_EasyNav_NextMan", "ui_EasyNav_DragMode", "ui_EasyNav_Cockpit", "ui_SimulationControls", "ui_SimulationStop", "ui_NavigateMapSpeedLimit", "ui_NavigateMapSingpost", "ui_TripInfoPanel_Via", "ui_TripInfoPanel", "ui_EasyNav_RoundaboutIcons", "ui_StartpointCancel", localMenuLayers, "ui_BugReport", "ui_MapLocalMenuOpenClose", "ui_MapLocalMenuListLayer", "ui_Quick_Menu_Background", "ui_RecalcMsgBoxNavigate", "ui_EasyNav_SkipMenu", "ui_Footer_onmap", uieffect)
st_EasyNav.active = nil
st_EasyNav.onBack = function()
  return sc_CockpitBack()
end
 
st_EasyNav.onLongBack = function()
  return sc_CockpitBack(true)
end
 
st_EasyNav.enter = function()
  gGoTextIsSelect = true
  gKeepMapPosAfterBack = false
end
 
st_EasyNav.init = function()
  sc_PosRecalcLayer()
  sc_Set_Presets()
  sc_init_local_menu("ui.lm_st_EasyNav")
  primary:ONMAPCLICK(sc_EasyMapClick)
  obs_enter_drag_mode:START("no_trigger")
  if MODEL.lua.dragMode() then
    sc_dragmode(true)
    MODEL.lua.mainMenuMode = false
  else
    if MODEL.navigation.is_in_simulation() then
      sc_SetFlyOverMode()
    else
      sc_set_Nav2D3D()
      MODEL.lua.mainMenuMode = false
    end
    sc_SetCockpitMap()
    sc_Set_Follow_On()
    MODEL.map.primary.show_cursor = false
  end
  ATTACH_LANEINFO(sprLaneInfoEasy, "laneinfo.ini")
  ATTACH_LANEINFO(sprLaneInfoSignpost, "laneinfo_signpost.ini")
  ui.bLaneInfoSignpostForceRedraw = 1
  MODEL.map.primary.car_posy = 80
  st_EasyNav.active = true
  ui_Local_Menu_Background.ALPHA = 0
  ui_Local_Menu_Background_Disabled:HIDE()
  if not MODEL.map.primary.center_follow() and not gKeepMapPosAfterBack then
    MODEL.map.primary.center_noanim(MODEL.map.cursor.position())
  end
  gKeepMapPosAfterBack = false
  if showDriveCarefully and MODEL.interface.drive_carefully() then
    sc_drive_carefully_init()
  end
  satPhaseTimerId = doDelayed(20, sc_CycleSatPhase, true)
  MODEL.lua.ismapvisible = true
  CockpitInit:trigger()
end
 
st_EasyNav.done = function()
  sc_reset_primary()
  primary:ONMAPCLICK()
  sc_SetNavCarPos(false)
  killDelayed(satPhaseTimerId)
  ui_Quick_Menu_Background.ALPHA = 0
  ui_Quick_Menu_Background_Disabled:HIDE()
  MODEL.screen.msgbox.pause_tags("popup", true)
  obs_enter_drag_mode:STOP()
  st_EasyNav.active = nil
  obs_user_browsing_map:STOP()
  MODEL.lua.ismapvisible = false
  CockpitDone:trigger()
end
 
if MODEL.other.debug() then
  obs_SIMULATION_BUG_OBSERVER = var.observer({ONCHANGE = function()
    local mapState = MODEL.map.primary.state()
    if (mapState == "simulate_2d" or mapState == "simulate") and vActiveState() ~= "st_easynav" then
      ASSERT(false, "Invalid state accessed from simulation! Tell Isu if you see this. Thanks")
    end
  end
  , MODEL = MODEL.ui.vActiveState, TRIGGER_ON_START = false})
  obs_SIMULATION_BUG_OBSERVER:START()
end
st_EasyNav.exit = function()
  local state = MODEL.map.primary.state()
  if state == "simulate_2d" or state == "simulate" then
    ASSERT(false, "Tell Isu if you see this. Thanks")
    MODEL.map.primary.exit_state()
  end
  gGoTextIsSelect = false
end
 
sc_LMPlaceInfo_onrelease = function()
  sc_close_local_menu()
  if st_FindPOIFlatList.isEntered then
    MODEL.ui.lm_POI_ProviderAll.setcurrent(0)
    gLastProviderID = gROPoi_Provider
    CLEARTOSTATE(st_FindPOIFlatList)
    sc_ShowPlacesAroundCursor("fade", 0, "")
  else
    MODEL.poi.copy_query("poi.flat_search", "poi.tmp_flat", 1)
    sc_ShowPlacesAroundCursor("fade", 0, "")
  end
end
 
sc_LMFavorite_onrelease = function()
  if st_WhereAmI.isActive then
    MODEL.my.map.select_address(MODEL.navigation.car.position())
  end
  sc_close_local_menu()
  sc_btnPM_Favorite_OnRelease()
end
 
sc_LMCursorPos_onrelease = function()
  MODEL.map.primary.center = MODEL.my.map.selected_item.position()
  sc_close_local_menu()
end
 
sc_LMCurrentPos_onrelease = function()
  MODEL.map.primary.center = MODEL.navigation.car.position()
  sc_close_local_menu()
end
 
sc_LMLastPos_onrelease = function()
  MODEL.map.primary.center = MODEL.navigation.car.position()
  sc_close_local_menu()
end
 
sc_ShowItinerList = function()
  sc_NextStateAnim(st_RouteItiner, "vert_scroll", 0, "")
end
 
sc_SignPostDiricon = function()
end
 
sc_RestoreSmartZoom = function()
  local mapLayer = MODEL.map.primary()
  MODEL.lua.showLaneInfo = true
  mapLayer.camera_settings.roundabout.centery = 50
  if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
    if sc_VehicleIsPedestrian() then
      mapLayer.car_posy = 70
    else
      mapLayer.car_posy = 80
    end
  else
    mapLayer.car_posy = 80
  end
  mapLayer.camera_settings.presetid = MODEL.lua.vEasyViewMode() + 1
end
 
sc_AngleSignPost = function()
  MODEL.lua.showLaneInfo = false
  local mapLayer = MODEL.map.primary()
  mapLayer.camera_settings.roundabout.centery = 65
  mapLayer.camera_settings.presetid = 10 * (MODEL.lua.vEasyViewMode() + 1) + 1
end
 
sc_Easy3D = function()
  local mapLayer = MODEL.map.primary()
  if not MODEL.lua.dragMode() then
    mapLayer.center_follow = true
    mapLayer.rotate_follow = true
  end
  mapLayer.save_state(mapLayer.state())
  mapLayer.switch_state("navmap3d", 0)
  if sc_VehicleIsPedestrian() then
    sc_Set_Pedestrian_Presets_3D()
    mapLayer.zoom_follow = false
    mapLayer.tilt_follow = false
  elseif not MODEL.lua.dragMode() then
    mapLayer.zoom_follow = true
    mapLayer.tilt_follow = true
  end
end
 
sc_Easy2D = function()
  local mapLayer = MODEL.map.primary()
  if not MODEL.lua.dragMode() then
    mapLayer.center_follow = true
    mapLayer.rotate_follow = true
  end
  mapLayer.save_state(mapLayer.state())
  mapLayer.switch_state("2dheadup", 0)
  if sc_VehicleIsPedestrian() then
    sc_Set_Pedestrian_Presets_2D()
    mapLayer.zoom_follow = false
    mapLayer.car_posy = 70
    mapLayer.center_posy = 70
  elseif not MODEL.lua.dragMode() then
    mapLayer.zoom_follow = true
    mapLayer.car_posy = 80
    mapLayer.center_posy = 80
  end
  mapLayer.breadcrumbs = sc_VehicleIsPedestrian()
end
 
sc_Dragmode_Type_Changes = function()
  local mapLayer = MODEL.map.primary()
  local mapMode = mapLayer.mode()
  if mapMode == "3d" then
    MODEL.lua.tiltVisible = true
  else
    mapLayer.tilt_factor = float_1
    MODEL.lua.tiltVisible = false
  end
end
 
sc_Easy3Ddragmode = function()
  local mapLayer = MODEL.map.primary()
  sc_Set_Common_3DMap(mapLayer)
  carPosySave = mapLayer.center_posy()
  MODEL.lua.dragMode = true
  MODEL.lua.tiltVisible = true
  mapLayer.zoom_lock = false
  mapLayer.tilt_lock = false
  mapLayer.rotate_lock = false
  mapLayer.center_lock = false
  mapLayer.center_follow = false
  mapLayer.zoom_follow = false
  mapLayer.tilt_follow = false
  mapLayer.rotate_follow = false
  mapLayer.navi_mode_3d_labels = false
  mapLayer.breadcrumbs = sc_VehicleIsPedestrian()
end
 
sc_Easy2Ddragmode = function()
  local mapLayer = MODEL.map.primary()
  sc_Set_Common_2DMap(mapLayer)
  if sc_VehicleIsPedestrian() then
    mapLayer.center_posy = 70
  else
    mapLayer.center_posy = 80
  end
  carPosySave = mapLayer.center_posy()
  MODEL.lua.dragMode = true
  MODEL.lua.tiltVisible = false
  mapLayer.zoom_lock = false
  mapLayer.rotate_lock = false
  mapLayer.center_lock = false
  mapLayer.center_follow = false
  mapLayer.zoom_follow = false
  mapLayer.rotate_follow = false
  mapLayer.breadcrumbs = sc_VehicleIsPedestrian()
  mapLayer.navi_mode_3d_labels = false
end
 
sc_Easy3DFromDragmode = function()
  local mapLayer = MODEL.map.primary()
  MODEL.lua.dragMode = false
  MODEL.lua.tiltVisible = false
  mapLayer.switch_state("navmap3d", 0)
  if sc_VehicleIsPedestrian() then
    mapLayer.zoom_follow = false
    mapLayer.tilt_follow = false
    mapLayer.rotate_follow = false
  else
    mapLayer.zoom_follow = true
    mapLayer.tilt_follow = true
    mapLayer.rotate_follow = true
  end
end
 
sc_Easy2DFromDragmode = function()
  local mapLayer = MODEL.map.primary()
  MODEL.lua.dragMode = false
  MODEL.lua.tiltVisible = false
  mapLayer.switch_state("2dheadup", 0)
  if sc_VehicleIsPedestrian() then
    mapLayer.zoom_follow = false
    mapLayer.breadcrumbs = true
    mapLayer.center_posy = 50
  else
    mapLayer.zoom_follow = true
    mapLayer.breadcrumbs = false
    mapLayer.center_posy = 80
  end
end
 
sc_set_Nav2D3D = function()
  if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
    sc_Easy2D()
  else
    sc_Easy3D()
  end
end
 
sc_set_Nav2D3D_in_dragmode = function()
  if MODEL.map.primary.zoom() > maxZoom then
    return 
  end
  local mapLayer = MODEL.map.primary()
  if MODEL.map.primary.mode() ~= "2d" then
    mapLayer.autochange_mode_for_zoom = false
    sc_Easy2Ddragmode()
  else
    mapLayer.autochange_mode_for_zoom = true
    sc_Easy3Ddragmode()
  end
end
 
sc_set_Nav2D3D_MapSettings = function()
  local mapLayer = MODEL.map.primary()
  mapLayer.car_posx = 50
  mapLayer.center_posx = 50
  sc_set_Nav2D3D()
  mapLayer.car_posx = 25
  mapLayer.center_posx = 25
end
 
sc_Set_Presets = function()
  if sc_VehicleIsPedestrian() then
    sc_Set_Pedestrian_Presets()
  end
  MODEL.map.primary.camera_settings.presetid = MODEL.lua.vEasyViewMode() + 1
end
 
sc_Set_Follow_On = function()
  local mapLayer = MODEL.map.primary()
  if not sc_VehicleIsPedestrian() then
    mapLayer.zoom_follow = true
    mapLayer.tilt_follow = true
  end
  mapLayer.center_follow = true
  mapLayer.rotate_follow = true
end
 
sc_Set_Follow_Off = function()
  local mapLayer = MODEL.map.primary()
  mapLayer.center_follow = false
  mapLayer.zoom_follow = false
  mapLayer.tilt_follow = false
  mapLayer.rotate_follow = false
end
 
sc_Set_Pedestrian_Presets = function()
  if MODEL.map.primary.mode() == "3d" then
    sc_Set_Pedestrian_Presets_3D()
  else
    sc_Set_Pedestrian_Presets_2D()
  end
end
 
sc_Set_Pedestrian_Presets_3D = function()
  local mapLayer = MODEL.map.primary()
  local easyViewMode = MODEL.lua.vEasyViewMode()
  if easyViewMode == EViewMode.Close then
    mapLayer.zoom = 25
    mapLayer.tilt = 8000
  elseif easyViewMode == EViewMode.Normal then
    mapLayer.zoom = 75
    mapLayer.tilt = 7300
  elseif easyViewMode == EViewMode.Far then
    mapLayer.zoom = 130
    mapLayer.tilt = 7000
  end
end
 
sc_Set_Pedestrian_Presets_2D = function()
  local easyViewMode = MODEL.lua.vEasyViewMode()
  if easyViewMode == EViewMode.Close then
    MODEL.map.primary.zoom = 100
  elseif easyViewMode == EViewMode.Normal then
    MODEL.map.primary.zoom = 175
  elseif easyViewMode == EViewMode.Far then
    MODEL.map.primary.zoom = 650
  end
end
 
sc_dragmode = function(SetCursor)
  if MODEL.navigation.is_in_simulation() then
    ASSERT(false, "Dragmode in simulation?")
    local centerLock = MODEL.map.primary.center_lock()
    local follow = MODEL.map.primary.center_follow()
    MODEL.map.primary.center_lock = true
    MODEL.map.primary.center_follow = true
    return 
  end
  if st_RouteItinerMap.isActive then
    ASSERT(false, "Dragmode in itinerview?")
  end
  local mapLayer = MODEL.map.primary()
  if mapLayer.state() == "dragmode" then
    return 
  end
  mapLayer.save_state("dragmode")
  mapLayer.switch_state("dragmode")
  sc_Set_Follow_Off()
  mapLayer.show_cursor = true
  if SetCursor then
    MODEL.map.primary.cursor_icon = "cursor"
  end
  mapLayer.auto_set_cursor = true
  if SetCursor then
    MODEL.map.cursor.position = MODEL.navigation.car.position()
    MODEL.my.map.select_address(MODEL.navigation.car.position())
  end
  obs_Dragmode_Type:START("no_trigger")
  obs_InvalidateClickedListEvent:START("no_trigger")
  sc_reset_primary(false)
  if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
    sc_Easy2Ddragmode()
  else
    mapLayer.autochange_mode_for_zoom = true
    sc_Easy3Ddragmode()
  end
  if g_MapModeBeforeDragMode < 0 then
    g_MapModeBeforeDragMode = MODEL.lua.vEasyMapMode()
  end
  DragModeOn:trigger()
end
 
sc_backFromdragmode = function()
  obs_InvalidateClickedListEvent:STOP()
  nextRotate = 0
  MODEL.lua.dragMode = false
  MODEL.map.primary.autochange_mode_for_zoom = true
  obs_Dragmode_Type:STOP()
  sc_SetCockpitMap()
  MODEL.lua.vEasyMapMode = g_MapModeBeforeDragMode
  g_MapModeBeforeDragMode = -1
  if MODEL.lua.vEasyMapMode() == EMapMode.Mode_2D then
    sc_Easy2DFromDragmode()
  else
    sc_Easy3DFromDragmode()
  end
  BackFromDragMode:trigger()
end
 
sc_setCarPosAfterDragMode = function()
  sc_SetNavCarPos(MODEL.screen.msgbox.is_onscreen())
end
 
sc_EasyMapClick = function()
  local selectedPois = MODEL.map.primary.clicked_poi_list
  if #selectedPois == 1 then
    local currentPoi = selectedPois[0]
    MODEL.my.poi.select_poi(currentPoi.provider_id(), currentPoi.id())
  end
  PoiSelected = false
  gClickedPoiFlag = false
  if #selectedPois and (MODEL.map.primary.zoom():toInt() <= gPoiDistantDistance or st_ShowPoiResultOnMap.isActive) then
    sc_SetPOICursorIcon()
    PoiSelected = true
    gClickedPoiFlag = true
    g_cursor_strapped = true
  else
    PoiMapClick_NoPoi:trigger()
  end
  if MODEL.map.primary.center_follow() then
    obs_enter_drag_mode:STOP()
    sc_dragmode(false)
    obs_enter_drag_mode:START("NO_TRIGGER")
  end
end
 
sc_PoiMapClick_NoPoi = function()
  MODEL.map.primary.cursor_icon = "cursor"
  g_cursor_strapped = false
end
 
sc_InvalidateClickedListEvent = function()
  MODEL.map.primary.cursor_icon = "cursor"
  g_cursor_strapped = false
  PoiSelected = false
end
 
sc_route_planning_start = function()
  g_WaypointIsolatedWarningIssued = {}
  gAviodRouteRecalculated = true
end
 
sc_TunnelOn = function()
  if gUseNightmodeInTunnel and MODEL.map.auto_nightmode() then
    gBeforeTunnel = MODEL.screen.nightmode()
    MODEL.screen.nightmode = true
  end
end
 
sc_TunnelOff = function()
  if gUseNightmodeInTunnel and MODEL.map.auto_nightmode() then
    MODEL.screen.nightmode = gBeforeTunnel
    gBeforeTunnel = false
  end
end
 
gSimControlsFadeDelayID = -1
gSimControlsVisibilityDelayID = -1
gSimControlsFadeMin = 0
gSimControlsFadeMax = 32
gSimControlsFadeInTime = 0
gSimControlsFadeOutTime = 24
tSimControlsObjects = {"spr_SC_bg", "btn_simspeed", "txt_simspeed", "btn_ManNext", "spr_ManNext", "btn_sim_play", "spr_sim_play", "btn_sim_pause", "spr_sim_pause", "btn_ManPrev", "spr_ManPrev"}
sc_ShowHideSimulateControls = function()
  if MODEL.lua.SimControlsVisible() then
    sc_RestartSimControlsDelay()
  else
    MODEL.lua.SimControlsVisible = true
    sc_RestartSimControlsDelay()
  end
end
 
sc_RestartSimControlsDelay = function()
  sc_ResetSimControlsDelay()
  sc_StartFadeSimControls(gSimControlsFadeMin, gSimControlsFadeMax, gSimControlsFadeInTime)
  gSimControlsFadeDelayID = doDelayed(200, "sc_FadeOutSimControls()")
end
 
sc_ResetSimControlsDelay = function()
  if gSimControlsFadeDelayID ~= -1 then
    killDelayed(gSimControlsFadeDelayID)
    gSimControlsFadeDelayID = -1
  end
  if gSimControlsVisibilityDelayID ~= -1 then
    killDelayed(gSimControlsVisibilityDelayID)
    gSimControlsVisibilityDelayID = -1
  end
end
 
sc_FadeOutSimControls = function()
  sc_StartFadeSimControls(gSimControlsFadeMax, gSimControlsFadeMin, gSimControlsFadeOutTime)
  gSimControlsVisibilityDelayID = doDelayed(24, "sc_SimControlsNotVisible()")
end
 
sc_SimControlsNotVisible = function()
  MODEL.lua.SimControlsVisible = false
end
 
sc_StartFadeSimControls = function(from, to, time)
  for cntr = 1, #tSimControlsObjects do
    _G[tSimControlsObjects[cntr]]:BLENDALPHA(from, to, time)
  end
  scroll_SC.ALPHA = to
end
 
sc_simulate_speedup = function()
  if MODEL.route.simulation_speed_percent() == 100 then
    MODEL.route.simulation_speed_percent = 400
  elseif MODEL.route.simulation_speed_percent() == 400 then
    MODEL.route.simulation_speed_percent = 800
  elseif MODEL.route.simulation_speed_percent() == 800 then
    MODEL.route.simulation_speed_percent = 1600
  else
    MODEL.route.simulation_speed_percent = 100
  end
end
 
sc_gpsPosToRoadOn = function()
  MODEL.navigation.gps_pos_to_road = true
end
 
sc_gpsPosToRoadOff = function()
  MODEL.navigation.gps_pos_to_road = false
end
 
sc_nVehicle_change = function()
  sc_SetVehicleSpecificSettings()
  sc_SetCalcmethodText()
  VehicleChanged:trigger()
end
 
sc_VehicleChanged = function()
  if st_RouteParamsWithWarnings_Route.isEntered then
    MODEL.route.list.navigated.clear_alternatives(false)
    MODEL.route.list.navigated.recalculate_all(ERouteChangeType.PreferencesChanged)
  end
end
 
sc_SetVehicleSpecificSettings = function()
  local vehicleType = MODEL.route.settings.primary.vehicle_type()
  if vehicleType == EVehicleType.Pedestrian then
    MODEL.map.show_oneway = false
    MODEL.sound.voice.guidance_enabled = false
  else
    MODEL.map.show_oneway = true
    MODEL.sound.voice.guidance_enabled = true
    if MODEL.EXISTS.map.reset_breadcrumb() then
      MODEL.map.reset_breadcrumb()
    end
  end
  MODEL.route.list.navigated.use_waiting_times = vehicleType == EVehicleType.Truck
  SetVehicle:trigger()
end
 
sc_NorthUP_2DHeadUp = function()
  if nextRotate == 0 then
    nextRotate = MODEL.map.primary.rotate()
    MODEL.map.primary.rotate = 0
  else
    MODEL.map.primary.rotate = nextRotate
    nextRotate = 0
  end
end
 
sc_RotateStop = function()
  MODEL.map.primary.rotate_stop()
  nextRotate = 0
end
 
sc_MapProviderChanged = function(prevProviderName, nextProviderName)
   -- Overwrote pending register. (Assignments::assign)
  MODEL.screen.msgbox.create_from({line = {}, button = {translated_format(m_i18n("You have left the area covered by '%s' maps. This area is covered by '%s' maps."), prevProviderName, nextProviderName)}})
end
 
sc_AutoCloseCockpit = function()
  gCockpitAutoClosed = true
  if (MODEL.lua.CockpitType() == 0 or MODEL.lua.CockpitType() == 1) and MODEL.lua.vEasyNavTripInfoOpen() and not gCockpitJustOpened then
    MODEL.lua.vEasyNavTripInfoOpen = false
  end
end
 
sc_ReopenCockpit = function()
  if not MODEL.lua.vEasyNavTripInfoOpen() and gCockpitAutoClosed then
    MODEL.lua.vEasyNavTripInfoOpen = true
  end
  gCockpitAutoClosed = false
end
 
sc_CheckIfCockpitNeedClose = function()
  gCockpitJustOpened = false
  CheckIfCockpitNeedClose:trigger()
end
 
sc_SelectCockpit_Map = function()
  if MODEL.lua.vEasyNavTripInfoOpen() then
    if MODEL.lua.isValidRoute() then
      lm_CockpitList.has_route_closed[0] = lm_CockpitList.has_route[index]
      ui.vCockpitFieldClosed = index + 1
    else
      lm_CockpitList.no_route_closed[0] = lm_CockpitList.no_route[index]
      ui.vCockpitFieldNoRouteClosed = index + 1
    end
    killDelayed(gCheckCockpitID)
    gCockpitAutoClosed = false
    gCockpitJustOpened = false
  else
    gCockpitJustOpened = true
    gCheckCockpitID = doDelayed(150, sc_CheckIfCockpitNeedClose)
  end
  MODEL.lua.vEasyNavTripInfoOpen = not MODEL.lua.vEasyNavTripInfoOpen()
end
 
sc_AddMapPopup = function(ButtonNumber, text, icon, iconphase, onrelease, onclose, useOncloseAtTimeout, timeout, order, button1txt, button2txt, tag, layer)
  local priority = 1
  MODEL.screen.msgbox.new.setup(ButtonNumber + 2)
  if layer == nil then
    MODEL.screen.msgbox.new.set_layer(ui_MapMessageBox)
  else
    MODEL.screen.msgbox.new.set_layer(layer)
  end
  if type(text) == "string" then
    MODEL.screen.msgbox.new.set_line(1, text)
  else
    MODEL.screen.msgbox.new.set_line_wstr(1, text)
  end
  if useOncloseAtTimeout == nil or useOncloseAtTimeout == false then
    MODEL.screen.msgbox.new.setup_button(1, "")
  else
    MODEL.screen.msgbox.new.setup_button(1, tostring(onclose))
  end
  if ButtonNumber == 1 then
    if button1txt ~= nil then
      MODEL.screen.msgbox.new.setup_button(2, tostring(onrelease), button1txt)
    else
      MODEL.screen.msgbox.new.setup_button(2, tostring(onrelease), m_i18n("OK"))
    end
  elseif ButtonNumber == 2 then
    if button1txt ~= nil then
      MODEL.screen.msgbox.new.setup_button(2, tostring(onrelease), button1txt)
    else
      MODEL.screen.msgbox.new.setup_button(2, tostring(onrelease), m_i18n("Yes"))
    end
    if button2txt ~= nil then
      MODEL.screen.msgbox.new.setup_button(3, tostring(onclose), button2txt)
    else
      MODEL.screen.msgbox.new.setup_button(3, tostring(onclose), m_i18n("No"))
    end
  else
    ASSERT(false, "Nincs megcsinalva erre a gombszamra")
  end
  if icon == nil then
    icon = ""
    iconphase = 0
  end
  if iconphase == nil or iconphase == "" then
    iconphase = 0
  end
  MODEL.screen.msgbox.new.setup_button(ButtonNumber + 2, "", "", "", icon, iconphase)
  MODEL.screen.msgbox.new.add_tag("popup")
  if order ~= nil then
    ASSERT(priority < 100)
    priority = priority + order
  end
  MODEL.screen.msgbox.new.set_priority(priority)
  if timeout ~= nil then
    MODEL.screen.msgbox.new.set_time_out(timeout * 1000)
  end
  if tag ~= nil then
    MODEL.screen.msgbox.new.add_tag(tag)
  end
  return MODEL.screen.msgbox.create_new()
end
 
sc_RemoveMapPopupById = function(removeId)
  MODEL.screen.msgbox.close(removeId)
end
 
sc_GetPopupIndexById = function(popupId)
  local foundIndex = -1
  for i = 0, #MODEL.screen.msgbox.list - 1 do
    local MsgBoxID = MODEL.screen.msgbox.list[i].id()
    if MsgBoxID == popupId then
      foundIndex = i
      break
    end
  end
  return foundIndex
end
 
sc_LaneInfoVisibleOnchange = function()
  if MODEL.lua.laneInfoVisible() then
    sprLaneInfoEasy:BLENDALPHA(0, 32, 20)
  else
    sprLaneInfoEasy:BLENDALPHA(32, 0, 20)
  end
end
 
sc_OnMapInfo = function()
  local selectedPois = MODEL.map.primary.clicked_poi_list
  local Poi = MODEL.my.poi.current
  gKeepMapPosAfterBack = true
  if MODEL.my.map.selected_item.type() == 1 and Poi.provider_id() ~= 0 and Poi.id() ~= 0 and PoiSelected then
    sc_NextStateAnim(st_ShowPOIInfo, "fade", 1, "")
  elseif g_cursor_strapped and #selectedPois and gClickedPoiFlag then
    if #selectedPois == 1 then
      local poi = selectedPois[0]()
      MODEL.my.poi.select_poi(poi.provider_id(), poi.id())
      sc_NextStateAnim(st_ShowPOIInfo, "fade", 1, "")
    else
      st_PoiSelectionOnMapResult.createRouteOnClick = false
      sc_NextStateAnim(st_PoiSelectionOnMapResult, "fade", 1, "")
    end
  else
    PoiMapInfo_NoPoi:trigger()
  end
end
 
sc_PoiMapInfo_NoPoi = function()
  sc_NextStateAnim(st_CursorLocation, "fade", 1, "")
end
 
createState("st_GpsStatus")
st_GpsStatus:useLayers(uieffect, "ui_Footer", "ui_Status", "ui_Title", "ui_GPSStatus", "ui_Background")
st_GpsStatus.init = function()
  txtTitle.TEXT = m_i18n("GPS Information")
  MODEL.gps.autoupdate_satellite_display = true
end
 
st_GpsStatus.done = function()
  MODEL.gps.autoupdate_satellite_display = false
end
 
sc_map_local_menu_gps_status = function()
  sc_NextStateAnim(st_GpsStatus, "horz_scroll", 1, "")
end
 
sc_SetGPS_Phase = function(valid, used, isEgnos, isWaas)
  local phase = 0
  if not valid then
    phase = 1
  elseif not used then
    phase = 3
  elseif isEgnos or isWaas then
    phase = 4
  else
    phase = 0
  end
  return phase
end
 
sc_SetGPSSignal_Bmp = function(valid, used, isEgnos, isWaas)
  local bmp = "gpsstatus_progreswhite_spr.bmp"
  if not valid then
    bmp = "gpsstatus_progreswhite_spr.bmp"
  elseif not used then
    bmp = "gpsstatus_progresred_spr.bmp"
  elseif isEgnos or isWaas then
    bmp = "gpsstatus_progresblue_spr.bmp"
  else
    bmp = "gpsstatus_progresgreen_spr.bmp"
  end
  return bmp
end
 
sc_CaptureScreen = function(force)
  if MODEL.lua.captureScreen or force then
    MODEL.ui.__screenshot()
    doDelayed(15, function()
      sc_InfoMessageBox(m_i18n("DEBUG~Screen Captured"), true)
    end
    )
  end
end
 
sc_SetBMPSize = function(Min, Max, Padding, Bmp, Width, Height, phase)
  local currentW = Width + Padding
  if Max < currentW then
    currentW = Max
  end
  if Min > currentW then
    currentW = Min
  end
  local phaseTxt = ""
  if phase ~= nil and phase ~= 1 then
    phaseTxt = "#" .. phase
  end
  return string.format("%s@%dx%d.bmp%s", Bmp, currentW, Height, phaseTxt)
end
 
sc_SetBMPSizeByPercent = function(Min, Max, Padding, Bmp, Width, Height, phase)
  local Min = sc_GetRealValueW(Min)
  local Max = sc_GetRealValueW(Max)
  local Padding = sc_GetRealValueW(Padding)
  local Width = sc_GetRealValueW(Width)
  local Height = sc_GetRealValueH(Height)
  local currentW = Width + Padding
  if Max < currentW then
    currentW = Max
  end
  if Min > currentW then
    currentW = Min
  end
  local phaseTxt = ""
  if phase ~= nil and phase ~= 1 then
    phaseTxt = "#" .. phase
  end
  return string.format("%s@%dx%d.bmp%s", Bmp, currentW, Height, phaseTxt)
end
 
sc_ToPercent = function(value)
  return DOUBLE.new(value) / 100
end
 
sc_GetRealValueW = function(value)
  local var = DOUBLE.new(value)
  if var < DOUBLE.new(1) then
    return DOUBLE.new(value * CSS.Param.width):toInt()
  else
    return value
  end
end
 
sc_GetRealValueH = function(value)
  local var = DOUBLE.new(value)
  if var < DOUBLE.new(1) then
    return DOUBLE.new(value * CSS.Param.height):toInt()
  else
    return value
  end
end
 
sc_Compass = function(heading)
  if heading == nil then
    return ""
  end
  heading = (4095 - heading) * 360 / 4096
  if heading > 180 then
    heading = heading - 360
  end
  if heading == nil then
    return L""
  elseif heading > -22 and heading <= 22 then
    return translate("HEADING~N")
  elseif heading > 22 and heading <= 67 then
    return translate("HEADING~NE")
  elseif heading > 67 and heading <= 112 then
    return translate("HEADING~E")
  elseif heading > 112 and heading <= 157 then
    return translate("HEADING~SE")
  elseif heading > -67 and heading <= -22 then
    return translate("HEADING~NW")
  elseif heading > -112 and heading <= -67 then
    return translate("HEADING~W")
  elseif heading > -157 and heading <= -112 then
    return translate("HEADING~SW")
  elseif heading > 157 and heading <= 180 or heading <= -157 and heading > -180 then
    return translate("HEADING~S")
  end
end
 
sc_OpenMapMenu = function()
  MODEL.lua.vEasyNavMapMenuOpen = not MODEL.lua.vEasyNavMapMenuOpen()
end
 
sc_StartPointCancel_Onrelease = function()
  StartPointCancel:trigger()
  if MODEL.route.list.navigated.waypoints.start_is_user_selected() then
    sc_TurnOnGPSMsg()
  else
    sc_TurnOnGPS()
  end
end
 
sc_CalcSpeedLimitPercent = function()
  local SpeedLimit = MODEL.warning.driveralert.speed_limit()
  local CurrentSpeed = MODEL.navigation.car.current_speed()
  if SpeedLimit == 0 then
    return 0
  end
  local SpeedPercent = CurrentSpeed * 100 / SpeedLimit - 100
  if SpeedPercent > 99 then
    return "!!!"
  elseif SpeedPercent > 0 then
    if MODEL.lua.speedWarningAlwaysVisibleChk() then
      return tostring(SpeedPercent) .. "%"
    else
      return "+" .. tostring(SpeedPercent) .. "%"
    end
  else
    return tostring(SpeedPercent) .. "%"
  end
end
 
sc_GetSatX = function(phase, index, radius, bmpWidth)
  local phase = (phase + satMaxPhase / 3 * index) % satMaxPhase
  local angle = DOUBLE.new("6.283") * phase / satMaxPhase
  return DOUBLE.cos(angle) * radius:toInt() - bmpWidth / 2
end
 
sc_GetSatY = function(phase, index, radius, bmpWidth)
  local phase = (phase + satMaxPhase / 3 * index) % satMaxPhase
  local angle = DOUBLE.new("6.283") * phase / satMaxPhase
  return DOUBLE.sin(angle) * radius:toInt() - bmpWidth / 2
end
 
sc_GetSatX2 = function(phase, index, bias)
  local phase = (phase + satMaxPhase / 3 * index) % satMaxPhase
  local angle = DOUBLE.new("6.283") * phase / satMaxPhase
  return DOUBLE.cos(angle) * SatAnimRadius:toInt() + bias
end
 
sc_GetSatY2 = function(phase, index, bias)
  local phase = (phase + satMaxPhase / 3 * index) % satMaxPhase
  local angle = DOUBLE.new("6.283") * phase / satMaxPhase
  return DOUBLE.sin(angle) * SatAnimRadius:toInt() + bias
end
 
sc_GetSatZ = function(phase, index)
  if (phase + satMaxPhase / 3 * index) % satMaxPhase > satMaxPhase / 2 or not 12 then
  end
  return 9
end
 
sc_CycleSatPhase = function()
  MODEL.lua.satPhase = (MODEL.lua.satPhase() + 1) % satMaxPhase
end
 
sc_SetNavCarPos = function(isPanelOpen)
  local maplayer = MODEL.map.primary
  if isPanelOpen then
    if MODEL.lua.CockpitType() == 1 then
      maplayer.car_posx = 44
      maplayer.center_posx = 44
    elseif MODEL.lua.CockpitType() == 2 then
      maplayer.car_posx = 31
      maplayer.center_posx = 31
    else
      maplayer.car_posx = 33
      maplayer.center_posx = 33
    end
  else
    maplayer.car_posx = 50
    maplayer.center_posx = 50
  end
  if MODEL.lua.tripInfoVisible() then
    maplayer.car_posx = maplayer.car_posx() + 2
    maplayer.center_posx = maplayer.center_posx() + 2
  end
end
 
sc_GetAdvancedSpeedLimitPhase = function(speed, speed_limit)
  if speed <= speed_limit then
    return 0
  elseif speed <= speed_limit * MODEL.warning.speedwarn_alt_tolerance() / 100 then
    return 1
  else
    return 2
  end
end
 
gSpeedLimitLoopDelay = -1
sc_SpeedLimitConditionChanged = function()
  local driveralert = MODEL.warning.driveralert
  MODEL.lua.ShowConditionalSpeedLimit = false
  if driveralert.speed_limit_condition.valid() then
    if driveralert.speed_limit_condition() == eSpeedlimitContionTypes.eTime then
      return 
    end
    if gSpeedLimitLoopDelay == -1 then
      MODEL.lua.ShowConditionalSpeedLimit = true
      gSpeedLimitLoopDelay = doDelayed(250, sc_SpeedLimitConditionLoop, true)
    end
  elseif gSpeedLimitLoopDelay ~= -1 then
    killDelayed(gSpeedLimitLoopDelay)
    gSpeedLimitLoopDelay = -1
  end
end
 
sc_SpeedLimitConditionLoop = function()
  local driveralert = MODEL.warning.driveralert
  if driveralert.speed_limit_condition() == eSpeedlimitContionTypes.eTime then
    MODEL.lua.ShowConditionalSpeedLimit = false
    ASSERT(false, "Forgot stop timer?")
    return 
  end
  MODEL.lua.ShowConditionalSpeedLimit = not MODEL.lua.ShowConditionalSpeedLimit()
end
 
sc_RefreshOverviewStatus = function()
  MODEL.lua.OverViewModeOn = not MODEL.lua.OverViewModeOn()
  MODEL.lua.OverViewModeOn = not MODEL.lua.OverViewModeOn()
end
 
sc_SetPOICursorIcon = function()
  local selectedPois = MODEL.map.primary.clicked_poi_list
  local OneTypePoi = true
  if #selectedPois > 1 then
    for poiIdx = 1, #selectedPois - 1 do
      if selectedPois[0]().icon() ~= selectedPois[poiIdx]().icon() then
        OneTypePoi = false
        break
      end
    end
  end
  local FileName = nil
  if #selectedPois then
    FileName = MODEL.screen.get_icon_file_and_phase(selectedPois[0].icon(), 1)
  else
    FileName = MODEL.screen.get_icon_file_and_phase(MODEL.my.poi.current.icon(), 1)
  end
  if OneTypePoi and FileName:sub(1, 1) == "*" then
    MODEL.map.primary.cursor_icon = "cursor_poi_brand"
  else
    MODEL.map.primary.cursor_icon = "cursor_poi"
  end
end
 
sc_IsMapPopupOnscreen = function()
  local popup = false
  if MODEL.screen.msgbox.is_onscreen() then
    popup = MODEL.screen.msgbox.on_screen.has_tag("popup")
  end
  return popup
end
 
gcockpitHeader_autodetect = nil
gcockpitHeader_detect = nil
gcockpitHeader_startpoint = nil
sc_cockpitHeaderLayer_onshow = function()
  MODEL.lua.cockpitHeaderLayerVisible = true
end
 
sc_cockpitHeaderLayer_onhide = function()
  if not gcockpitHeader_autodetect and not gcockpitHeader_detect and not gcockpitHeader_startpoint then
    MODEL.lua.cockpitHeaderLayerVisible = false
  end
end
 
sc_GpsListGlonass = function()
  MODEL.ui.lmGpsSatellites.clear()
  MODEL.ui.lmGpsSatellitesGlonass.clear()
  MODEL.lua.SatellitesAvailable = 0
  MODEL.lua.SatellitesAvailableGlonass = 0
  for gpslist,idx in ModelList_iter(MODEL.gps.satellites) do
    if gpslist.prn() < 64 or not MODEL.lua.ShowGlonass() then
      ui.lmGpsSatellites:add({prn = gpslist.prn(), valid = gpslist.valid(), used = gpslist.used(), egnos = gpslist.egnos(), waas = gpslist.waas(), snr = gpslist.snr(), elevation = gpslist.snr(), azimuth = gpslist.azimuth(), posx = gpslist.posx(), posy = gpslist.posy()})
      if gpslist.used() == true then
        MODEL.lua.SatellitesAvailable = MODEL.lua.SatellitesAvailable() + 1
      end
    else
      ui.lmGpsSatellitesGlonass:add({prn = gpslist.prn(), valid = gpslist.valid(), used = gpslist.used(), egnos = gpslist.egnos(), waas = gpslist.waas(), snr = gpslist.snr(), elevation = gpslist.snr(), azimuth = gpslist.azimuth(), posx = gpslist.posx(), posy = gpslist.posy()})
      if gpslist.used() == true then
        MODEL.lua.SatellitesAvailableGlonass = MODEL.lua.SatellitesAvailableGlonass() + 1
      end
    end
  end
end