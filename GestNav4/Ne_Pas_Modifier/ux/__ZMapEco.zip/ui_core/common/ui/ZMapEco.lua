
function sc_NavCtrl_ScreenChange(screenType)
    debug_log("lg_renault", 3, "lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
    sc_HwKeySelect()
    if screenType == eScreenTypes.Map then
        sc_GoToMap()
    elseif screenType == eScreenTypes.Nav then
		sc_GoTo_MainMenu()
    elseif screenType == eScreenTypes.BackFromSynctool then
        debug_log("lg_renault", 3, "Looks like we\'re just back from synctool. Going to content screen.")
        NEXTSTATE(st_AboutContents)
    else
        debug_log("lg_renault", 1, "SERIOUS screen-change PROBLEM: lua sc_NavCtrl_ScreenChange screenType = " .. tostring(screenType))
        sc_GoTo_MainMenu()
    end
end