MODEL.SETPERSISTENT.lua.TransButtonAltitude = INT_MODEL(32)
MODEL.SETPERSISTENT.lua.TransButtonArrow = INT_MODEL(32)
MODEL.SETPERSISTENT.lua.BdArrowColor = INT_MODEL(8)
MODEL.SETPERSISTENT.lua.BdArrow2Color = INT_MODEL(14)
MODEL.SETPERSISTENT.lua.SpeedInfoColorD = INT_MODEL(5)
MODEL.SETPERSISTENT.lua.SpeedInfoColorN = INT_MODEL(6)
MODEL.SETPERSISTENT.lua.Surv = BOOL_MODEL(false)
MODEL.SETPERSISTENT.lua.SBHome = WSTRING_MODEL(L"")
MODEL.SETPERSISTENT.lua.SBWork = WSTRING_MODEL(L"")
MODEL.SET.lua.SBFAVNOCNT = BOOL_MODEL(false)
--mod by Rafael2san
MODEL.SET.lua.SelectMapContent = BOOL_MODEL(false)
MODEL.SET.lua.ChangeMapContent = BOOL_MODEL(true)
--rafael2san
MODEL.SET.lua.tomtompicture = BOOL_MODEL(false)
MODEL.SET.lua.herepicture = BOOL_MODEL(false)
-- Modif Hb31 Bouton Day Night
MODEL.SETPERSISTENT.lua.JourNuit = BOOL_MODEL(true)

-- Fin Modif