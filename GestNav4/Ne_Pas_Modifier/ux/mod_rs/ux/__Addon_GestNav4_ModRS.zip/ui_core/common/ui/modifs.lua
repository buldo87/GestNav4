
st_EasyNav.init = function()
MODEL.lua.EtatMapchanger = sc_GetSysEntry("gestnav3", "image_maps", 0) 
  sc_PosRecalcLayer()
  sc_Set_Presets()
  sc_init_local_menu("ui.lm_st_EasyNav")
  primary:ONMAPCLICK(sc_EasyMapClick)
  obs_enter_drag_mode:START("no_trigger")
  if MODEL.lua.dragMode() then
    sc_dragmode(true)
    MODEL.lua.mainMenuMode = false
  else
    if MODEL.navigation.is_in_simulation() then
      sc_SetFlyOverMode()
    else
      sc_set_Nav2D3D()
      MODEL.lua.mainMenuMode = false
    end
    sc_SetCockpitMap()
    sc_Set_Follow_On()
    MODEL.map.primary.show_cursor = false
  end
  ATTACH_LANEINFO(sprLaneInfoEasy, "laneinfo.ini")
  ATTACH_LANEINFO(sprLaneInfoSignpost, "laneinfo_signpost.ini")
  ui.bLaneInfoSignpostForceRedraw = 1
  MODEL.map.primary.car_posy = 80
  st_EasyNav.active = true
  ui_Local_Menu_Background.ALPHA = 0
  ui_Local_Menu_Background_Disabled:HIDE()
  if not MODEL.map.primary.center_follow() and not gKeepMapPosAfterBack then
    MODEL.map.primary.center_noanim(MODEL.map.cursor.position())
  end
  gKeepMapPosAfterBack = false
  if showDriveCarefully and MODEL.interface.drive_carefully() then
    sc_drive_carefully_init()
  end
  satPhaseTimerId = doDelayed(20, sc_CycleSatPhase, true)
  MODEL.lua.ismapvisible = true
  CockpitInit:trigger()
end
	MODEL.lua.EtatMapchanger = sc_GetSysEntry("gestnav3", "image_maps", 0) 
